module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// object to store loaded chunks
/******/ 	// "0" means "already loaded"
/******/ 	var installedChunks = {
/******/ 		0: 0
/******/ 	};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/ 	// This file contains only the entry chunk.
/******/ 	// The chunk loading function for additional chunks
/******/ 	__webpack_require__.e = function requireEnsure(chunkId) {
/******/ 		var promises = [];
/******/
/******/
/******/ 		// require() chunk loading for javascript
/******/
/******/ 		// "0" is the signal for "already loaded"
/******/ 		if(installedChunks[chunkId] !== 0) {
/******/ 			var chunk = require("./" + ({"1":"pages/aboutme","2":"pages/contact","3":"pages/index","4":"pages/portfolio"}[chunkId]||chunkId) + ".js");
/******/ 			var moreModules = chunk.modules, chunkIds = chunk.ids;
/******/ 			for(var moduleId in moreModules) {
/******/ 				modules[moduleId] = moreModules[moduleId];
/******/ 			}
/******/ 			for(var i = 0; i < chunkIds.length; i++)
/******/ 				installedChunks[chunkIds[i]] = 0;
/******/ 		}
/******/ 		return Promise.all(promises);
/******/ 	};
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/_nuxt/";
/******/
/******/ 	// uncaught error handler for webpack runtime
/******/ 	__webpack_require__.oe = function(err) {
/******/ 		process.nextTick(function() {
/******/ 			throw err; // catch this error by using import().catch()
/******/ 		});
/******/ 	};
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 23);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports) {

module.exports = require("vue");

/***/ }),
/* 1 */
/***/ (function(module, exports) {

module.exports = require("ufo");

/***/ }),
/* 2 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return normalizeComponent; });
/* globals __VUE_SSR_CONTEXT__ */

// IMPORTANT: Do NOT use ES2015 features in this file (except for modules).
// This module is a runtime utility for cleaner component module output and will
// be included in the final webpack user bundle.

function normalizeComponent (
  scriptExports,
  render,
  staticRenderFns,
  functionalTemplate,
  injectStyles,
  scopeId,
  moduleIdentifier, /* server only */
  shadowMode /* vue-cli only */
) {
  // Vue.extend constructor export interop
  var options = typeof scriptExports === 'function'
    ? scriptExports.options
    : scriptExports

  // render functions
  if (render) {
    options.render = render
    options.staticRenderFns = staticRenderFns
    options._compiled = true
  }

  // functional template
  if (functionalTemplate) {
    options.functional = true
  }

  // scopedId
  if (scopeId) {
    options._scopeId = 'data-v-' + scopeId
  }

  var hook
  if (moduleIdentifier) { // server build
    hook = function (context) {
      // 2.3 injection
      context =
        context || // cached call
        (this.$vnode && this.$vnode.ssrContext) || // stateful
        (this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext) // functional
      // 2.2 with runInNewContext: true
      if (!context && typeof __VUE_SSR_CONTEXT__ !== 'undefined') {
        context = __VUE_SSR_CONTEXT__
      }
      // inject component styles
      if (injectStyles) {
        injectStyles.call(this, context)
      }
      // register component module identifier for async chunk inferrence
      if (context && context._registeredComponents) {
        context._registeredComponents.add(moduleIdentifier)
      }
    }
    // used by ssr in case component is cached and beforeCreate
    // never gets called
    options._ssrRegister = hook
  } else if (injectStyles) {
    hook = shadowMode
      ? function () {
        injectStyles.call(
          this,
          (options.functional ? this.parent : this).$root.$options.shadowRoot
        )
      }
      : injectStyles
  }

  if (hook) {
    if (options.functional) {
      // for template-only hot-reload because in that case the render fn doesn't
      // go through the normalizer
      options._injectStyles = hook
      // register for functional component in vue file
      var originalRender = options.render
      options.render = function renderWithStyleInjection (h, context) {
        hook.call(context)
        return originalRender(h, context)
      }
    } else {
      // inject component registration as beforeCreate hook
      var existing = options.beforeCreate
      options.beforeCreate = existing
        ? [].concat(existing, hook)
        : [hook]
    }
  }

  return {
    exports: scriptExports,
    options: options
  }
}


/***/ }),
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/*
  MIT License http://www.opensource.org/licenses/mit-license.php
  Author Tobias Koppers @sokra
*/
// css base code, injected by the css-loader
// eslint-disable-next-line func-names
module.exports = function (useSourceMap) {
  var list = []; // return the list of modules as css string

  list.toString = function toString() {
    return this.map(function (item) {
      var content = cssWithMappingToString(item, useSourceMap);

      if (item[2]) {
        return "@media ".concat(item[2], " {").concat(content, "}");
      }

      return content;
    }).join('');
  }; // import a list of modules into the list
  // eslint-disable-next-line func-names


  list.i = function (modules, mediaQuery, dedupe) {
    if (typeof modules === 'string') {
      // eslint-disable-next-line no-param-reassign
      modules = [[null, modules, '']];
    }

    var alreadyImportedModules = {};

    if (dedupe) {
      for (var i = 0; i < this.length; i++) {
        // eslint-disable-next-line prefer-destructuring
        var id = this[i][0];

        if (id != null) {
          alreadyImportedModules[id] = true;
        }
      }
    }

    for (var _i = 0; _i < modules.length; _i++) {
      var item = [].concat(modules[_i]);

      if (dedupe && alreadyImportedModules[item[0]]) {
        // eslint-disable-next-line no-continue
        continue;
      }

      if (mediaQuery) {
        if (!item[2]) {
          item[2] = mediaQuery;
        } else {
          item[2] = "".concat(mediaQuery, " and ").concat(item[2]);
        }
      }

      list.push(item);
    }
  };

  return list;
};

function cssWithMappingToString(item, useSourceMap) {
  var content = item[1] || ''; // eslint-disable-next-line prefer-destructuring

  var cssMapping = item[3];

  if (!cssMapping) {
    return content;
  }

  if (useSourceMap && typeof btoa === 'function') {
    var sourceMapping = toComment(cssMapping);
    var sourceURLs = cssMapping.sources.map(function (source) {
      return "/*# sourceURL=".concat(cssMapping.sourceRoot || '').concat(source, " */");
    });
    return [content].concat(sourceURLs).concat([sourceMapping]).join('\n');
  }

  return [content].join('\n');
} // Adapted from convert-source-map (MIT)


function toComment(sourceMap) {
  // eslint-disable-next-line no-undef
  var base64 = btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap))));
  var data = "sourceMappingURL=data:application/json;charset=utf-8;base64,".concat(base64);
  return "/*# ".concat(data, " */");
}

/***/ }),
/* 4 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, "default", function() { return /* binding */ addStylesServer; });

// CONCATENATED MODULE: ./node_modules/vue-style-loader/lib/listToStyles.js
/**
 * Translates the list format produced by css-loader into something
 * easier to manipulate.
 */
function listToStyles (parentId, list) {
  var styles = []
  var newStyles = {}
  for (var i = 0; i < list.length; i++) {
    var item = list[i]
    var id = item[0]
    var css = item[1]
    var media = item[2]
    var sourceMap = item[3]
    var part = {
      id: parentId + ':' + i,
      css: css,
      media: media,
      sourceMap: sourceMap
    }
    if (!newStyles[id]) {
      styles.push(newStyles[id] = { id: id, parts: [part] })
    } else {
      newStyles[id].parts.push(part)
    }
  }
  return styles
}

// CONCATENATED MODULE: ./node_modules/vue-style-loader/lib/addStylesServer.js


function addStylesServer (parentId, list, isProduction, context) {
  if (!context && typeof __VUE_SSR_CONTEXT__ !== 'undefined') {
    context = __VUE_SSR_CONTEXT__
  }
  if (context) {
    if (!context.hasOwnProperty('styles')) {
      Object.defineProperty(context, 'styles', {
        enumerable: true,
        get: function() {
          return renderStyles(context._styles)
        }
      })
      // expose renderStyles for vue-server-renderer (vuejs/#6353)
      context._renderStyles = renderStyles
    }

    var styles = context._styles || (context._styles = {})
    list = listToStyles(parentId, list)
    if (isProduction) {
      addStyleProd(styles, list)
    } else {
      addStyleDev(styles, list)
    }
  }
}

// In production, render as few style tags as possible.
// (mostly because IE9 has a limit on number of style tags)
function addStyleProd (styles, list) {
  for (var i = 0; i < list.length; i++) {
    var parts = list[i].parts
    for (var j = 0; j < parts.length; j++) {
      var part = parts[j]
      // group style tags by media types.
      var id = part.media || 'default'
      var style = styles[id]
      if (style) {
        if (style.ids.indexOf(part.id) < 0) {
          style.ids.push(part.id)
          style.css += '\n' + part.css
        }
      } else {
        styles[id] = {
          ids: [part.id],
          css: part.css,
          media: part.media
        }
      }
    }
  }
}

// In dev we use individual style tag for each module for hot-reload
// and source maps.
function addStyleDev (styles, list) {
  for (var i = 0; i < list.length; i++) {
    var parts = list[i].parts
    for (var j = 0; j < parts.length; j++) {
      var part = parts[j]
      styles[part.id] = {
        ids: [part.id],
        css: part.css,
        media: part.media
      }
    }
  }
}

function renderStyles (styles) {
  var css = ''
  for (var key in styles) {
    var style = styles[key]
    css += '<style data-vue-ssr-id="' + style.ids.join(' ') + '"' +
        (style.media ? ( ' media="' + style.media + '"' ) : '') + '>' +
        style.css + '</style>'
  }
  return css
}


/***/ }),
/* 5 */
/***/ (function(module, exports) {

// This file is intentionally left empty for noop aliases

/***/ }),
/* 6 */
/***/ (function(module, exports) {

module.exports = require("vue-no-ssr");

/***/ }),
/* 7 */
/***/ (function(module, exports) {

module.exports = require("vue-client-only");

/***/ }),
/* 8 */
/***/ (function(module, exports) {

module.exports = require("vue-router");

/***/ }),
/* 9 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = function (url, options) {
  if (!options) {
    // eslint-disable-next-line no-param-reassign
    options = {};
  } // eslint-disable-next-line no-underscore-dangle, no-param-reassign


  url = url && url.__esModule ? url.default : url;

  if (typeof url !== 'string') {
    return url;
  } // If url is already wrapped in quotes, remove them


  if (/^['"].*['"]$/.test(url)) {
    // eslint-disable-next-line no-param-reassign
    url = url.slice(1, -1);
  }

  if (options.hash) {
    // eslint-disable-next-line no-param-reassign
    url += options.hash;
  } // Should url be wrapped?
  // See https://drafts.csswg.org/css-values-3/#urls


  if (/["'() \t\n]/.test(url) || options.needQuotes) {
    return "\"".concat(url.replace(/"/g, '\\"').replace(/\n/g, '\\n'), "\"");
  }

  return url;
};

/***/ }),
/* 10 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./components/light.vue?vue&type=template&id=50fea370&scoped=true&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"light_background md:w-screen px-0"},[_vm._ssrNode("<img"+(_vm._ssrAttr("data-src",__webpack_require__(25)))+(_vm._ssrAttr("test",_vm.light.src))+(_vm._ssrAttr("srcSet",_vm.light.srcSet))+" alt=\"light\" class=\"lazyload light overflow-hidden \" data-v-50fea370>")])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/light.vue?vue&type=template&id=50fea370&scoped=true&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/light.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
const light = __webpack_require__(26);

/* harmony default export */ var lightvue_type_script_lang_js_ = ({
  name: "light",

  data() {
    return {
      light
    };
  }

});
// CONCATENATED MODULE: ./components/light.vue?vue&type=script&lang=js&
 /* harmony default export */ var components_lightvue_type_script_lang_js_ = (lightvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(2);

// CONCATENATED MODULE: ./components/light.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(27)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  components_lightvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "50fea370",
  "0b74bbfc"
  
)

/* harmony default export */ var components_light = __webpack_exports__["a"] = (component.exports);

/***/ }),
/* 11 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(28);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(4).default
module.exports.__inject__ = function (context) {
  add("c87ed110", content, true, context)
};

/***/ }),
/* 12 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(30);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(4).default
module.exports.__inject__ = function (context) {
  add("468e057e", content, true, context)
};

/***/ }),
/* 13 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(33);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(4).default
module.exports.__inject__ = function (context) {
  add("310278e4", content, true, context)
};

/***/ }),
/* 14 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(39);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(4).default
module.exports.__inject__ = function (context) {
  add("221e2513", content, true, context)
};

/***/ }),
/* 15 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(42);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(4).default
module.exports.__inject__ = function (context) {
  add("7c94fe8a", content, true, context)
};

/***/ }),
/* 16 */
/***/ (function(module, exports) {

module.exports = require("node-fetch");

/***/ }),
/* 17 */
/***/ (function(module, exports) {

module.exports = require("vue-meta");

/***/ }),
/* 18 */
/***/ (function(module, exports) {

module.exports = require("lazysizes");

/***/ }),
/* 19 */
/***/ (function(module) {

module.exports = JSON.parse("{\"title\":\"c1chy.app\",\"meta\":[{\"hid\":\"charset\",\"charset\":\"utf-8\"},{\"hid\":\"viewport\",\"name\":\"viewport\",\"content\":\"width=device-width, initial-scale=1\"},{\"hid\":\"mobile-web-app-capable\",\"name\":\"mobile-web-app-capable\",\"content\":\"yes\"},{\"hid\":\"apple-mobile-web-app-title\",\"name\":\"apple-mobile-web-app-title\",\"content\":\"c1chy.app\"},{\"hid\":\"author\",\"name\":\"author\",\"content\":\"c1chy\"},{\"hid\":\"description\",\"name\":\"description\",\"content\":\"My Frontend experience and projects\"},{\"hid\":\"theme-color\",\"name\":\"theme-color\",\"content\":\"#40635b\"},{\"hid\":\"og:type\",\"name\":\"og:type\",\"property\":\"og:type\",\"content\":\"website\"},{\"hid\":\"og:title\",\"name\":\"og:title\",\"property\":\"og:title\",\"content\":\"c1chy.app\"},{\"hid\":\"og:site_name\",\"name\":\"og:site_name\",\"property\":\"og:site_name\",\"content\":\"c1chy.app\"},{\"hid\":\"og:description\",\"name\":\"og:description\",\"property\":\"og:description\",\"content\":\"My Frontend experience and projects\"}],\"link\":[{\"hid\":\"shortcut-icon\",\"rel\":\"shortcut icon\",\"href\":\"/_nuxt/icons/icon_64x64.789ef7.png\"},{\"hid\":\"apple-touch-icon\",\"rel\":\"apple-touch-icon\",\"href\":\"/_nuxt/icons/icon_512x512.789ef7.png\",\"sizes\":\"512x512\"},{\"rel\":\"manifest\",\"href\":\"/_nuxt/manifest.7d95adfc.json\",\"hid\":\"manifest\"}],\"htmlAttrs\":{\"lang\":\"de\"}}");

/***/ }),
/* 20 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/927d57c.webp";

/***/ }),
/* 21 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/10f4c86.png";

/***/ }),
/* 22 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/442f483.webp";

/***/ }),
/* 23 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(43);


/***/ }),
/* 24 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/85b5ef9.webp";

/***/ }),
/* 25 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/825c15c.png";

/***/ }),
/* 26 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = {
          srcSet: __webpack_require__.p + "img/88196ea-300.webp"+" 300w"+","+__webpack_require__.p + "img/b041aa0-600.webp"+" 600w"+","+__webpack_require__.p + "img/d9d7436-1000.webp"+" 1000w",
          images:[ {path: __webpack_require__.p + "img/88196ea-300.webp",width: 300,height: 300},{path: __webpack_require__.p + "img/b041aa0-600.webp",width: 600,height: 600},{path: __webpack_require__.p + "img/d9d7436-1000.webp",width: 1000,height: 1000}],
          src: __webpack_require__.p + "img/88196ea-300.webp",
          toString:function(){return __webpack_require__.p + "img/88196ea-300.webp"},
          
          width: 300,
          height: 300
        }

/***/ }),
/* 27 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_vue_loader_lib_index_js_vue_loader_options_light_vue_vue_type_style_index_0_id_50fea370_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(11);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_vue_loader_lib_index_js_vue_loader_options_light_vue_vue_type_style_index_0_id_50fea370_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_vue_loader_lib_index_js_vue_loader_options_light_vue_vue_type_style_index_0_id_50fea370_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_vue_loader_lib_index_js_vue_loader_options_light_vue_vue_type_style_index_0_id_50fea370_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_vue_loader_lib_index_js_vue_loader_options_light_vue_vue_type_style_index_0_id_50fea370_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),
/* 28 */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(3);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".light_background[data-v-50fea370]{width:160vw;position:absolute;top:45%;left:50%;transform:translate(-50%,-50%);margin:0;overflow:hidden}.light_background img.light[data-v-50fea370]{z-index:-1;height:100vmax;width:100%;-webkit-animation:rotate 120s linear infinite;animation:rotate 120s linear infinite;-o-object-fit:cover;object-fit:cover;overflow:hidden}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),
/* 29 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_vue_loader_lib_index_js_vue_loader_options_error_vue_vue_type_style_index_0_id_2c0d40b1_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(12);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_vue_loader_lib_index_js_vue_loader_options_error_vue_vue_type_style_index_0_id_2c0d40b1_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_vue_loader_lib_index_js_vue_loader_options_error_vue_vue_type_style_index_0_id_2c0d40b1_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_vue_loader_lib_index_js_vue_loader_options_error_vue_vue_type_style_index_0_id_2c0d40b1_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_vue_loader_lib_index_js_vue_loader_options_error_vue_vue_type_style_index_0_id_2c0d40b1_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),
/* 30 */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(3);
var ___CSS_LOADER_GET_URL_IMPORT___ = __webpack_require__(9);
var ___CSS_LOADER_URL_IMPORT_0___ = __webpack_require__(31);
var ___CSS_LOADER_URL_IMPORT_1___ = __webpack_require__(21);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
var ___CSS_LOADER_URL_REPLACEMENT_0___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_0___);
var ___CSS_LOADER_URL_REPLACEMENT_1___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_1___);
// Module
___CSS_LOADER_EXPORT___.push([module.i, "section[data-v-2c0d40b1]{background-color:#faebd7;background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_0___ + ")}header h1[data-v-2c0d40b1]{color:#224a49;filter:drop-shadow(5px 6px 0 #a9c9bb);font-family:Barlow Condensed,sans-serif}header div[data-v-2c0d40b1]:first-child{width:100vw;position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);margin:0;overflow:hidden}header img.light[data-v-2c0d40b1]{height:100vmax;width:100%;-webkit-animation:rotate 120s linear infinite;animation:rotate 120s linear infinite;z-index:-1;-o-object-fit:cover;object-fit:cover;overflow:hidden}header .title[data-v-2c0d40b1]{font-family:Barlow Condensed,sans-serif;color:#4f7b70;line-height:normal}header .title h1[data-v-2c0d40b1]{-webkit-text-stroke-width:3px;filter:drop-shadow(4px 5px 0 #224a49);-webkit-text-stroke-color:#e4ddd3;background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_1___ + ");background-color:#4f7b70;-webkit-font-smoothing:antialiased;-webkit-background-clip:text;-webkit-text-fill-color:transparent}header .title_dividers span[data-v-2c0d40b1]{background:linear-gradient(270deg,hsla(0,0%,100%,.01),#e9e4dd,#e9e4dd,hsla(0,0%,100%,.01))}header figure figcaption[data-v-2c0d40b1]{font-family:Satisfy,sans-serif;letter-spacing:10px}header figure figcaption a[data-v-2c0d40b1]{transition:all .2s ease}header figure figcaption a[data-v-2c0d40b1]:hover{color:#224a49}.banner[data-v-2c0d40b1]{background-color:#224a49;margin-left:25%;margin-right:25%;border-radius:50px}.banner img[data-v-2c0d40b1]{margin-top:2rem;margin-bottom:1rem}p[data-v-2c0d40b1]{font-size:3.333333em;color:#224a49;line-height:1.08;text-align:center;margin:0;padding:0;border:0;vertical-align:baseline;-webkit-text-size-adjust:none;text-decoration:none;word-spacing:.06em;letter-spacing:.04em}.link[data-v-2c0d40b1],p[data-v-2c0d40b1]{font-style:inherit}.link[data-v-2c0d40b1]{color:#000;text-align:center;font-size:2.6em;line-height:1;margin-top:1rem}.link a[data-v-2c0d40b1]{color:#224a49;transition:all .2s ease}.link a[data-v-2c0d40b1]:hover{color:#e53e26}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),
/* 31 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/87ad976.png";

/***/ }),
/* 32 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_vue_loader_lib_index_js_vue_loader_options_loading_vue_vue_type_style_index_0_id_880984f2_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(13);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_vue_loader_lib_index_js_vue_loader_options_loading_vue_vue_type_style_index_0_id_880984f2_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_vue_loader_lib_index_js_vue_loader_options_loading_vue_vue_type_style_index_0_id_880984f2_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_vue_loader_lib_index_js_vue_loader_options_loading_vue_vue_type_style_index_0_id_880984f2_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_vue_loader_lib_index_js_vue_loader_options_loading_vue_vue_type_style_index_0_id_880984f2_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),
/* 33 */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(3);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".opacity[data-v-880984f2]{opacity:1}#hola[data-v-880984f2]{width:100vw;height:100vh;background-color:#252328;position:fixed;z-index:999}#preloader[data-v-880984f2]{position:relative;width:80px;height:80px;top:45%;margin:0 auto}#preloader span[data-v-880984f2]{position:absolute;border:8px solid #ffe066;border-top-color:transparent;border-radius:999px}#preloader span[data-v-880984f2]:first-child{width:80px;height:80px;-webkit-animation:spin-1-data-v-880984f2 2s linear infinite;animation:spin-1-data-v-880984f2 2s linear infinite}#preloader span[data-v-880984f2]:nth-child(2){top:20px;left:20px;width:40px;height:40px;-webkit-animation:spin-2-data-v-880984f2 1s linear infinite;animation:spin-2-data-v-880984f2 1s linear infinite}@-webkit-keyframes spin-1-data-v-880984f2{0%{transform:rotate(1turn);opacity:1}50%{transform:rotate(180deg);opacity:.5}to{transform:rotate(0deg);opacity:1}}@keyframes spin-1-data-v-880984f2{0%{transform:rotate(1turn);opacity:1}50%{transform:rotate(180deg);opacity:.5}to{transform:rotate(0deg);opacity:1}}@-webkit-keyframes spin-2-data-v-880984f2{0%{transform:rotate(0deg);opacity:.5}50%{transform:rotate(180deg);opacity:1}to{transform:rotate(1turn);opacity:.5}}@keyframes spin-2-data-v-880984f2{0%{transform:rotate(0deg);opacity:.5}50%{transform:rotate(180deg);opacity:1}to{transform:rotate(1turn);opacity:.5}}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),
/* 34 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(35);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
__webpack_require__(4).default("2de190f4", content, true)

/***/ }),
/* 35 */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(3);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, "*{-webkit-overflow-scrolling:touch}.fullpage-container{position:relative;width:100%;height:100%;overflow:hidden}.fullpage-wp{display:flex;width:100%;height:100%;flex-flow:column nowrap;justify-content:flex-start;align-items:center}.fullpage-wp.anim{transform:translateZ(0);transition:all .5s ease-out 0s}.fullpage-wp.fullpage-wp-h{display:flex;flex-flow:row nowrap;justify-content:flex-start;align-items:center}.page{box-sizing:border-box;display:block;position:relative;width:100%;height:100%;flex-shrink:0;overflow:hidden}.animated{opacity:1}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),
/* 36 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(37);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
__webpack_require__(4).default("38dfa7e4", content, true)

/***/ }),
/* 37 */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(3);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, "html{line-height:1.15;-webkit-text-size-adjust:100%}body{margin:0}main{display:block}h1{font-size:2em;margin:.67em 0}hr{box-sizing:content-box;height:0;overflow:visible}pre{font-family:monospace,monospace;font-size:1em}a{background-color:transparent}abbr[title]{border-bottom:none;text-decoration:underline;-webkit-text-decoration:underline dotted;text-decoration:underline dotted}b,strong{font-weight:bolder}code,kbd,samp{font-family:monospace,monospace;font-size:1em}small{font-size:80%}sub,sup{font-size:75%;line-height:0;position:relative;vertical-align:baseline}sub{bottom:-.25em}sup{top:-.5em}img{border-style:none}button,input,optgroup,select,textarea{font-family:inherit;font-size:100%;line-height:1.15;margin:0}button,input{overflow:visible}button,select{text-transform:none}[type=button],[type=reset],[type=submit],button{-webkit-appearance:button}[type=button]::-moz-focus-inner,[type=reset]::-moz-focus-inner,[type=submit]::-moz-focus-inner,button::-moz-focus-inner{border-style:none;padding:0}[type=button]:-moz-focusring,[type=reset]:-moz-focusring,[type=submit]:-moz-focusring,button:-moz-focusring{outline:1px dotted ButtonText}fieldset{padding:.35em .75em .625em}legend{box-sizing:border-box;color:inherit;display:table;max-width:100%;padding:0;white-space:normal}progress{vertical-align:baseline}textarea{overflow:auto}[type=checkbox],[type=radio]{box-sizing:border-box;padding:0}[type=number]::-webkit-inner-spin-button,[type=number]::-webkit-outer-spin-button{height:auto}[type=search]{-webkit-appearance:textfield;outline-offset:-2px}[type=search]::-webkit-search-decoration{-webkit-appearance:none}::-webkit-file-upload-button{-webkit-appearance:button;font:inherit}details{display:block}summary{display:list-item}[hidden],template{display:none}blockquote,dd,dl,figure,h1,h2,h3,h4,h5,h6,hr,p,pre{margin:0}button{background-color:transparent;background-image:none}button:focus{outline:1px dotted;outline:5px auto -webkit-focus-ring-color}fieldset,ol,ul{margin:0;padding:0}ol,ul{list-style:none}html{font-family:Barlow Condensed,Mulish,Merriweather,Satisfy;line-height:1.5}*,:after,:before{box-sizing:border-box;border:0 solid #e2e8f0}hr{border-top-width:1px}img{border-style:solid}textarea{resize:vertical}input::-moz-placeholder,textarea::-moz-placeholder{color:#a0aec0}input:-ms-input-placeholder,textarea:-ms-input-placeholder{color:#a0aec0}input::placeholder,textarea::placeholder{color:#a0aec0}[role=button],button{cursor:pointer}table{border-collapse:collapse}h1,h2,h3,h4,h5,h6{font-size:inherit;font-weight:inherit}a{color:inherit;text-decoration:inherit}button,input,optgroup,select,textarea{padding:0;line-height:inherit;color:inherit}code,kbd,pre,samp{font-family:SFMono-Regular,Menlo,Monaco,Consolas,\"Liberation Mono\",\"Courier New\",monospace}audio,canvas,embed,iframe,img,object,svg,video{display:block;vertical-align:middle}img,video{max-width:100%;height:auto}*{margin:0;padding:0;box-sizing:border-box}:focus,button:focus{outline:0}*,:active,:focus,:hover,:visited{outline:none}body{height:100%;width:100%;word-spacing:.06em;letter-spacing:.04em}#__layout,body,html{background-color:#faebd7}html{scroll-behavior:smooth}.bg-white{--tw-bg-opacity:1;background-color:rgba(255,255,255,var(--tw-bg-opacity))}figcaption{color:#fff}.bottom-1{bottom:.25rem}.bottom-4{bottom:1rem}.bottom-8{bottom:2rem}.bottom-12{bottom:3rem}.bottom-16{bottom:4rem}.bottom-20{bottom:5rem}.bottom-1\\/20{bottom:5%}.bottom-1\\/2{bottom:50%}.top-2{top:.5rem}.top-4{top:1rem}.top-12{top:3rem}.top-20{top:5.25rem}.top-24{top:5.75rem}.top-28{top:7.25rem}.top-32{top:8.5rem}.top-36{top:10.5rem}.left-2\\/4{left:50%}.left-2{left:.5rem}.left-4{left:1rem}.left-16{left:4rem}.right-1{right:.25rem}.right-2{right:.5rem}.right-4{right:1rem}.right-8{right:2rem}.right-12{right:3rem}.right-28{right:6.5rem}.h-0\\.5{height:.25rem}.h-40,.h-44{height:11rem}.h-48{height:12rem}.h-72{height:18rem}.h-108{height:28rem}.h-112{height:30rem}.h-132{height:36rem}.h-164{height:44rem}.h-1\\/3{height:33%}.h-1\\/2{height:50%}.h-2\\/5{height:40%}.h-3\\/4{height:75%}.max-h-0{max-height:0}.w-36{width:9rem}.w-52{width:13rem}.w-72{width:18rem}.w-80{width:20rem}.w-116{width:32rem}.text-white{--tw-text-opacity:1;color:rgba(255,255,255,var(--tw-text-opacity))}.border-12{border-width:12px}#fp-nav{display:none}.circle1{top:31vh}.circle2{top:33vh}.circle3{top:35vh}[data-anchor=page3]:before{top:5px;left:17px;width:90%}[data-anchor=page3]:after{width:90%;bottom:5px;left:17px}[data-anchor=page3] .bg_stars:before{width:3%;height:95%;left:5px}[data-anchor=page3] .bg_stars:after{width:3%;height:95%;right:5px}.hat{-webkit-animation:matrix 7s ease infinite;animation:matrix 7s ease infinite}.hat,.logo{top:2rem}@media (min-width:480px){[data-anchor=page3]:before{top:5px;left:15px;width:95%}[data-anchor=page3]:after{width:95%;bottom:5px;left:15px}[data-anchor=page3] .bg_stars:before{width:3%;height:90%;left:5px;top:18px}[data-anchor=page3] .bg_stars:after{right:5px;width:3%;height:90%;top:18px}.section-1 img:first-child{top:.5rem}.light_background{width:200vw}}@media (min-width:768px){[data-anchor=page3]:before{top:5px;left:15px;width:96%}[data-anchor=page3]:after{left:16px;width:96%;bottom:5px}[data-anchor=page3] .bg_stars:before{width:3%;height:96%;left:5px;top:25px}[data-anchor=page3] .bg_stars:after{right:5px;width:3%;height:96%;top:25px}[data-anchor=page1] .light_background{width:200vw}[data-anchor=page2] .welcome_studio div span:after{height:18px}[data-anchor=page4] article div span:after{height:18px!important}#form{--ratio:9/16;--width:98vmin;--height:calc(var(--width)*var(--ratio));margin:0 auto;width:90vmin;height:70vh;display:flex;flex-direction:column}#form input{height:5vh}#form textarea{height:20vh}}@media (min-width:1024px){.slide{height:50vh}}@media (min-width:1280px){.ribbon figcaption{font-size:1.2vw}.hat{top:4rem}.logo{top:7rem}#form{height:100vh}.circle1{top:31vh;left:50vw}.circle2{top:33vh;left:48vw}.circle3{top:35vh;left:47vw}[data-anchor=page3]:before{top:5px;left:10px;width:98%}[data-anchor=page3]:after{left:10px;width:98%;bottom:5px}[data-anchor=page3] .bg_stars:before{width:3%;height:95%;left:5px;top:18px}[data-anchor=page3] .bg_stars:after{right:5px;width:3%;height:95%;top:18px}#fp-nav{display:block}#fp-nav ul li a span,.fp-slidesNav ul li a span{height:12px!important;width:12px!important;margin:-2px 0 0 -7px!important;transition:all .3s ease-in-out!important;background-color:#333!important}#fp-nav ul li,.fp-slidesNav ul li{display:block;width:25px;height:65px!important;margin:5px!important;position:relative}#fp-nav ul li:hover a.active span,#fp-nav ul li a.active span,.fp-slidesNav ul li:hover a.active span,.fp-slidesNav ul li a.active span{height:30px!important;width:30px!important;margin:-16px 0 0 -16px!important;border-radius:100%}#fp-nav ul li:hover a span,.fp-slidesNav ul li:hover a span{width:20px!important;height:20px!important;margin:-7px 0 0 -11px!important;background:#a1362b!important}#fp-nav ul li:hover a.active span,#fp-nav ul li a.active span,.fp-slidesNav ul li:hover a.active span,.fp-slidesNav ul li a.active span{background:#a1362b!important}#fp-nav ul li:focus:before{display:inline-table;transition:border-top-color .15s linear,border-right-color .15s linear .1s,border-bottom-color .15s linear .2s}.fp-slidesNav ul li:focus:after{border-left-width:2px;border-right-width:2px;transform:rotate(270deg);transition:transform .4s linear 0s,border-left-width 0s linear .35s;background:green!important}.wolf{bottom:4rem}.home{height:100vh;position:relative;background-color:#faebd7;display:flex;justify-content:center;align-items:center}.home:before{left:0}.home:after,.home:before{position:absolute;width:50%;height:100%;z-index:10;top:0;content:\"\";background-color:#faebd7}.home:after{right:0}.animate-border{border-left:60px solid #faebd7;border-right:60px solid #faebd7;transition:border .5s ease .2s}.home.divide:after,.home.divide:before{transition:all .6s cubic-bezier(.645,.045,.355,1) 1.2s;width:0}}@media (min-width:1536px){.ribbon figcaption{font-size:1.4vw}[data-anchor=page2] .welcome_studio>div>span:after{height:15px!important}.about_me span:after,.portfolio_case span:after{height:20px!important}#form{height:90vh}.circle1{left:48vw;top:31vh}.circle2{left:48.5vw;top:33vh}.circle3{left:49vw;top:34.5vh}[data-anchor=page3]:before{bottom:14px;width:97.8%;left:18px;height:16px;top:auto}[data-anchor=page3]:after{top:6px;width:97.6%;height:15px;left:18px}[data-anchor=page3] .bg_stars:before{top:20px;width:15px;left:10px;height:95%}[data-anchor=page3] .bg_stars:after{top:20px;width:15px;right:13px;height:95%}}@-webkit-keyframes rotate{to{transform:rotate(1turn)}}@keyframes rotate{to{transform:rotate(1turn)}}@-webkit-keyframes matrix{0%{transform:translateX(5%)}25%{transform:translateY(-5%)}50%{transform:translateX(-5%)}75%{transform:translateY(5%)}to{transform:translateX(5%)}}@keyframes matrix{0%{transform:translateX(5%)}25%{transform:translateY(-5%)}50%{transform:translateX(-5%)}75%{transform:translateY(5%)}to{transform:translateX(5%)}}.spiral-enter-active{animation:spiral 1s reverse}.spiral-leave-active{-webkit-animation:spiral 1s;animation:spiral 1s}@-webkit-keyframes spiral{0%{-webkit-clip-path:polygon(0 0,100% 0,100% 100%,0 100%,0 25%,75% 25%,75% 75%,25% 75%,25% 50%,50% 50%,25% 50%,25% 75%,75% 75%,75% 25%,0 25%);clip-path:polygon(0 0,100% 0,100% 100%,0 100%,0 25%,75% 25%,75% 75%,25% 75%,25% 50%,50% 50%,25% 50%,25% 75%,75% 75%,75% 25%,0 25%)}14.25%{-webkit-clip-path:polygon(0 0,100% 0,100% 100%,0 100%,0 25%,75% 25%,75% 75%,50% 75%,50% 50%,50% 50%,25% 50%,25% 75%,75% 75%,75% 25%,0 25%);clip-path:polygon(0 0,100% 0,100% 100%,0 100%,0 25%,75% 25%,75% 75%,50% 75%,50% 50%,50% 50%,25% 50%,25% 75%,75% 75%,75% 25%,0 25%)}28.5%{-webkit-clip-path:polygon(0 0,100% 0,100% 100%,0 100%,0 25%,75% 25%,75% 50%,50% 50%,50% 50%,50% 50%,25% 50%,25% 75%,75% 75%,75% 25%,0 25%);clip-path:polygon(0 0,100% 0,100% 100%,0 100%,0 25%,75% 25%,75% 50%,50% 50%,50% 50%,50% 50%,25% 50%,25% 75%,75% 75%,75% 25%,0 25%)}42.75%{-webkit-clip-path:polygon(0 0,100% 0,100% 100%,0 100%,0 25%,25% 25%,25% 50%,25% 50%,25% 50%,25% 50%,25% 50%,25% 75%,75% 75%,75% 25%,0 25%);clip-path:polygon(0 0,100% 0,100% 100%,0 100%,0 25%,25% 25%,25% 50%,25% 50%,25% 50%,25% 50%,25% 50%,25% 75%,75% 75%,75% 25%,0 25%)}57%{-webkit-clip-path:polygon(0 0,100% 0,100% 100%,0 100%,0 75%,25% 75%,25% 75%,25% 75%,25% 75%,25% 75%,25% 75%,25% 75%,75% 75%,75% 25%,0 25%);clip-path:polygon(0 0,100% 0,100% 100%,0 100%,0 75%,25% 75%,25% 75%,25% 75%,25% 75%,25% 75%,25% 75%,25% 75%,75% 75%,75% 25%,0 25%)}71.25%{-webkit-clip-path:polygon(0 0,100% 0,100% 100%,75% 100%,75% 75%,75% 75%,75% 75%,75% 75%,75% 75%,75% 75%,75% 75%,75% 75%,75% 75%,75% 25%,0 25%);clip-path:polygon(0 0,100% 0,100% 100%,75% 100%,75% 75%,75% 75%,75% 75%,75% 75%,75% 75%,75% 75%,75% 75%,75% 75%,75% 75%,75% 25%,0 25%)}85.5%{-webkit-clip-path:polygon(0 0,100% 0,100% 25%,75% 25%,75% 25%,75% 25%,75% 25%,75% 25%,75% 25%,75% 25%,75% 25%,75% 25%,75% 25%,75% 25%,0 25%);clip-path:polygon(0 0,100% 0,100% 25%,75% 25%,75% 25%,75% 25%,75% 25%,75% 25%,75% 25%,75% 25%,75% 25%,75% 25%,75% 25%,75% 25%,0 25%)}to{-webkit-clip-path:polygon(0 0,0 0,0 0,0 0,0 0,0 0,0 0,0 0,0 25%,0 25%,0 25%,0 25%,0 25%,0 25%,0 25%);clip-path:polygon(0 0,0 0,0 0,0 0,0 0,0 0,0 0,0 0,0 25%,0 25%,0 25%,0 25%,0 25%,0 25%,0 25%)}}@keyframes spiral{0%{-webkit-clip-path:polygon(0 0,100% 0,100% 100%,0 100%,0 25%,75% 25%,75% 75%,25% 75%,25% 50%,50% 50%,25% 50%,25% 75%,75% 75%,75% 25%,0 25%);clip-path:polygon(0 0,100% 0,100% 100%,0 100%,0 25%,75% 25%,75% 75%,25% 75%,25% 50%,50% 50%,25% 50%,25% 75%,75% 75%,75% 25%,0 25%)}14.25%{-webkit-clip-path:polygon(0 0,100% 0,100% 100%,0 100%,0 25%,75% 25%,75% 75%,50% 75%,50% 50%,50% 50%,25% 50%,25% 75%,75% 75%,75% 25%,0 25%);clip-path:polygon(0 0,100% 0,100% 100%,0 100%,0 25%,75% 25%,75% 75%,50% 75%,50% 50%,50% 50%,25% 50%,25% 75%,75% 75%,75% 25%,0 25%)}28.5%{-webkit-clip-path:polygon(0 0,100% 0,100% 100%,0 100%,0 25%,75% 25%,75% 50%,50% 50%,50% 50%,50% 50%,25% 50%,25% 75%,75% 75%,75% 25%,0 25%);clip-path:polygon(0 0,100% 0,100% 100%,0 100%,0 25%,75% 25%,75% 50%,50% 50%,50% 50%,50% 50%,25% 50%,25% 75%,75% 75%,75% 25%,0 25%)}42.75%{-webkit-clip-path:polygon(0 0,100% 0,100% 100%,0 100%,0 25%,25% 25%,25% 50%,25% 50%,25% 50%,25% 50%,25% 50%,25% 75%,75% 75%,75% 25%,0 25%);clip-path:polygon(0 0,100% 0,100% 100%,0 100%,0 25%,25% 25%,25% 50%,25% 50%,25% 50%,25% 50%,25% 50%,25% 75%,75% 75%,75% 25%,0 25%)}57%{-webkit-clip-path:polygon(0 0,100% 0,100% 100%,0 100%,0 75%,25% 75%,25% 75%,25% 75%,25% 75%,25% 75%,25% 75%,25% 75%,75% 75%,75% 25%,0 25%);clip-path:polygon(0 0,100% 0,100% 100%,0 100%,0 75%,25% 75%,25% 75%,25% 75%,25% 75%,25% 75%,25% 75%,25% 75%,75% 75%,75% 25%,0 25%)}71.25%{-webkit-clip-path:polygon(0 0,100% 0,100% 100%,75% 100%,75% 75%,75% 75%,75% 75%,75% 75%,75% 75%,75% 75%,75% 75%,75% 75%,75% 75%,75% 25%,0 25%);clip-path:polygon(0 0,100% 0,100% 100%,75% 100%,75% 75%,75% 75%,75% 75%,75% 75%,75% 75%,75% 75%,75% 75%,75% 75%,75% 75%,75% 25%,0 25%)}85.5%{-webkit-clip-path:polygon(0 0,100% 0,100% 25%,75% 25%,75% 25%,75% 25%,75% 25%,75% 25%,75% 25%,75% 25%,75% 25%,75% 25%,75% 25%,75% 25%,0 25%);clip-path:polygon(0 0,100% 0,100% 25%,75% 25%,75% 25%,75% 25%,75% 25%,75% 25%,75% 25%,75% 25%,75% 25%,75% 25%,75% 25%,75% 25%,0 25%)}to{-webkit-clip-path:polygon(0 0,0 0,0 0,0 0,0 0,0 0,0 0,0 0,0 25%,0 25%,0 25%,0 25%,0 25%,0 25%,0 25%);clip-path:polygon(0 0,0 0,0 0,0 0,0 0,0 0,0 0,0 0,0 25%,0 25%,0 25%,0 25%,0 25%,0 25%,0 25%)}}.slots,.spotlight{background-color:#000}.slots-enter-active{animation:slots 1s reverse}.slots-leave-active{-webkit-animation:slots 1s 1.5s;animation:slots 1s 1.5s}@-webkit-keyframes slots{0%{-webkit-clip-path:polygon(0 0,14% 0,14% 0,28% 0,28% 0,42% 0,42% 0,56% 0,56% 0,70% 0,70% 0,84% 0,84% 0,100% 0,100% 100%,0 100%);clip-path:polygon(0 0,14% 0,14% 0,28% 0,28% 0,42% 0,42% 0,56% 0,56% 0,70% 0,70% 0,84% 0,84% 0,100% 0,100% 100%,0 100%)}50%{-webkit-clip-path:polygon(0 0,14% 0,14% 100%,28% 100%,28% 0,42% 0,42% 100%,56% 100%,56% 0,70% 0,70% 100%,84% 100%,84% 0,100% 0,100% 100%,0 100%);clip-path:polygon(0 0,14% 0,14% 100%,28% 100%,28% 0,42% 0,42% 100%,56% 100%,56% 0,70% 0,70% 100%,84% 100%,84% 0,100% 0,100% 100%,0 100%)}to{-webkit-clip-path:polygon(0 100%,14% 100%,14% 100%,28% 100%,28% 100%,42% 100%,42% 100%,56% 100%,56% 100%,70% 100%,70% 100%,84% 100%,84% 100%,100% 100%,100% 100%,0 100%);clip-path:polygon(0 100%,14% 100%,14% 100%,28% 100%,28% 100%,42% 100%,42% 100%,56% 100%,56% 100%,70% 100%,70% 100%,84% 100%,84% 100%,100% 100%,100% 100%,0 100%)}}@keyframes slots{0%{-webkit-clip-path:polygon(0 0,14% 0,14% 0,28% 0,28% 0,42% 0,42% 0,56% 0,56% 0,70% 0,70% 0,84% 0,84% 0,100% 0,100% 100%,0 100%);clip-path:polygon(0 0,14% 0,14% 0,28% 0,28% 0,42% 0,42% 0,56% 0,56% 0,70% 0,70% 0,84% 0,84% 0,100% 0,100% 100%,0 100%)}50%{-webkit-clip-path:polygon(0 0,14% 0,14% 100%,28% 100%,28% 0,42% 0,42% 100%,56% 100%,56% 0,70% 0,70% 100%,84% 100%,84% 0,100% 0,100% 100%,0 100%);clip-path:polygon(0 0,14% 0,14% 100%,28% 100%,28% 0,42% 0,42% 100%,56% 100%,56% 0,70% 0,70% 100%,84% 100%,84% 0,100% 0,100% 100%,0 100%)}to{-webkit-clip-path:polygon(0 100%,14% 100%,14% 100%,28% 100%,28% 100%,42% 100%,42% 100%,56% 100%,56% 100%,70% 100%,70% 100%,84% 100%,84% 100%,100% 100%,100% 100%,0 100%);clip-path:polygon(0 100%,14% 100%,14% 100%,28% 100%,28% 100%,42% 100%,42% 100%,56% 100%,56% 100%,70% 100%,70% 100%,84% 100%,84% 100%,100% 100%,100% 100%,0 100%)}}.spotlight-enter-active{animation:spotlight 2s reverse}.spotlight-leave-active{-webkit-animation:spotlight 2s 1.5s;animation:spotlight 2s 1.5s}@-webkit-keyframes spotlight{0%{-webkit-clip-path:circle(100% at 50% 50%);clip-path:circle(100% at 50% 50%)}25%{-webkit-clip-path:circle(20% at 50% 50%);clip-path:circle(20% at 50% 50%)}50%{-webkit-clip-path:circle(20% at 12% 84%);clip-path:circle(20% at 12% 84%)}75%{-webkit-clip-path:circle(20% at 93% 51%);clip-path:circle(20% at 93% 51%)}to{-webkit-clip-path:circle(20% at -30% 20%);clip-path:circle(20% at -30% 20%)}}@keyframes spotlight{0%{-webkit-clip-path:circle(100% at 50% 50%);clip-path:circle(100% at 50% 50%)}25%{-webkit-clip-path:circle(20% at 50% 50%);clip-path:circle(20% at 50% 50%)}50%{-webkit-clip-path:circle(20% at 12% 84%);clip-path:circle(20% at 12% 84%)}75%{-webkit-clip-path:circle(20% at 93% 51%);clip-path:circle(20% at 93% 51%)}to{-webkit-clip-path:circle(20% at -30% 20%);clip-path:circle(20% at -30% 20%)}}@-webkit-keyframes shine{to{left:125%}}@keyframes shine{to{left:125%}}.bg-scroll{background-attachment:scroll}.bg-black{--bg-opacity:1;background-color:#000;background-color:rgba(0,0,0,var(--bg-opacity))}.bg-white{--bg-opacity:1;background-color:#fff;background-color:rgba(255,255,255,var(--bg-opacity))}.bg-none{background-image:none}.bg-center{background-position:50%}.bg-repeat{background-repeat:repeat}.bg-no-repeat{background-repeat:no-repeat}.bg-repeat-round{background-repeat:round}.bg-auto{background-size:auto}.bg-cover{background-size:cover}.rounded-xl{border-radius:.75rem}.rounded-2xl{border-radius:1rem}.rounded-3xl{border-radius:1.5rem}.rounded-4xl{border-radius:2rem}.border-solid{border-style:solid}.border-none{border-style:none}.border-2{border-width:2px}.border{border-width:1px}.box-border{box-sizing:border-box}.box-content{box-sizing:content-box}.cursor-default{cursor:default}.cursor-pointer{cursor:pointer}.block{display:block}.inline-block{display:inline-block}.inline{display:inline}.flex{display:flex}.table{display:table}.grid{display:grid}.hidden{display:none}.flex-row-reverse{flex-direction:row-reverse}.flex-col{flex-direction:column}.flex-wrap{flex-wrap:wrap}.items-end{align-items:flex-end}.items-center{align-items:center}.self-end{align-self:flex-end}.self-center{align-self:center}.justify-items-center{justify-items:center}.justify-start{justify-content:flex-start}.justify-end{justify-content:flex-end}.justify-center{justify-content:center}.justify-between{justify-content:space-between}.justify-around{justify-content:space-around}.justify-evenly{justify-content:space-evenly}.font-sans{font-family:Barlow Condensed,Mulish,Merriweather,Satisfy}.font-medium{font-weight:500}.font-semibold{font-weight:600}.font-bold{font-weight:700}.h-0{height:0}.h-4{height:1rem}.h-8{height:2rem}.h-12{height:3rem}.h-16{height:4rem}.h-20{height:5rem}.h-24{height:6rem}.h-32{height:8rem}.h-56{height:14rem}.h-auto{height:auto}.h-full{height:100%}.h-screen{height:100vh}.text-xs{font-size:.75rem}.text-xl{font-size:1.25rem}.text-2xl{font-size:1.675rem}.text-3xl{font-size:1.875rem}.text-4xl{font-size:2.25rem}.text-5xl{font-size:3rem}.text-6xl{font-size:4rem}.text-8xl{font-size:8rem}.text-9xl{font-size:9rem}.text-10xl{font-size:10rem}.text-11xl{font-size:11rem}.leading-none{line-height:1}.leading-tight{line-height:1.25}.leading-snug{line-height:1.375}.leading-normal{line-height:1.5}.leading-loose{line-height:2}.list-none{list-style-type:none}.m-0{margin:0}.m-2{margin:.5rem}.m-4{margin:1rem}.m-auto{margin:auto}.my-10{margin-top:2.5rem;margin-bottom:2.5rem}.my-auto{margin-top:auto;margin-bottom:auto}.mx-auto{margin-left:auto;margin-right:auto}.mt-0{margin-top:0}.mt-1{margin-top:.25rem}.mb-1{margin-bottom:.25rem}.mt-2{margin-top:.5rem}.ml-2{margin-left:.5rem}.mt-3{margin-top:.75rem}.mt-4{margin-top:1rem}.mb-4{margin-bottom:1rem}.ml-4{margin-left:1rem}.mt-5{margin-top:1.25rem}.mb-5{margin-bottom:1.25rem}.mt-6{margin-top:1.5rem}.ml-6{margin-left:1.5rem}.mt-8{margin-top:2rem}.mb-8{margin-bottom:2rem}.mt-10{margin-top:2.5rem}.mb-10{margin-bottom:2.5rem}.mt-12{margin-top:3rem}.ml-12{margin-left:3rem}.mt-16{margin-top:4rem}.mb-16{margin-bottom:4rem}.mt-20{margin-top:5rem}.mb-20{margin-bottom:5rem}.mb-24{margin-bottom:6rem}.mr-auto{margin-right:auto}.max-w-full{max-width:100%}.min-h-screen{min-height:100vh}.opacity-0{opacity:0}.opacity-100{opacity:1}.outline-none{outline:2px solid transparent;outline-offset:2px}.overflow-hidden{overflow:hidden}.overflow-x-hidden{overflow-x:hidden}.p-1{padding:.25rem}.p-2{padding:.5rem}.p-10{padding:2.5rem}.p-20{padding:5rem}.p-24{padding:6rem}.px-0{padding-left:0;padding-right:0}.py-1{padding-top:.25rem;padding-bottom:.25rem}.px-1{padding-left:.25rem;padding-right:.25rem}.py-2{padding-top:.5rem;padding-bottom:.5rem}.px-2{padding-left:.5rem;padding-right:.5rem}.px-3{padding-left:.75rem;padding-right:.75rem}.px-4{padding-left:1rem;padding-right:1rem}.py-6{padding-top:1.5rem;padding-bottom:1.5rem}.px-12{padding-left:3rem;padding-right:3rem}.px-16{padding-left:4rem;padding-right:4rem}.pt-1{padding-top:.25rem}.pb-1{padding-bottom:.25rem}.pl-1{padding-left:.25rem}.pt-2{padding-top:.5rem}.pb-2{padding-bottom:.5rem}.pl-2{padding-left:.5rem}.pt-4{padding-top:1rem}.pt-5{padding-top:1.25rem}.pr-5{padding-right:1.25rem}.pb-5{padding-bottom:1.25rem}.pb-8{padding-bottom:2rem}.pb-10{padding-bottom:2.5rem}.pb-16{padding-bottom:4rem}.pt-20{padding-top:5rem}.static{position:static}.fixed{position:fixed}.absolute{position:absolute}.relative{position:relative}.right-0{right:0}.bottom-0{bottom:0}.left-0{left:0}.resize-none{resize:none}.text-left{text-align:left}.text-center{text-align:center}.text-white{--text-opacity:1;color:#fff;color:rgba(255,255,255,var(--text-opacity))}.italic{font-style:italic}.uppercase{text-transform:uppercase}.tracking-widest{letter-spacing:.45em}.align-middle{vertical-align:middle}.w-2{width:.5rem}.w-4{width:1rem}.w-8{width:2rem}.w-20{width:5rem}.w-auto{width:auto}.w-1\\/2{width:50%}.w-1\\/3{width:33.333333%}.w-2\\/3{width:66.666667%}.w-3\\/4{width:75%}.w-2\\/5{width:40%}.w-3\\/5{width:60%}.w-4\\/5{width:80%}.w-4\\/12{width:33.333333%}.w-5\\/12{width:41.666667%}.w-7\\/12{width:58.333333%}.w-8\\/12{width:66.666667%}.w-9\\/12{width:75%}.w-10\\/12{width:83.333333%}.w-11\\/12{width:91.666667%}.w-full{width:100%}.w-screen{width:100vw}.z-0{z-index:0}.z-10{z-index:10}.z-20{z-index:20}.z-30{z-index:30}.z-40{z-index:40}.z-50{z-index:50}.gap-x-0{grid-column-gap:0;-moz-column-gap:0;column-gap:0}.gap-y-16{grid-row-gap:4rem;row-gap:4rem}.grid-cols-1{grid-template-columns:repeat(1,minmax(0,1fr))}.grid-cols-2{grid-template-columns:repeat(2,minmax(0,1fr))}.grid-cols-3{grid-template-columns:repeat(3,minmax(0,1fr))}.grid-rows-2{grid-template-rows:repeat(2,minmax(0,1fr))}.transform{--transform-translate-x:0;--transform-translate-y:0;--transform-rotate:0;--transform-skew-x:0;--transform-skew-y:0;--transform-scale-x:1;--transform-scale-y:1;transform:translateX(var(--transform-translate-x)) translateY(var(--transform-translate-y)) rotate(var(--transform-rotate)) skewX(var(--transform-skew-x)) skewY(var(--transform-skew-y)) scaleX(var(--transform-scale-x)) scaleY(var(--transform-scale-y))}.-translate-x-1\\/2{--transform-translate-x:-50%}.transition-all{transition-property:all}.transition{transition-property:background-color,border-color,color,fill,stroke,opacity,box-shadow,transform}.ease-in{transition-timing-function:cubic-bezier(.4,0,1,1)}.ease-out{transition-timing-function:cubic-bezier(0,0,.2,1)}.ease-in-out{transition-timing-function:cubic-bezier(.4,0,.2,1)}@-webkit-keyframes spin{to{transform:rotate(1turn)}}@keyframes spin{to{transform:rotate(1turn)}}@-webkit-keyframes ping{75%,to{transform:scale(2);opacity:0}}@keyframes ping{75%,to{transform:scale(2);opacity:0}}@-webkit-keyframes pulse{50%{opacity:.5}}@keyframes pulse{50%{opacity:.5}}@-webkit-keyframes bounce{0%,to{transform:translateY(-25%);-webkit-animation-timing-function:cubic-bezier(.8,0,1,1);animation-timing-function:cubic-bezier(.8,0,1,1)}50%{transform:none;-webkit-animation-timing-function:cubic-bezier(0,0,.2,1);animation-timing-function:cubic-bezier(0,0,.2,1)}}@keyframes bounce{0%,to{transform:translateY(-25%);-webkit-animation-timing-function:cubic-bezier(.8,0,1,1);animation-timing-function:cubic-bezier(.8,0,1,1)}50%{transform:none;-webkit-animation-timing-function:cubic-bezier(0,0,.2,1);animation-timing-function:cubic-bezier(0,0,.2,1)}}.filter-shadow-black{filter:drop-shadow(.35rem .35rem .4rem rgba(0,0,0,.5))}.filter-shadow-green{filter:drop-shadow(5px 6px 0 #4f7b70)}@media (min-width:480px){.sm\\:block{display:block}.sm\\:flex{display:flex}.sm\\:hidden{display:none}.sm\\:flex-row{flex-direction:row}.sm\\:self-start{align-self:flex-start}.sm\\:self-center{align-self:center}.sm\\:justify-end{justify-content:flex-end}.sm\\:justify-center{justify-content:center}.sm\\:h-8{height:2rem}.sm\\:h-20{height:5rem}.sm\\:h-24{height:6rem}.sm\\:h-auto{height:auto}.sm\\:text-xl{font-size:1.25rem}.sm\\:text-2xl{font-size:1.675rem}.sm\\:mt-2{margin-top:.5rem}.sm\\:mb-3{margin-bottom:.75rem}.sm\\:mt-4{margin-top:1rem}.sm\\:ml-5{margin-left:1.25rem}.sm\\:ml-10{margin-left:2.5rem}.sm\\:tracking-wide{letter-spacing:.15em}.sm\\:w-32{width:8rem}.sm\\:w-1\\/2{width:50%}.sm\\:w-1\\/3{width:33.333333%}.sm\\:w-1\\/4{width:25%}.sm\\:w-2\\/5{width:40%}.sm\\:w-full{width:100%}}@media (min-width:768px){.md\\:block{display:block}.md\\:hidden{display:none}.md\\:flex-col{flex-direction:column}.md\\:self-center{align-self:center}.md\\:justify-start{justify-content:flex-start}.md\\:h-16{height:4rem}.md\\:h-24{height:6rem}.md\\:text-xl{font-size:1.25rem}.md\\:text-2xl{font-size:1.675rem}.md\\:text-3xl{font-size:1.875rem}.md\\:text-4xl{font-size:2.25rem}.md\\:text-5xl{font-size:3rem}.md\\:text-6xl{font-size:4rem}.md\\:mt-0{margin-top:0}.md\\:ml-3{margin-left:.75rem}.md\\:mt-4{margin-top:1rem}.md\\:px-0{padding-left:0;padding-right:0}.md\\:absolute{position:absolute}.md\\:text-left{text-align:left}.md\\:tracking-widest{letter-spacing:.45em}.md\\:visible{visibility:visible}.md\\:w-20{width:5rem}.md\\:w-40{width:10rem}.md\\:w-1\\/2{width:50%}.md\\:w-2\\/3{width:66.666667%}.md\\:w-full{width:100%}.md\\:w-screen{width:100vw}}@media (min-width:1024px){.lg\\:block{display:block}.lg\\:inline{display:inline}.lg\\:flex{display:flex}.lg\\:hidden{display:none}.lg\\:flex-col{flex-direction:column}.lg\\:justify-center{justify-content:center}.lg\\:justify-evenly{justify-content:space-evenly}.lg\\:h-32{height:8rem}.lg\\:h-64{height:16rem}.lg\\:h-full{height:100%}.lg\\:text-xl{font-size:1.25rem}.lg\\:text-2xl{font-size:1.675rem}.lg\\:text-3xl{font-size:1.875rem}.lg\\:text-5xl{font-size:3rem}.lg\\:text-10xl{font-size:10rem}.lg\\:mb-5{margin-bottom:1.25rem}.lg\\:ml-6{margin-left:1.5rem}.lg\\:mt-16{margin-top:4rem}.lg\\:-mb-8{margin-bottom:-2rem}.lg\\:pr-2{padding-right:.5rem}.lg\\:pt-12{padding-top:3rem}.lg\\:pl-16{padding-left:4rem}.lg\\:pb-32{padding-bottom:8rem}.lg\\:absolute{position:absolute}.lg\\:relative{position:relative}.lg\\:text-center{text-align:center}.lg\\:w-1\\/2{width:50%}.lg\\:w-1\\/3{width:33.333333%}.lg\\:w-2\\/3{width:66.666667%}.lg\\:w-1\\/4{width:25%}.lg\\:w-3\\/4{width:75%}.lg\\:w-5\\/12{width:41.666667%}.lg\\:w-full{width:100%}}@media (min-width:1280px){.xl\\:border-purple-700{--border-opacity:1;border-color:#6b46c1;border-color:rgba(107,70,193,var(--border-opacity))}.xl\\:rounded-4xl{border-radius:2rem}.xl\\:block{display:block}.xl\\:flex{display:flex}.xl\\:hidden{display:none}.xl\\:flex-row{flex-direction:row}.xl\\:flex-row-reverse{flex-direction:row-reverse}.xl\\:justify-center{justify-content:center}.xl\\:h-12{height:3rem}.xl\\:text-xs{font-size:.75rem}.xl\\:text-xl{font-size:1.25rem}.xl\\:text-2xl{font-size:1.675rem}.xl\\:text-3xl{font-size:1.875rem}.xl\\:text-4xl{font-size:2.25rem}.xl\\:text-7xl{font-size:5rem}.xl\\:mt-0{margin-top:0}.xl\\:mt-2{margin-top:.5rem}.xl\\:ml-2{margin-left:.5rem}.xl\\:mt-4{margin-top:1rem}.xl\\:mt-5{margin-top:1.25rem}.xl\\:mb-5{margin-bottom:1.25rem}.xl\\:mt-10{margin-top:2.5rem}.xl\\:mt-16{margin-top:4rem}.xl\\:max-w-full{max-width:100%}.xl\\:p-2{padding:.5rem}.xl\\:text-center{text-align:center}.xl\\:tracking-wider{letter-spacing:.35em}.xl\\:w-1\\/2{width:50%}.xl\\:w-2\\/3{width:66.666667%}.xl\\:w-1\\/4{width:25%}.xl\\:w-3\\/4{width:75%}.xl\\:w-1\\/5{width:20%}.xl\\:w-2\\/5{width:40%}.xl\\:w-7\\/12{width:58.333333%}.xl\\:w-full{width:100%}}@media (min-width:1536px){.\\32xl\\:block{display:block}.\\32xl\\:flex{display:flex}.\\32xl\\:self-start{align-self:flex-start}.\\32xl\\:self-end{align-self:flex-end}.\\32xl\\:self-stretch{align-self:stretch}.\\32xl\\:font-bold{font-weight:700}.\\32xl\\:h-12{height:3rem}.\\32xl\\:h-40{height:10rem}.\\32xl\\:h-auto{height:auto}.\\32xl\\:text-xl{font-size:1.25rem}.\\32xl\\:text-2xl{font-size:1.675rem}.\\32xl\\:text-3xl{font-size:1.875rem}.\\32xl\\:text-4xl{font-size:2.25rem}.\\32xl\\:text-5xl{font-size:3rem}.\\32xl\\:text-9xl{font-size:9rem}.\\32xl\\:text-10xl{font-size:10rem}.\\32xl\\:text-11xl{font-size:11rem}.\\32xl\\:m-auto{margin:auto}.\\32xl\\:mt-0{margin-top:0}.\\32xl\\:mb-0{margin-bottom:0}.\\32xl\\:mb-1{margin-bottom:.25rem}.\\32xl\\:mt-2{margin-top:.5rem}.\\32xl\\:ml-2{margin-left:.5rem}.\\32xl\\:mt-3{margin-top:.75rem}.\\32xl\\:mr-3{margin-right:.75rem}.\\32xl\\:mb-3{margin-bottom:.75rem}.\\32xl\\:mt-4{margin-top:1rem}.\\32xl\\:mt-5{margin-top:1.25rem}.\\32xl\\:mt-6{margin-top:1.5rem}.\\32xl\\:ml-6{margin-left:1.5rem}.\\32xl\\:mt-8{margin-top:2rem}.\\32xl\\:mt-16{margin-top:4rem}.\\32xl\\:mt-20{margin-top:5rem}.\\32xl\\:mb-24{margin-bottom:6rem}.\\32xl\\:ml-24{margin-left:6rem}.\\32xl\\:max-w-lg{max-width:32rem}.\\32xl\\:p-1{padding:.25rem}.\\32xl\\:p-2{padding:.5rem}.\\32xl\\:p-3{padding:.75rem}.\\32xl\\:p-4{padding:1rem}.\\32xl\\:p-5{padding:1.25rem}.\\32xl\\:pt-3{padding-top:.75rem}.\\32xl\\:pb-12{padding-bottom:3rem}.\\32xl\\:pt-16{padding-top:4rem}.\\32xl\\:pb-16{padding-bottom:4rem}.\\32xl\\:pb-20{padding-bottom:5rem}.\\32xl\\:pl-24{padding-left:6rem}.\\32xl\\:absolute{position:absolute}.\\32xl\\:relative{position:relative}.\\32xl\\:top-0{top:0}.\\32xl\\:right-0{right:0}.\\32xl\\:bottom-0{bottom:0}.\\32xl\\:text-center{text-align:center}.\\32xl\\:tracking-wide{letter-spacing:.15em}.\\32xl\\:tracking-wider{letter-spacing:.35em}.\\32xl\\:tracking-widest{letter-spacing:.45em}.\\32xl\\:w-16{width:4rem}.\\32xl\\:w-20{width:5rem}.\\32xl\\:w-40{width:10rem}.\\32xl\\:w-1\\/2{width:50%}.\\32xl\\:w-1\\/3{width:33.333333%}.\\32xl\\:w-2\\/3{width:66.666667%}.\\32xl\\:w-1\\/4{width:25%}.\\32xl\\:w-1\\/12{width:8.333333%}.\\32xl\\:w-3\\/12{width:25%}.\\32xl\\:w-9\\/12{width:75%}.\\32xl\\:w-full{width:100%}}@media (orientation:portrait){.portrait\\:w-1\\/2{width:50%}}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),
/* 38 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_vue_loader_lib_index_js_vue_loader_options_navigation_vue_vue_type_style_index_0_id_9f8a126e_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(14);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_vue_loader_lib_index_js_vue_loader_options_navigation_vue_vue_type_style_index_0_id_9f8a126e_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_vue_loader_lib_index_js_vue_loader_options_navigation_vue_vue_type_style_index_0_id_9f8a126e_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_vue_loader_lib_index_js_vue_loader_options_navigation_vue_vue_type_style_index_0_id_9f8a126e_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_vue_loader_lib_index_js_vue_loader_options_navigation_vue_vue_type_style_index_0_id_9f8a126e_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),
/* 39 */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(3);
var ___CSS_LOADER_GET_URL_IMPORT___ = __webpack_require__(9);
var ___CSS_LOADER_URL_IMPORT_0___ = __webpack_require__(40);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
var ___CSS_LOADER_URL_REPLACEMENT_0___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_0___);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".spin[data-v-9f8a126e]{position:absolute}.spin[data-v-9f8a126e]:hover{color:#0eb7da}.spin[data-v-9f8a126e]:before{border:2px solid transparent}.spin[data-v-9f8a126e]:hover:before{border-top-color:#0eb7da;border-right-color:#0eb7da;border-bottom-color:#0eb7da;display:inline-table;transition:border-top-color .15s linear,border-right-color .15s linear .1s,border-bottom-color .15s linear .2s}.spin[data-v-9f8a126e]:after{border:0 solid transparent}.spin[data-v-9f8a126e]:hover:after{border-top:2px solid #0eb7da;border-left-width:2px;border-right-width:2px;transform:rotate(270deg);transition:transform .4s linear 0s,border-left-width 0s linear .35s}.spin[data-v-9f8a126e]:focus{border-top-color:#0eb7da;border-right-color:#0eb7da;border-bottom-color:#0eb7da;display:inline-table;transition:border-top-color .15s linear,border-right-color .15s linear .1s,border-bottom-color .15s linear .2s}.circle[data-v-9f8a126e]{box-shadow:none}.circle[data-v-9f8a126e],.circle[data-v-9f8a126e]:after,.circle[data-v-9f8a126e]:before{border-radius:100%}input[data-v-9f8a126e]{display:none}label[data-v-9f8a126e]{cursor:pointer}.bevel[data-v-9f8a126e]{z-index:100;display:flex;align-items:center;justify-content:center;position:relative;padding:0 26px;height:46px;background:#f33 linear-gradient(180deg,#f33 50%,#d11515 0);border-radius:0;box-shadow:0 15px 25px -10px rgba(0,0,0,.5),inset 0 0 0 0 rgba(255,51,51,0),inset 0 -27px 0 0 #d11515;font-size:20px;text-align:center;text-shadow:0 3px 5px #d11515,0 5px 10px #d11515,0 5px 10px #d11515,0 5px 10px #d11515,0 5px 10px #d11515;color:#fff;font-family:Merriweather,sans-serif;letter-spacing:.4px;overflow:hidden;outline:0!important;transform:scale(1.01);transition:all .2s ease-in-out}.bevel[data-v-9f8a126e]:after,.bevel[data-v-9f8a126e]:before{content:\" \";width:27px;max-width:50%;height:100%;position:absolute;top:0;transition-delay:.15s}.bevel[data-v-9f8a126e]:before{left:0;background:linear-gradient(45deg,transparent 66.66667%,#f33 66.66667%),linear-gradient(-45deg,#d11515 33.33333%,transparent 33.33333%),linear-gradient(90deg,#f33,#d11515)}.bevel[data-v-9f8a126e]:after{right:0;background:linear-gradient(-45deg,transparent 66.66667%,#f33 66.66667%),linear-gradient(45deg,#d11515 33.33333%,transparent 33.33333%),linear-gradient(270deg,#f33,#d11515)}.bevel[data-v-9f8a126e]:hover{transform:scale(1.07);box-shadow:0 25px 40px -5px rgba(0,0,0,.3),inset 0 0 0 0 rgba(255,51,51,0),inset 0 -27px 0 0 #d11515}input:checked~.bevel[data-v-9f8a126e]{padding:0 18.5px;background:rgba(255,51,51,0);box-shadow:0 5px 15px -5px rgba(0,0,0,.3),inset 0 0 0 4px #f33,inset 0 0 0 0 #d11515;border-radius:10px;font-size:24px;font-weight:700;text-shadow:0 3px 5px rgba(209,21,21,0),0 5px 10px rgba(209,21,21,0),0 5px 10px rgba(209,21,21,0),0 5px 10px rgba(209,21,21,0),0 5px 10px rgba(209,21,21,0);color:#f33;transform:scale(.7) rotate(-6deg);transition-delay:.135s}input:checked~.bevel[data-v-9f8a126e]:after,input:checked~.bevel[data-v-9f8a126e]:before{transition-delay:0s}input:checked~.bevel[data-v-9f8a126e]:before{transform:translateX(-100%)}input:checked~.bevel[data-v-9f8a126e]:after{transform:translateX(100%)}input:checked~.bevel+span[data-v-9f8a126e]{color:rgba(255,51,51,.1875);transform:translateY(56px)}span[data-v-9f8a126e]{display:block;margin-bottom:10px;font-size:32px;font-weight:700;color:#222;z-index:-1;transition-delay:.135s}nav .nav[data-v-9f8a126e]{background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_0___ + ");background-color:#faebd7}nav .nav ul[data-v-9f8a126e]{border-top:2px solid #6eb8b3;border-bottom:2px solid #6eb8b3}nav .nav ul li[data-v-9f8a126e]{align-self:center;width:10vw;height:100%;display:flex;align-items:center}nav .nav ul li a[data-v-9f8a126e]{font-weight:700;color:#224a49;text-transform:uppercase;filter:drop-shadow(2px 2px 0 rgba(229,62,38,.27))}nav .nav ul li[data-v-9f8a126e] :focus,nav .nav ul li[data-v-9f8a126e] :hover{transition:all .3s ease;color:#e53e26}nav .nav ul li[data-v-9f8a126e] :before{border:2px solid transparent}nav .nav ul li[data-v-9f8a126e] :focus:before{border-top-color:#0eb7da;border-right-color:#0eb7da;border-bottom-color:#0eb7da;display:inline-table;transition:border-top-color .15s linear,border-right-color .15s linear .1s,border-bottom-color .15s linear .2s}nav .nav ul li[data-v-9f8a126e] :focus:after{border-top:2px solid #0eb7da;border-left-width:2px;border-right-width:2px;transform:rotate(270deg);transition:transform .4s linear 0s,border-left-width 0s linear .35s}nav .nav ul li[data-v-9f8a126e] :before{padding-right:4vw;margin-right:20px;content:\"★\";color:#6eb8b3}nav .nav ul li[data-v-9f8a126e] :before:first-child{display:none}nav .slidein[data-v-9f8a126e]{right:-100%;box-shadow:1px 1px 10px rgba(0,0,0,.5);transition:all .5s ease-in-out}nav .open[data-v-9f8a126e]{right:0;z-index:10}nav .close-btn[data-v-9f8a126e]{border:none;font-weight:700;font-size:2em;background:transparent;position:absolute;top:0;left:0;height:100%;padding:0 1em}nav button[data-v-9f8a126e]{border-radius:3em;font-size:1.1em}nav h1[data-v-9f8a126e]{font-weight:700}nav h1[data-v-9f8a126e],nav p[data-v-9f8a126e]{font-family:\"Barlow Condensed\",sans-serif}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),
/* 40 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/0e204ce.webp";

/***/ }),
/* 41 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_3_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_3_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_3_oneOf_1_2_node_modules_vue_loader_lib_index_js_vue_loader_options_desktop_vue_vue_type_style_index_0_id_5802eed9_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(15);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_3_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_3_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_3_oneOf_1_2_node_modules_vue_loader_lib_index_js_vue_loader_options_desktop_vue_vue_type_style_index_0_id_5802eed9_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_3_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_3_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_3_oneOf_1_2_node_modules_vue_loader_lib_index_js_vue_loader_options_desktop_vue_vue_type_style_index_0_id_5802eed9_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_3_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_3_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_3_oneOf_1_2_node_modules_vue_loader_lib_index_js_vue_loader_options_desktop_vue_vue_type_style_index_0_id_5802eed9_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_3_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_3_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_3_oneOf_1_2_node_modules_vue_loader_lib_index_js_vue_loader_options_desktop_vue_vue_type_style_index_0_id_5802eed9_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),
/* 42 */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(3);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
// Module
___CSS_LOADER_EXPORT___.push([module.i, "section[data-v-5802eed9]{width:100%}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),
/* 43 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: external "vue"
var external_vue_ = __webpack_require__(0);
var external_vue_default = /*#__PURE__*/__webpack_require__.n(external_vue_);

// EXTERNAL MODULE: external "ufo"
var external_ufo_ = __webpack_require__(1);

// EXTERNAL MODULE: external "node-fetch"
var external_node_fetch_ = __webpack_require__(16);
var external_node_fetch_default = /*#__PURE__*/__webpack_require__.n(external_node_fetch_);

// CONCATENATED MODULE: ./node_modules/.cache/nuxt/middleware.js
const middleware = {};
/* harmony default export */ var nuxt_middleware = (middleware);
// CONCATENATED MODULE: ./node_modules/.cache/nuxt/utils.js

 // window.{{globals.loadedCallback}} hook
// Useful for jsdom testing or plugins (https://github.com/tmpvar/jsdom#dealing-with-asynchronous-script-loading)

if (false) {}

function createGetCounter(counterObject, defaultKey = '') {
  return function getCounter(id = defaultKey) {
    if (counterObject[id] === undefined) {
      counterObject[id] = 0;
    }

    return counterObject[id]++;
  };
}
function empty() {}
function globalHandleError(error) {
  if (external_vue_default.a.config.errorHandler) {
    external_vue_default.a.config.errorHandler(error);
  }
}
function interopDefault(promise) {
  return promise.then(m => m.default || m);
}
function hasFetch(vm) {
  return vm.$options && typeof vm.$options.fetch === 'function' && !vm.$options.fetch.length;
}
function purifyData(data) {
  if (true) {
    return data;
  }

  return Object.entries(data).filter(([key, value]) => {
    const valid = !(value instanceof Function) && !(value instanceof Promise);

    if (!valid) {
      console.warn(`${key} is not able to be stringified. This will break in a production environment.`);
    }

    return valid;
  }).reduce((obj, [key, value]) => {
    obj[key] = value;
    return obj;
  }, {});
}
function getChildrenComponentInstancesUsingFetch(vm, instances = []) {
  const children = vm.$children || [];

  for (const child of children) {
    if (child.$fetch) {
      instances.push(child);
      continue; // Don't get the children since it will reload the template
    }

    if (child.$children) {
      getChildrenComponentInstancesUsingFetch(child, instances);
    }
  }

  return instances;
}
function applyAsyncData(Component, asyncData) {
  if ( // For SSR, we once all this function without second param to just apply asyncData
  // Prevent doing this for each SSR request
  !asyncData && Component.options.__hasNuxtData) {
    return;
  }

  const ComponentData = Component.options._originDataFn || Component.options.data || function () {
    return {};
  };

  Component.options._originDataFn = ComponentData;

  Component.options.data = function () {
    const data = ComponentData.call(this, this);

    if (this.$ssrContext) {
      asyncData = this.$ssrContext.asyncData[Component.cid];
    }

    return { ...data,
      ...asyncData
    };
  };

  Component.options.__hasNuxtData = true;

  if (Component._Ctor && Component._Ctor.options) {
    Component._Ctor.options.data = Component.options.data;
  }
}
function sanitizeComponent(Component) {
  // If Component already sanitized
  if (Component.options && Component._Ctor === Component) {
    return Component;
  }

  if (!Component.options) {
    Component = external_vue_default.a.extend(Component); // fix issue #6

    Component._Ctor = Component;
  } else {
    Component._Ctor = Component;
    Component.extendOptions = Component.options;
  } // If no component name defined, set file path as name, (also fixes #5703)


  if (!Component.options.name && Component.options.__file) {
    Component.options.name = Component.options.__file;
  }

  return Component;
}
function getMatchedComponents(route, matches = false, prop = 'components') {
  return Array.prototype.concat.apply([], route.matched.map((m, index) => {
    return Object.keys(m[prop]).map(key => {
      matches && matches.push(index);
      return m[prop][key];
    });
  }));
}
function getMatchedComponentsInstances(route, matches = false) {
  return getMatchedComponents(route, matches, 'instances');
}
function flatMapComponents(route, fn) {
  return Array.prototype.concat.apply([], route.matched.map((m, index) => {
    return Object.keys(m.components).reduce((promises, key) => {
      if (m.components[key]) {
        promises.push(fn(m.components[key], m.instances[key], m, key, index));
      } else {
        delete m.components[key];
      }

      return promises;
    }, []);
  }));
}
function resolveRouteComponents(route, fn) {
  return Promise.all(flatMapComponents(route, async (Component, instance, match, key) => {
    // If component is a function, resolve it
    if (typeof Component === 'function' && !Component.options) {
      try {
        Component = await Component();
      } catch (error) {
        // Handle webpack chunk loading errors
        // This may be due to a new deployment or a network problem
        if (error && error.name === 'ChunkLoadError' && typeof window !== 'undefined' && window.sessionStorage) {
          const timeNow = Date.now();
          const previousReloadTime = parseInt(window.sessionStorage.getItem('nuxt-reload')); // check for previous reload time not to reload infinitely

          if (!previousReloadTime || previousReloadTime + 60000 < timeNow) {
            window.sessionStorage.setItem('nuxt-reload', timeNow);
            window.location.reload(true
            /* skip cache */
            );
          }
        }

        throw error;
      }
    }

    match.components[key] = Component = sanitizeComponent(Component);
    return typeof fn === 'function' ? fn(Component, instance, match, key) : Component;
  }));
}
async function getRouteData(route) {
  if (!route) {
    return;
  } // Make sure the components are resolved (code-splitting)


  await resolveRouteComponents(route); // Send back a copy of route with meta based on Component definition

  return { ...route,
    meta: getMatchedComponents(route).map((Component, index) => {
      return { ...Component.options.meta,
        ...(route.matched[index] || {}).meta
      };
    })
  };
}
async function setContext(app, context) {
  // If context not defined, create it
  if (!app.context) {
    app.context = {
      isStatic: true,
      isDev: false,
      isHMR: false,
      app,
      payload: context.payload,
      error: context.error,
      base: app.router.options.base,
      env: {}
    }; // Only set once

    if (context.ssrContext) {
      app.context.ssrContext = context.ssrContext;
    }

    app.context.redirect = (status, path, query) => {
      if (!status) {
        return;
      }

      app.context._redirected = true; // if only 1 or 2 arguments: redirect('/') or redirect('/', { foo: 'bar' })

      let pathType = typeof path;

      if (typeof status !== 'number' && (pathType === 'undefined' || pathType === 'object')) {
        query = path || {};
        path = status;
        pathType = typeof path;
        status = 302;
      }

      if (pathType === 'object') {
        path = app.router.resolve(path).route.fullPath;
      } // "/absolute/route", "./relative/route" or "../relative/route"


      if (/(^[.]{1,2}\/)|(^\/(?!\/))/.test(path)) {
        app.context.next({
          path,
          query,
          status
        });
      } else {
        path = Object(external_ufo_["withQuery"])(path, query);

        if (true) {
          app.context.next({
            path,
            status
          });
        }

        if (false) {}
      }
    };

    if (true) {
      app.context.beforeNuxtRender = fn => context.beforeRenderFns.push(fn);
    }

    if (false) {}
  } // Dynamic keys


  const [currentRouteData, fromRouteData] = await Promise.all([getRouteData(context.route), getRouteData(context.from)]);

  if (context.route) {
    app.context.route = currentRouteData;
  }

  if (context.from) {
    app.context.from = fromRouteData;
  }

  app.context.next = context.next;
  app.context._redirected = false;
  app.context._errored = false;
  app.context.isHMR = false;
  app.context.params = app.context.route.params || {};
  app.context.query = app.context.route.query || {};
}
function middlewareSeries(promises, appContext) {
  if (!promises.length || appContext._redirected || appContext._errored) {
    return Promise.resolve();
  }

  return promisify(promises[0], appContext).then(() => {
    return middlewareSeries(promises.slice(1), appContext);
  });
}
function promisify(fn, context) {
  let promise;

  if (fn.length === 2) {
    // fn(context, callback)
    promise = new Promise(resolve => {
      fn(context, function (err, data) {
        if (err) {
          context.error(err);
        }

        data = data || {};
        resolve(data);
      });
    });
  } else {
    promise = fn(context);
  }

  if (promise && promise instanceof Promise && typeof promise.then === 'function') {
    return promise;
  }

  return Promise.resolve(promise);
} // Imported from vue-router

function getLocation(base, mode) {
  if (mode === 'hash') {
    return window.location.hash.replace(/^#\//, '');
  }

  base = decodeURI(base).slice(0, -1); // consideration is base is normalized with trailing slash

  let path = decodeURI(window.location.pathname);

  if (base && path.startsWith(base)) {
    path = path.slice(base.length);
  }

  const fullPath = (path || '/') + window.location.search + window.location.hash;
  return Object(external_ufo_["normalizeURL"])(fullPath);
} // Imported from path-to-regexp

/**
 * Compile a string to a template function for the path.
 *
 * @param  {string}             str
 * @param  {Object=}            options
 * @return {!function(Object=, Object=)}
 */

function compile(str, options) {
  return tokensToFunction(parse(str, options), options);
}
function getQueryDiff(toQuery, fromQuery) {
  const diff = {};
  const queries = { ...toQuery,
    ...fromQuery
  };

  for (const k in queries) {
    if (String(toQuery[k]) !== String(fromQuery[k])) {
      diff[k] = true;
    }
  }

  return diff;
}
function normalizeError(err) {
  let message;

  if (!(err.message || typeof err === 'string')) {
    try {
      message = JSON.stringify(err, null, 2);
    } catch (e) {
      message = `[${err.constructor.name}]`;
    }
  } else {
    message = err.message || err;
  }

  return { ...err,
    message,
    statusCode: err.statusCode || err.status || err.response && err.response.status || 500
  };
}
/**
 * The main path matching regexp utility.
 *
 * @type {RegExp}
 */

const PATH_REGEXP = new RegExp([// Match escaped characters that would otherwise appear in future matches.
// This allows the user to escape special characters that won't transform.
'(\\\\.)', // Match Express-style parameters and un-named parameters with a prefix
// and optional suffixes. Matches appear as:
//
// "/:test(\\d+)?" => ["/", "test", "\d+", undefined, "?", undefined]
// "/route(\\d+)"  => [undefined, undefined, undefined, "\d+", undefined, undefined]
// "/*"            => ["/", undefined, undefined, undefined, undefined, "*"]
'([\\/.])?(?:(?:\\:(\\w+)(?:\\(((?:\\\\.|[^\\\\()])+)\\))?|\\(((?:\\\\.|[^\\\\()])+)\\))([+*?])?|(\\*))'].join('|'), 'g');
/**
 * Parse a string for the raw tokens.
 *
 * @param  {string}  str
 * @param  {Object=} options
 * @return {!Array}
 */

function parse(str, options) {
  const tokens = [];
  let key = 0;
  let index = 0;
  let path = '';
  const defaultDelimiter = options && options.delimiter || '/';
  let res;

  while ((res = PATH_REGEXP.exec(str)) != null) {
    const m = res[0];
    const escaped = res[1];
    const offset = res.index;
    path += str.slice(index, offset);
    index = offset + m.length; // Ignore already escaped sequences.

    if (escaped) {
      path += escaped[1];
      continue;
    }

    const next = str[index];
    const prefix = res[2];
    const name = res[3];
    const capture = res[4];
    const group = res[5];
    const modifier = res[6];
    const asterisk = res[7]; // Push the current path onto the tokens.

    if (path) {
      tokens.push(path);
      path = '';
    }

    const partial = prefix != null && next != null && next !== prefix;
    const repeat = modifier === '+' || modifier === '*';
    const optional = modifier === '?' || modifier === '*';
    const delimiter = res[2] || defaultDelimiter;
    const pattern = capture || group;
    tokens.push({
      name: name || key++,
      prefix: prefix || '',
      delimiter,
      optional,
      repeat,
      partial,
      asterisk: Boolean(asterisk),
      pattern: pattern ? escapeGroup(pattern) : asterisk ? '.*' : '[^' + escapeString(delimiter) + ']+?'
    });
  } // Match any characters still remaining.


  if (index < str.length) {
    path += str.substr(index);
  } // If the path exists, push it onto the end.


  if (path) {
    tokens.push(path);
  }

  return tokens;
}
/**
 * Prettier encoding of URI path segments.
 *
 * @param  {string}
 * @return {string}
 */


function encodeURIComponentPretty(str, slashAllowed) {
  const re = slashAllowed ? /[?#]/g : /[/?#]/g;
  return encodeURI(str).replace(re, c => {
    return '%' + c.charCodeAt(0).toString(16).toUpperCase();
  });
}
/**
 * Encode the asterisk parameter. Similar to `pretty`, but allows slashes.
 *
 * @param  {string}
 * @return {string}
 */


function encodeAsterisk(str) {
  return encodeURIComponentPretty(str, true);
}
/**
 * Escape a regular expression string.
 *
 * @param  {string} str
 * @return {string}
 */


function escapeString(str) {
  return str.replace(/([.+*?=^!:${}()[\]|/\\])/g, '\\$1');
}
/**
 * Escape the capturing group by escaping special characters and meaning.
 *
 * @param  {string} group
 * @return {string}
 */


function escapeGroup(group) {
  return group.replace(/([=!:$/()])/g, '\\$1');
}
/**
 * Expose a method for transforming tokens into the path function.
 */


function tokensToFunction(tokens, options) {
  // Compile all the tokens into regexps.
  const matches = new Array(tokens.length); // Compile all the patterns before compilation.

  for (let i = 0; i < tokens.length; i++) {
    if (typeof tokens[i] === 'object') {
      matches[i] = new RegExp('^(?:' + tokens[i].pattern + ')$', flags(options));
    }
  }

  return function (obj, opts) {
    let path = '';
    const data = obj || {};
    const options = opts || {};
    const encode = options.pretty ? encodeURIComponentPretty : encodeURIComponent;

    for (let i = 0; i < tokens.length; i++) {
      const token = tokens[i];

      if (typeof token === 'string') {
        path += token;
        continue;
      }

      const value = data[token.name || 'pathMatch'];
      let segment;

      if (value == null) {
        if (token.optional) {
          // Prepend partial segment prefixes.
          if (token.partial) {
            path += token.prefix;
          }

          continue;
        } else {
          throw new TypeError('Expected "' + token.name + '" to be defined');
        }
      }

      if (Array.isArray(value)) {
        if (!token.repeat) {
          throw new TypeError('Expected "' + token.name + '" to not repeat, but received `' + JSON.stringify(value) + '`');
        }

        if (value.length === 0) {
          if (token.optional) {
            continue;
          } else {
            throw new TypeError('Expected "' + token.name + '" to not be empty');
          }
        }

        for (let j = 0; j < value.length; j++) {
          segment = encode(value[j]);

          if (!matches[i].test(segment)) {
            throw new TypeError('Expected all "' + token.name + '" to match "' + token.pattern + '", but received `' + JSON.stringify(segment) + '`');
          }

          path += (j === 0 ? token.prefix : token.delimiter) + segment;
        }

        continue;
      }

      segment = token.asterisk ? encodeAsterisk(value) : encode(value);

      if (!matches[i].test(segment)) {
        throw new TypeError('Expected "' + token.name + '" to match "' + token.pattern + '", but received "' + segment + '"');
      }

      path += token.prefix + segment;
    }

    return path;
  };
}
/**
 * Get the flags for a regexp from the options.
 *
 * @param  {Object} options
 * @return {string}
 */


function flags(options) {
  return options && options.sensitive ? '' : 'i';
}

function addLifecycleHook(vm, hook, fn) {
  if (!vm.$options[hook]) {
    vm.$options[hook] = [];
  }

  if (!vm.$options[hook].includes(fn)) {
    vm.$options[hook].push(fn);
  }
}
const urlJoin = external_ufo_["joinURL"];
const stripTrailingSlash = external_ufo_["withoutTrailingSlash"];
const isSamePath = external_ufo_["isSamePath"];
function setScrollRestoration(newVal) {
  try {
    window.history.scrollRestoration = newVal;
  } catch (e) {}
}
// CONCATENATED MODULE: ./node_modules/.cache/nuxt/mixins/fetch.server.js



async function serverPrefetch() {
  if (!this._fetchOnServer) {
    return;
  } // Call and await on $fetch


  try {
    await this.$options.fetch.call(this);
  } catch (err) {
    if (false) {}

    this.$fetchState.error = normalizeError(err);
  }

  this.$fetchState.pending = false; // Define an ssrKey for hydration

  this._fetchKey = this._fetchKey || this.$ssrContext.fetchCounters['']++; // Add data-fetch-key on parent element of Component

  const attrs = this.$vnode.data.attrs = this.$vnode.data.attrs || {};
  attrs['data-fetch-key'] = this._fetchKey; // Add to ssrContext for window.__NUXT__.fetch

  this.$ssrContext.nuxt.fetch[this._fetchKey] = this.$fetchState.error ? {
    _error: this.$fetchState.error
  } : purifyData(this._data);
}

/* harmony default export */ var fetch_server = ({
  created() {
    if (!hasFetch(this)) {
      return;
    }

    if (typeof this.$options.fetchOnServer === 'function') {
      this._fetchOnServer = this.$options.fetchOnServer.call(this) !== false;
    } else {
      this._fetchOnServer = this.$options.fetchOnServer !== false;
    }

    const defaultKey = this.$options._scopeId || this.$options.name || '';
    const getCounter = createGetCounter(this.$ssrContext.fetchCounters, defaultKey);

    if (typeof this.$options.fetchKey === 'function') {
      this._fetchKey = this.$options.fetchKey.call(this, getCounter);
    } else {
      const key = 'string' === typeof this.$options.fetchKey ? this.$options.fetchKey : defaultKey;
      this._fetchKey = key ? key + ':' + getCounter(key) : String(getCounter(key));
    } // Added for remove vue undefined warning while ssr


    this.$fetch = () => {}; // issue #8043


    external_vue_default.a.util.defineReactive(this, '$fetchState', {
      pending: true,
      error: null,
      timestamp: Date.now()
    });
    addLifecycleHook(this, 'serverPrefetch', serverPrefetch);
  }

});
// EXTERNAL MODULE: external "vue-meta"
var external_vue_meta_ = __webpack_require__(17);
var external_vue_meta_default = /*#__PURE__*/__webpack_require__.n(external_vue_meta_);

// EXTERNAL MODULE: external "vue-client-only"
var external_vue_client_only_ = __webpack_require__(7);
var external_vue_client_only_default = /*#__PURE__*/__webpack_require__.n(external_vue_client_only_);

// EXTERNAL MODULE: external "vue-no-ssr"
var external_vue_no_ssr_ = __webpack_require__(6);
var external_vue_no_ssr_default = /*#__PURE__*/__webpack_require__.n(external_vue_no_ssr_);

// EXTERNAL MODULE: external "vue-router"
var external_vue_router_ = __webpack_require__(8);
var external_vue_router_default = /*#__PURE__*/__webpack_require__.n(external_vue_router_);

// CONCATENATED MODULE: ./node_modules/.cache/nuxt/router.scrollBehavior.js


if (false) {}

function shouldScrollToTop(route) {
  const Pages = getMatchedComponents(route);

  if (Pages.length === 1) {
    const {
      options = {}
    } = Pages[0];
    return options.scrollToTop !== false;
  }

  return Pages.some(({
    options
  }) => options && options.scrollToTop);
}

/* harmony default export */ var router_scrollBehavior = (function (to, from, savedPosition) {
  // If the returned position is falsy or an empty object, will retain current scroll position
  let position = false;
  const isRouteChanged = to !== from; // savedPosition is only available for popstate navigations (back button)

  if (savedPosition) {
    position = savedPosition;
  } else if (isRouteChanged && shouldScrollToTop(to)) {
    position = {
      x: 0,
      y: 0
    };
  }

  const nuxt = window.$nuxt;

  if ( // Initial load (vuejs/vue-router#3199)
  !isRouteChanged || // Route hash changes
  to.path === from.path && to.hash !== from.hash) {
    nuxt.$nextTick(() => nuxt.$emit('triggerScroll'));
  }

  return new Promise(resolve => {
    // wait for the out transition to complete (if necessary)
    nuxt.$once('triggerScroll', () => {
      // coords will be used if no selector is provided,
      // or if the selector didn't match any element.
      if (to.hash) {
        let hash = to.hash; // CSS.escape() is not supported with IE and Edge.

        if (typeof window.CSS !== 'undefined' && typeof window.CSS.escape !== 'undefined') {
          hash = '#' + window.CSS.escape(hash.substr(1));
        }

        try {
          if (document.querySelector(hash)) {
            // scroll to anchor by returning the selector
            position = {
              selector: hash
            };
          }
        } catch (e) {
          console.warn('Failed to save scroll position. Please add CSS.escape() polyfill (https://github.com/mathiasbynens/CSS.escape).');
        }
      }

      resolve(position);
    });
  });
});
// CONCATENATED MODULE: ./node_modules/.cache/nuxt/router.js






const _1411701c = () => interopDefault(__webpack_require__.e(/* import() | pages/aboutme */ 1).then(__webpack_require__.bind(null, 115)));

const _a7c70652 = () => interopDefault(__webpack_require__.e(/* import() | pages/contact */ 2).then(__webpack_require__.bind(null, 116)));

const _08087e3f = () => interopDefault(__webpack_require__.e(/* import() | pages/portfolio */ 4).then(__webpack_require__.bind(null, 114)));

const _5120576e = () => interopDefault(__webpack_require__.e(/* import() | pages/index */ 3).then(__webpack_require__.bind(null, 117)));

const emptyFn = () => {};

external_vue_default.a.use(external_vue_router_default.a);
const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior: router_scrollBehavior,
  routes: [{
    path: "/aboutme",
    component: _1411701c,
    name: "aboutme"
  }, {
    path: "/contact",
    component: _a7c70652,
    name: "contact"
  }, {
    path: "/portfolio",
    component: _08087e3f,
    name: "portfolio"
  }, {
    path: "/",
    component: _5120576e,
    name: "index"
  }],
  fallback: false
};
function createRouter(ssrContext, config) {
  const base = config._app && config._app.basePath || routerOptions.base;
  const router = new external_vue_router_default.a({ ...routerOptions,
    base
  }); // TODO: remove in Nuxt 3

  const originalPush = router.push;

  router.push = function push(location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort);
  };

  const resolve = router.resolve.bind(router);

  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = Object(external_ufo_["normalizeURL"])(to);
    }

    return resolve(to, current, append);
  };

  return router;
}
// CONCATENATED MODULE: ./node_modules/.cache/nuxt/components/nuxt-child.js
/* harmony default export */ var nuxt_child = ({
  name: 'NuxtChild',
  functional: true,
  props: {
    nuxtChildKey: {
      type: String,
      default: ''
    },
    keepAlive: Boolean,
    keepAliveProps: {
      type: Object,
      default: undefined
    }
  },

  render(_, {
    parent,
    data,
    props
  }) {
    const h = parent.$createElement;
    data.nuxtChild = true;
    const _parent = parent;
    const transitions = parent.$nuxt.nuxt.transitions;
    const defaultTransition = parent.$nuxt.nuxt.defaultTransition;
    let depth = 0;

    while (parent) {
      if (parent.$vnode && parent.$vnode.data.nuxtChild) {
        depth++;
      }

      parent = parent.$parent;
    }

    data.nuxtChildDepth = depth;
    const transition = transitions[depth] || defaultTransition;
    const transitionProps = {};
    transitionsKeys.forEach(key => {
      if (typeof transition[key] !== 'undefined') {
        transitionProps[key] = transition[key];
      }
    });
    const listeners = {};
    listenersKeys.forEach(key => {
      if (typeof transition[key] === 'function') {
        listeners[key] = transition[key].bind(_parent);
      }
    });

    if (false) {} // make sure that leave is called asynchronous (fix #5703)


    if (transition.css === false) {
      const leave = listeners.leave; // only add leave listener when user didnt provide one
      // or when it misses the done argument

      if (!leave || leave.length < 2) {
        listeners.leave = (el, done) => {
          if (leave) {
            leave.call(_parent, el);
          }

          _parent.$nextTick(done);
        };
      }
    }

    let routerView = h('routerView', data);

    if (props.keepAlive) {
      routerView = h('keep-alive', {
        props: props.keepAliveProps
      }, [routerView]);
    }

    return h('transition', {
      props: transitionProps,
      on: listeners
    }, [routerView]);
  }

});
const transitionsKeys = ['name', 'mode', 'appear', 'css', 'type', 'duration', 'enterClass', 'leaveClass', 'appearClass', 'enterActiveClass', 'enterActiveClass', 'leaveActiveClass', 'appearActiveClass', 'enterToClass', 'leaveToClass', 'appearToClass'];
const listenersKeys = ['beforeEnter', 'enter', 'afterEnter', 'enterCancelled', 'beforeLeave', 'leave', 'afterLeave', 'leaveCancelled', 'beforeAppear', 'appear', 'afterAppear', 'appearCancelled'];
// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./layouts/error.vue?vue&type=template&id=2c0d40b1&scoped=true&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"h-screen w-screen"},[_vm._ssrNode("<header class=\"exclusive-paper container  relative p-24 w-full flex flex-col justify-center grid grid-cols-1 justify-items-center h-112 max-w-full lg:max-w-max  mx-auto filter-shadow-black relative overflow-hidden\" data-v-2c0d40b1>","</header>",[_c('light',{staticClass:"filter-shadow-black overflow-hidden absolute"}),_vm._ssrNode(" <div class=\"title uppercase top-2\" data-v-2c0d40b1><h1 class=\"text-8xl font-semibold text-center uppercase\" data-v-2c0d40b1>ERROR 404\n      </h1></div> <div class=\"title_dividers w-1/2 h-4 mx-auto my-10 relative inline-block\" data-v-2c0d40b1><span class=\"w-full h-0.5 absolute left-2/4 transform -translate-x-1/2\" data-v-2c0d40b1></span> <span class=\"w-full h-0.5 top-2 absolute left-2/4 transform -translate-x-1/2\" data-v-2c0d40b1></span> <span class=\"w-full h-0.5 top-4 absolute left-2/4 transform -translate-x-1/2\" data-v-2c0d40b1></span></div> "),_vm._ssrNode("<figure class=\"relative flex items-center justify-center filter-shadow-black z-10\" data-v-2c0d40b1>","</figure>",[_vm._ssrNode("<img"+(_vm._ssrAttr("data-src",__webpack_require__(20)))+" alt=\"ribbon\" class=\"lazyload w-full h-20 my-auto z-1 filter-shadow-black\" data-v-2c0d40b1> "),_vm._ssrNode("<figcaption class=\"absolute block mx-auto mt-5 text-white text-3xl text-center \" data-v-2c0d40b1>","</figcaption>",[_c('NuxtLink',{attrs:{"to":"/"}},[_vm._v("Home")]),_vm._ssrNode("\n        &gt; Page Not Found\n      ")],2)],2)],2),_vm._ssrNode(" <div data-v-2c0d40b1><div class=\"banner \" data-v-2c0d40b1><img"+(_vm._ssrAttr("src",__webpack_require__(24)))+" alt=\"Error 404\" class=\"m-auto w-1/3\" data-v-2c0d40b1></div> <p data-v-2c0d40b1>Sorry<br data-v-2c0d40b1>\n      This page<br data-v-2c0d40b1>\n      doesn't exist. </p> <div class=\"link\" data-v-2c0d40b1>\n      Please, proceed to our <a href=\"/\" data-v-2c0d40b1>Home page</a></div></div>")],2)}
var staticRenderFns = []


// CONCATENATED MODULE: ./layouts/error.vue?vue&type=template&id=2c0d40b1&scoped=true&

// EXTERNAL MODULE: ./components/light.vue + 4 modules
var light = __webpack_require__(10);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./layouts/error.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var errorvue_type_script_lang_js_ = ({
  components: {
    light: light["a" /* default */]
  },

  data() {
    return {};
  }

});
// CONCATENATED MODULE: ./layouts/error.vue?vue&type=script&lang=js&
 /* harmony default export */ var layouts_errorvue_type_script_lang_js_ = (errorvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(2);

// CONCATENATED MODULE: ./layouts/error.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(29)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var error_component = Object(componentNormalizer["a" /* default */])(
  layouts_errorvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "2c0d40b1",
  "f3a04a0e"
  
)

/* harmony default export */ var layouts_error = (error_component.exports);
// CONCATENATED MODULE: ./node_modules/.cache/nuxt/components/nuxt.js




/* harmony default export */ var components_nuxt = ({
  name: 'Nuxt',
  components: {
    NuxtChild: nuxt_child,
    NuxtError: layouts_error
  },
  props: {
    nuxtChildKey: {
      type: String,
      default: undefined
    },
    keepAlive: Boolean,
    keepAliveProps: {
      type: Object,
      default: undefined
    },
    name: {
      type: String,
      default: 'default'
    }
  },

  errorCaptured(error) {
    // if we receive and error while showing the NuxtError component
    // capture the error and force an immediate update so we re-render
    // without the NuxtError component
    if (this.displayingNuxtError) {
      this.errorFromNuxtError = error;
      this.$forceUpdate();
    }
  },

  computed: {
    routerViewKey() {
      // If nuxtChildKey prop is given or current route has children
      if (typeof this.nuxtChildKey !== 'undefined' || this.$route.matched.length > 1) {
        return this.nuxtChildKey || compile(this.$route.matched[0].path)(this.$route.params);
      }

      const [matchedRoute] = this.$route.matched;

      if (!matchedRoute) {
        return this.$route.path;
      }

      const Component = matchedRoute.components.default;

      if (Component && Component.options) {
        const {
          options
        } = Component;

        if (options.key) {
          return typeof options.key === 'function' ? options.key(this.$route) : options.key;
        }
      }

      const strict = /\/$/.test(matchedRoute.path);
      return strict ? this.$route.path : this.$route.path.replace(/\/$/, '');
    }

  },

  beforeCreate() {
    external_vue_default.a.util.defineReactive(this, 'nuxt', this.$root.$options.nuxt);
  },

  render(h) {
    // if there is no error
    if (!this.nuxt.err) {
      // Directly return nuxt child
      return h('NuxtChild', {
        key: this.routerViewKey,
        props: this.$props
      });
    } // if an error occurred within NuxtError show a simple
    // error message instead to prevent looping


    if (this.errorFromNuxtError) {
      this.$nextTick(() => this.errorFromNuxtError = false);
      return h('div', {}, [h('h2', 'An error occurred while showing the error page'), h('p', 'Unfortunately an error occurred and while showing the error page another error occurred'), h('p', `Error details: ${this.errorFromNuxtError.toString()}`), h('nuxt-link', {
        props: {
          to: '/'
        }
      }, 'Go back to home')]);
    } // track if we are showing the NuxtError component


    this.displayingNuxtError = true;
    this.$nextTick(() => this.displayingNuxtError = false);
    return h(layouts_error, {
      props: {
        error: this.nuxt.err
      }
    });
  }

});
// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./components/loading.vue?vue&type=template&id=880984f2&scoped=true&
var loadingvue_type_template_id_880984f2_scoped_true_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return (_vm.loading)?_c('section',[_vm._ssrNode("<div id=\"hola\" data-v-880984f2><div id=\"preloader\" data-v-880984f2><span data-v-880984f2></span> <span data-v-880984f2></span></div></div>")]):_vm._e()}
var loadingvue_type_template_id_880984f2_scoped_true_staticRenderFns = []


// CONCATENATED MODULE: ./components/loading.vue?vue&type=template&id=880984f2&scoped=true&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/loading.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ var loadingvue_type_script_lang_js_ = ({
  data: function () {
    return {
      loading: false
    };
  },
  methods: {
    start() {
      this.loading = true;
      setTimeout(() => {
        Velocity(this.$refs.preloader, {
          opacity: 0.1,
          transform: ["translateY(-80px)", "translateY(0)"]
        }, {
          duration: 700,
          complete: () => {
            Velocity(this.$refs.hola, {
              transform: ["translateY(-100%)", "translateY(0)"]
            }, {
              duration: 1000,
              easing: [0.7, 0, 0.3, 1],
              complete: () => {
                this.$nuxt.$el.children[1].firstChild.children[1].classList.add('animate-border', 'divide');
                this.$nuxt.$el.children[1].firstChild.children[1].children[0].children[1].children[0].classList.add('animate__animated', 'animate__bounceInLeft', 'animate__delay-1s');
                this.$nuxt.$el.children[1].firstChild.children[1].children[0].children[1].children[1].classList.add('animate__animated', 'animate__bounceInLeft', 'animate__delay-2s');
                this.$nuxt.$el.children[1].firstChild.children[1].children[0].children[1].children[2].classList.add('animate__animated', 'animate__bounceInLeft', 'animate__delay-3s');
                this.$nuxt.$el.children[1].firstChild.children[1].children[0].children[1].children[0].style.opacity = 1;
                this.$nuxt.$el.children[1].firstChild.children[1].children[0].children[1].children[1].style.opacity = 1;
                this.$nuxt.$el.children[1].firstChild.children[1].children[0].children[1].children[2].style.opacity = 1;
              }
            });
          }
        });
      }, 3000);
    },

    finish() {
      this.loading = false;
    }

  }
});
// CONCATENATED MODULE: ./components/loading.vue?vue&type=script&lang=js&
 /* harmony default export */ var components_loadingvue_type_script_lang_js_ = (loadingvue_type_script_lang_js_); 
// CONCATENATED MODULE: ./components/loading.vue



function loading_injectStyles (context) {
  
  var style0 = __webpack_require__(32)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var loading_component = Object(componentNormalizer["a" /* default */])(
  components_loadingvue_type_script_lang_js_,
  loadingvue_type_template_id_880984f2_scoped_true_render,
  loadingvue_type_template_id_880984f2_scoped_true_staticRenderFns,
  false,
  loading_injectStyles,
  "880984f2",
  "6fa56cbc"
  
)

/* harmony default export */ var loading = (loading_component.exports);
// EXTERNAL MODULE: ./node_modules/fullpage-vue/src/fullpage.css
var fullpage = __webpack_require__(34);

// EXTERNAL MODULE: ./assets/css/tailwind.css
var tailwind = __webpack_require__(36);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./layouts/desktop.vue?vue&type=template&id=5802eed9&scoped=true&lang=html&
var desktopvue_type_template_id_5802eed9_scoped_true_lang_html_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('client-only',[_c('section',{staticClass:"w-full h-screen relative"},[_c('navigation'),_vm._v(" "),_c('Nuxt',{attrs:{"keep-alive":""}})],1)])}
var desktopvue_type_template_id_5802eed9_scoped_true_lang_html_staticRenderFns = []


// CONCATENATED MODULE: ./layouts/desktop.vue?vue&type=template&id=5802eed9&scoped=true&lang=html&

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./components/navigation.vue?vue&type=template&id=9f8a126e&scoped=true&
var navigationvue_type_template_id_9f8a126e_scoped_true_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('nav',{staticClass:"fixed w-full z-20 mt-3 hidden md:visible lg:hidden  xl:block"},[_vm._ssrNode("<button class=\"toggle m-2 absolute\" data-v-9f8a126e><input type=\"checkbox\" name=\"button\" id=\"button\""+(_vm._ssrAttr("checked",Array.isArray(_vm.checked)?_vm._i(_vm.checked,null)>-1:(_vm.checked)))+" data-v-9f8a126e> <label for=\"button\" class=\"bevel \" data-v-9f8a126e>MENU</label></button> "),_vm._ssrNode("<div id=\"nav\""+(_vm._ssrClass("slidein h-16 w-full w-max z-10 nav text-center flex fixed bg-center bg-repeat 2xl:w-full",_vm.open ? 'open' : ''))+" data-v-9f8a126e>","</div>",[_vm._ssrNode("<ul class=\"w-full h-12 px-16 flex justify-evenly self-center flex-wrap \" data-v-9f8a126e>","</ul>",[_vm._ssrNode("<li data-v-9f8a126e>","</li>",[_c('NuxtLink',{staticClass:"text-2xl spin circle",attrs:{"to":"/","prefetch":""}},[_vm._v("Home")])],1),_vm._ssrNode(" "),_vm._ssrNode("<li data-v-9f8a126e>","</li>",[_c('NuxtLink',{staticClass:"text-2xl spin circle cursor-pointer",attrs:{"to":"/aboutme","prefetch":""}},[_vm._v("\n          About Me\n        ")])],1),_vm._ssrNode(" <li data-v-9f8a126e><img"+(_vm._ssrAttr("srcSet",__webpack_require__(22)))+" alt=\"c1chy.web\" class=\"lazyload h-20 w-20 mx-auto\" data-v-9f8a126e></li> "),_vm._ssrNode("<li data-v-9f8a126e>","</li>",[_c('NuxtLink',{staticClass:"text-2xl spin circle",attrs:{"to":"/portfolio","prefetch":""}},[_vm._v("Portfolio")])],1),_vm._ssrNode(" "),_vm._ssrNode("<li data-v-9f8a126e>","</li>",[_c('NuxtLink',{staticClass:"text-2xl spin circle",attrs:{"to":"/contact","prefetch":""}},[_vm._v("Contact")])],1)],2)])],2)}
var navigationvue_type_template_id_9f8a126e_scoped_true_staticRenderFns = []


// CONCATENATED MODULE: ./components/navigation.vue?vue&type=template&id=9f8a126e&scoped=true&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/navigation.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ var navigationvue_type_script_lang_js_ = ({
  name: "navigation",

  data() {
    return {
      open: false,
      checked: false
    };
  },

  methods: {
    toggle() {
      this.open = !this.open;
      this.checked = !this.checked;
    },

    toTop() {
      window.scroll(0, 0);
      fullpage_api.moveTo('page1', 2);
    }

  }
});
// CONCATENATED MODULE: ./components/navigation.vue?vue&type=script&lang=js&
 /* harmony default export */ var components_navigationvue_type_script_lang_js_ = (navigationvue_type_script_lang_js_); 
// CONCATENATED MODULE: ./components/navigation.vue



function navigation_injectStyles (context) {
  
  var style0 = __webpack_require__(38)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var navigation_component = Object(componentNormalizer["a" /* default */])(
  components_navigationvue_type_script_lang_js_,
  navigationvue_type_template_id_9f8a126e_scoped_true_render,
  navigationvue_type_template_id_9f8a126e_scoped_true_staticRenderFns,
  false,
  navigation_injectStyles,
  "9f8a126e",
  "0bcda41e"
  
)

/* harmony default export */ var navigation = (navigation_component.exports);
// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./layouts/desktop.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var desktopvue_type_script_lang_js_ = ({
  components: {
    navigation: navigation
  }
});
// CONCATENATED MODULE: ./layouts/desktop.vue?vue&type=script&lang=js&
 /* harmony default export */ var layouts_desktopvue_type_script_lang_js_ = (desktopvue_type_script_lang_js_); 
// CONCATENATED MODULE: ./layouts/desktop.vue



function desktop_injectStyles (context) {
  
  var style0 = __webpack_require__(41)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var desktop_component = Object(componentNormalizer["a" /* default */])(
  layouts_desktopvue_type_script_lang_js_,
  desktopvue_type_template_id_5802eed9_scoped_true_lang_html_render,
  desktopvue_type_template_id_5802eed9_scoped_true_lang_html_staticRenderFns,
  false,
  desktop_injectStyles,
  "5802eed9",
  "ebef8666"
  
)

/* harmony default export */ var desktop = (desktop_component.exports);
// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/.cache/nuxt/layouts/default.vue?vue&type=template&id=acc293f0&
var defaultvue_type_template_id_acc293f0_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('Nuxt')}
var defaultvue_type_template_id_acc293f0_staticRenderFns = []


// CONCATENATED MODULE: ./node_modules/.cache/nuxt/layouts/default.vue?vue&type=template&id=acc293f0&

// CONCATENATED MODULE: ./node_modules/.cache/nuxt/layouts/default.vue

var script = {}


/* normalize component */

var default_component = Object(componentNormalizer["a" /* default */])(
  script,
  defaultvue_type_template_id_acc293f0_render,
  defaultvue_type_template_id_acc293f0_staticRenderFns,
  false,
  null,
  null,
  "5ba0c6f7"
  
)

/* harmony default export */ var layouts_default = (default_component.exports);
// CONCATENATED MODULE: ./node_modules/.cache/nuxt/App.js









const layouts = {
  "_desktop": sanitizeComponent(desktop),
  "_default": sanitizeComponent(layouts_default)
};
/* harmony default export */ var App = ({
  render(h, props) {
    const loadingEl = h('NuxtLoading', {
      ref: 'loading'
    });
    const layoutEl = h(this.layout || 'nuxt');
    const templateEl = h('div', {
      domProps: {
        id: '__layout'
      },
      key: this.layoutName
    }, [layoutEl]);
    const transitionEl = h('transition', {
      props: {
        name: 'layout',
        mode: 'out-in'
      },
      on: {
        beforeEnter(el) {
          // Ensure to trigger scroll event after calling scrollBehavior
          window.$nuxt.$nextTick(() => {
            window.$nuxt.$emit('triggerScroll');
          });
        }

      }
    }, [templateEl]);
    return h('div', {
      domProps: {
        id: '__nuxt'
      }
    }, [loadingEl, transitionEl]);
  },

  data: () => ({
    isOnline: true,
    layout: null,
    layoutName: '',
    nbFetching: 0
  }),

  beforeCreate() {
    external_vue_default.a.util.defineReactive(this, 'nuxt', this.$options.nuxt);
  },

  created() {
    // Add this.$nuxt in child instances
    this.$root.$options.$nuxt = this;

    if (false) {} // Add $nuxt.error()


    this.error = this.nuxt.error; // Add $nuxt.context

    this.context = this.$options.context;
  },

  async mounted() {
    this.$loading = this.$refs.loading;

    if (this.isPreview) {
      if (this.$store && this.$store._actions.nuxtServerInit) {
        this.$loading.start();
        await this.$store.dispatch('nuxtServerInit', this.context);
      }

      await this.refresh();
      this.$loading.finish();
    }
  },

  watch: {
    'nuxt.err': 'errorChanged'
  },
  computed: {
    isOffline() {
      return !this.isOnline;
    },

    isFetching() {
      return this.nbFetching > 0;
    },

    isPreview() {
      return Boolean(this.$options.previewData);
    }

  },
  methods: {
    refreshOnlineStatus() {
      if (false) {}
    },

    async refresh() {
      const pages = getMatchedComponentsInstances(this.$route);

      if (!pages.length) {
        return;
      }

      this.$loading.start();
      const promises = pages.map(page => {
        const p = []; // Old fetch

        if (page.$options.fetch && page.$options.fetch.length) {
          p.push(promisify(page.$options.fetch, this.context));
        }

        if (page.$fetch) {
          p.push(page.$fetch());
        } else {
          // Get all component instance to call $fetch
          for (const component of getChildrenComponentInstancesUsingFetch(page.$vnode.componentInstance)) {
            p.push(component.$fetch());
          }
        }

        if (page.$options.asyncData) {
          p.push(promisify(page.$options.asyncData, this.context).then(newData => {
            for (const key in newData) {
              external_vue_default.a.set(page.$data, key, newData[key]);
            }
          }));
        }

        return Promise.all(p);
      });

      try {
        await Promise.all(promises);
      } catch (error) {
        this.$loading.fail(error);
        globalHandleError(error);
        this.error(error);
      }

      this.$loading.finish();
    },

    errorChanged() {
      if (this.nuxt.err) {
        if (this.$loading) {
          if (this.$loading.fail) {
            this.$loading.fail(this.nuxt.err);
          }

          if (this.$loading.finish) {
            this.$loading.finish();
          }
        }

        let errorLayout = (layouts_error.options || layouts_error).layout;

        if (typeof errorLayout === 'function') {
          errorLayout = errorLayout(this.context);
        }

        this.setLayout(errorLayout);
      }
    },

    setLayout(layout) {
      if (!layout || !layouts['_' + layout]) {
        layout = 'default';
      }

      this.layoutName = layout;
      this.layout = layouts['_' + layout];
      return this.layout;
    },

    loadLayout(layout) {
      if (!layout || !layouts['_' + layout]) {
        layout = 'default';
      }

      return Promise.resolve(layouts['_' + layout]);
    },

    getRouterBase() {
      return Object(external_ufo_["withoutTrailingSlash"])(this.$router.options.base);
    },

    getRoutePath(route = '/') {
      const base = this.getRouterBase();
      return Object(external_ufo_["withoutTrailingSlash"])(Object(external_ufo_["withoutBase"])(Object(external_ufo_["parsePath"])(route).pathname, base));
    },

    getStaticAssetsPath(route = '/') {
      const {
        staticAssetsBase
      } = window.__NUXT__;
      return urlJoin(staticAssetsBase, this.getRoutePath(route));
    },

    async fetchStaticManifest() {
      return window.__NUXT_IMPORT__('manifest.js', Object(external_ufo_["normalizeURL"])(urlJoin(this.getStaticAssetsPath(), 'manifest.js')));
    },

    setPagePayload(payload) {
      this._pagePayload = payload;
      this._fetchCounters = {};
    },

    async fetchPayload(route, prefetch) {
      const path = Object(external_ufo_["decode"])(this.getRoutePath(route));
      const manifest = await this.fetchStaticManifest();

      if (!manifest.routes.includes(path)) {
        if (!prefetch) {
          this.setPagePayload(false);
        }

        throw new Error(`Route ${path} is not pre-rendered`);
      }

      const src = urlJoin(this.getStaticAssetsPath(route), 'payload.js');

      try {
        const payload = await window.__NUXT_IMPORT__(path, Object(external_ufo_["normalizeURL"])(src));

        if (!prefetch) {
          this.setPagePayload(payload);
        }

        return payload;
      } catch (err) {
        if (!prefetch) {
          this.setPagePayload(false);
        }

        throw err;
      }
    }

  },
  components: {
    NuxtLoading: loading
  }
});
// EXTERNAL MODULE: ./node_modules/.cache/nuxt/empty.js
var nuxt_empty = __webpack_require__(5);

// EXTERNAL MODULE: external "lazysizes"
var external_lazysizes_ = __webpack_require__(18);
var external_lazysizes_default = /*#__PURE__*/__webpack_require__.n(external_lazysizes_);

// CONCATENATED MODULE: ./node_modules/.cache/nuxt/lazySizes.js

const lsConfig = {};
Object.assign(external_lazysizes_default.a.cfg, lsConfig);
// CONCATENATED MODULE: ./node_modules/.cache/nuxt/pwa/meta.utils.js
function mergeMeta(to, from) {
  if (typeof to === 'function') {
    // eslint-disable-next-line no-console
    console.warn('Cannot merge meta. Avoid using head as a function!');
    return;
  }

  for (const key in from) {
    const value = from[key];

    if (Array.isArray(value)) {
      to[key] = to[key] || [];

      for (const item of value) {
        // Avoid duplicates
        if (item.hid && hasMeta(to[key], 'hid', item.hid) || item.name && hasMeta(to[key], 'name', item.name)) {
          continue;
        } // Add meta


        to[key].push(item);
      }
    } else if (typeof value === 'object') {
      to[key] = to[key] || {};

      for (const attr in value) {
        to[key][attr] = value[attr];
      }
    } else if (to[key] === undefined) {
      to[key] = value;
    }
  }
}

function hasMeta(arr, key, val) {
  return arr.find(obj => val ? obj[key] === val : obj[key]);
}
// EXTERNAL MODULE: ./node_modules/.cache/nuxt/pwa/meta.json
var meta = __webpack_require__(19);

// CONCATENATED MODULE: ./node_modules/.cache/nuxt/pwa/meta.plugin.js


/* harmony default export */ var meta_plugin = (function ({
  app
}) {
  mergeMeta(app.head, meta);
});
// CONCATENATED MODULE: ./node_modules/.cache/nuxt/pwa/icon.plugin.js
/* harmony default export */ var icon_plugin = (async function (ctx, inject) {
  const icons = {
    "64x64": "/_nuxt/icons/icon_64x64.789ef7.png",
    "120x120": "/_nuxt/icons/icon_120x120.789ef7.png",
    "144x144": "/_nuxt/icons/icon_144x144.789ef7.png",
    "152x152": "/_nuxt/icons/icon_152x152.789ef7.png",
    "192x192": "/_nuxt/icons/icon_192x192.789ef7.png",
    "384x384": "/_nuxt/icons/icon_384x384.789ef7.png",
    "512x512": "/_nuxt/icons/icon_512x512.789ef7.png",
    "ipad_1536x2048": "/_nuxt/icons/splash_ipad_1536x2048.789ef7.png",
    "ipadpro9_1536x2048": "/_nuxt/icons/splash_ipadpro9_1536x2048.789ef7.png",
    "ipadpro10_1668x2224": "/_nuxt/icons/splash_ipadpro10_1668x2224.789ef7.png",
    "ipadpro12_2048x2732": "/_nuxt/icons/splash_ipadpro12_2048x2732.789ef7.png",
    "iphonese_640x1136": "/_nuxt/icons/splash_iphonese_640x1136.789ef7.png",
    "iphone6_50x1334": "/_nuxt/icons/splash_iphone6_50x1334.789ef7.png",
    "iphoneplus_1080x1920": "/_nuxt/icons/splash_iphoneplus_1080x1920.789ef7.png",
    "iphonex_1125x2436": "/_nuxt/icons/splash_iphonex_1125x2436.789ef7.png",
    "iphonexr_828x1792": "/_nuxt/icons/splash_iphonexr_828x1792.789ef7.png",
    "iphonexsmax_1242x2688": "/_nuxt/icons/splash_iphonexsmax_1242x2688.789ef7.png"
  };

  const getIcon = size => icons[size + 'x' + size] || '';

  inject('icon', getIcon);
});
// CONCATENATED MODULE: ./node_modules/.cache/nuxt/index.js










/* Plugins */

 // Source: .\\lib.plugin.8eef95e0.js (mode: 'client')

 // Source: .\\lazySizes.js (mode: 'all')

 // Source: .\\fontLoader.js (mode: 'client')

 // Source: .\\workbox.js (mode: 'client')

 // Source: .\\pwa\\meta.plugin.js (mode: 'all')

 // Source: .\\pwa\\icon.plugin.js (mode: 'all')

 // Source: ..\\..\\..\\plugins\\fullpage (mode: 'client')

 // Source: ..\\..\\..\\plugins\\aos.js (mode: 'client')
// Component: <ClientOnly>

external_vue_default.a.component(external_vue_client_only_default.a.name, external_vue_client_only_default.a); // TODO: Remove in Nuxt 3: <NoSsr>

external_vue_default.a.component(external_vue_no_ssr_default.a.name, { ...external_vue_no_ssr_default.a,

  render(h, ctx) {
    if (false) {}

    return external_vue_no_ssr_default.a.render(h, ctx);
  }

}); // Component: <NuxtChild>

external_vue_default.a.component(nuxt_child.name, nuxt_child);
external_vue_default.a.component('NChild', nuxt_child); // Component NuxtLink is imported in server.js or client.js
// Component: <Nuxt>

external_vue_default.a.component(components_nuxt.name, components_nuxt);
Object.defineProperty(external_vue_default.a.prototype, '$nuxt', {
  get() {
    const globalNuxt = this.$root.$options.$nuxt;

    if (false) {}

    return globalNuxt;
  },

  configurable: true
});
external_vue_default.a.use(external_vue_meta_default.a, {
  "keyName": "head",
  "attribute": "data-n-head",
  "ssrAttribute": "data-n-head-ssr",
  "tagIDKeyName": "hid"
});
const defaultTransition = {
  "name": "page",
  "mode": "out-in",
  "appear": false,
  "appearClass": "appear",
  "appearActiveClass": "appear-active",
  "appearToClass": "appear-to"
};

async function createApp(ssrContext, config = {}) {
  const router = await createRouter(ssrContext, config); // Create Root instance
  // here we inject the router and store to all child components,
  // making them available everywhere as `this.$router` and `this.$store`.

  const app = {
    head: {
      "script": [{
        "src": "\u002F\u002Fcdnjs.cloudflare.com\u002Fajax\u002Flibs\u002Fvelocity\u002F2.0.6\u002Fvelocity.min.js"
      }, {
        "src": "\u002F\u002Fcdnjs.cloudflare.com\u002Fajax\u002Flibs\u002Fvelocity\u002F2.0.6\u002Fvelocity.ui.min.js"
      }],
      "title": "c1chy.web",
      "htmlAttrs": {
        "lang": "de",
        "amp": true
      },
      "meta": [{
        "charset": "utf-8"
      }, {
        "name": "viewport",
        "content": "width=device-width, initial-scale=1"
      }, {
        "hid": "description",
        "name": "description",
        "content": "c1chy My Frontend experiences Nuxt Portfolio Webentwickler"
      }],
      "link": [{
        "rel": "icon",
        "type": "image\u002Fx-icon",
        "href": "\u002Ffavicon.ico"
      }, {
        "rel": "preload",
        "as": "style",
        "href": "\u002Ffonts\u002Ffont-face.css"
      }, {
        "hid": "font-preload",
        "rel": "preload",
        "as": "style",
        "href": "\u002Ffonts\u002Ffont-face.css"
      }],
      "style": [],
      "noscript": [{
        "hid": "font-noscript",
        "innerHTML": "\u003Clink rel=\"stylesheet\" href=\"\u002Ffonts\u002Ffont-face.css\"\u003E"
      }],
      "__dangerouslyDisableSanitizersByTagID": {
        "font-noscript": ["innerHTML"]
      }
    },
    router,
    nuxt: {
      defaultTransition,
      transitions: [defaultTransition],

      setTransitions(transitions) {
        if (!Array.isArray(transitions)) {
          transitions = [transitions];
        }

        transitions = transitions.map(transition => {
          if (!transition) {
            transition = defaultTransition;
          } else if (typeof transition === 'string') {
            transition = Object.assign({}, defaultTransition, {
              name: transition
            });
          } else {
            transition = Object.assign({}, defaultTransition, transition);
          }

          return transition;
        });
        this.$options.nuxt.transitions = transitions;
        return transitions;
      },

      err: null,
      dateErr: null,

      error(err) {
        err = err || null;
        app.context._errored = Boolean(err);
        err = err ? normalizeError(err) : null;
        let nuxt = app.nuxt; // to work with @vue/composition-api, see https://github.com/nuxt/nuxt.js/issues/6517#issuecomment-573280207

        if (this) {
          nuxt = this.nuxt || this.$options.nuxt;
        }

        nuxt.dateErr = Date.now();
        nuxt.err = err; // Used in src/server.js

        if (ssrContext) {
          ssrContext.nuxt.error = err;
        }

        return err;
      }

    },
    ...App
  };
  const next = ssrContext ? ssrContext.next : location => app.router.push(location); // Resolve route

  let route;

  if (ssrContext) {
    route = router.resolve(ssrContext.url).route;
  } else {
    const path = getLocation(router.options.base, router.options.mode);
    route = router.resolve(path).route;
  } // Set context to app.context


  await setContext(app, {
    route,
    next,
    error: app.nuxt.error.bind(app),
    payload: ssrContext ? ssrContext.payload : undefined,
    req: ssrContext ? ssrContext.req : undefined,
    res: ssrContext ? ssrContext.res : undefined,
    beforeRenderFns: ssrContext ? ssrContext.beforeRenderFns : undefined,
    ssrContext
  });

  function inject(key, value) {
    if (!key) {
      throw new Error('inject(key, value) has no key provided');
    }

    if (value === undefined) {
      throw new Error(`inject('${key}', value) has no value provided`);
    }

    key = '$' + key; // Add into app

    app[key] = value; // Add into context

    if (!app.context[key]) {
      app.context[key] = value;
    } // Check if plugin not already installed


    const installKey = '__nuxt_' + key + '_installed__';

    if (external_vue_default.a[installKey]) {
      return;
    }

    external_vue_default.a[installKey] = true; // Call Vue.use() to install the plugin into vm

    external_vue_default.a.use(() => {
      if (!Object.prototype.hasOwnProperty.call(external_vue_default.a.prototype, key)) {
        Object.defineProperty(external_vue_default.a.prototype, key, {
          get() {
            return this.$root.$options[key];
          }

        });
      }
    });
  } // Inject runtime config as $config


  inject('config', config); // Add enablePreview(previewData = {}) in context for plugins

  if (false) {} // Plugin execution


  if (false) {}

  if (typeof /* Cannot get final name for export "default" in "./node_modules/.cache/nuxt/lazySizes.js" (known exports: , known reexports: ) */ undefined === 'function') {
    await /* Cannot get final name for export "default" in "./node_modules/.cache/nuxt/lazySizes.js" (known exports: , known reexports: ) */ undefined(app.context, inject);
  }

  if (false) {}

  if (false) {}

  if (typeof meta_plugin === 'function') {
    await meta_plugin(app.context, inject);
  }

  if (typeof icon_plugin === 'function') {
    await icon_plugin(app.context, inject);
  }

  if (false) {}

  if (false) {} // Lock enablePreview in context


  if (false) {} // Wait for async component to be resolved first


  await new Promise((resolve, reject) => {
    router.push(app.context.route.fullPath, resolve, err => {
      // https://github.com/vuejs/vue-router/blob/v3.4.3/src/util/errors.js
      if (!err._isRouter) return reject(err);
      if (err.type !== 2
      /* NavigationFailureType.redirected */
      ) return resolve(); // navigated to a different route in router guard

      const unregister = router.afterEach(async (to, from) => {
        if ( true && ssrContext && ssrContext.url) {
          ssrContext.url = to.fullPath;
        }

        app.context.route = await getRouteData(to);
        app.context.params = to.params || {};
        app.context.query = to.query || {};
        unregister();
        resolve();
      });
    });
  });
  return {
    app,
    router
  };
}


// CONCATENATED MODULE: ./node_modules/.cache/nuxt/components/nuxt-link.server.js

/* harmony default export */ var nuxt_link_server = ({
  name: 'NuxtLink',
  extends: external_vue_default.a.component('RouterLink'),
  props: {
    prefetch: {
      type: Boolean,
      default: true
    },
    noPrefetch: {
      type: Boolean,
      default: false
    }
  }
});
// CONCATENATED MODULE: ./node_modules/.cache/nuxt/server.js







 // should be included after ./index.js
// Update serverPrefetch strategy

external_vue_default.a.config.optionMergeStrategies.serverPrefetch = external_vue_default.a.config.optionMergeStrategies.created; // Fetch mixin

if (!external_vue_default.a.__nuxt__fetch__mixin__) {
  external_vue_default.a.mixin(fetch_server);
  external_vue_default.a.__nuxt__fetch__mixin__ = true;
} // Component: <NuxtLink>


external_vue_default.a.component(nuxt_link_server.name, nuxt_link_server);
external_vue_default.a.component('NLink', nuxt_link_server);

if (!global.fetch) {
  global.fetch = external_node_fetch_default.a;
}

const noopApp = () => new external_vue_default.a({
  render: h => h('div', {
    domProps: {
      id: '__nuxt'
    }
  })
});

const createNext = ssrContext => opts => {
  // If static target, render on client-side
  ssrContext.redirected = opts;

  if (ssrContext.target === 'static' || !ssrContext.res) {
    ssrContext.nuxt.serverRendered = false;
    return;
  }

  let fullPath = Object(external_ufo_["withQuery"])(opts.path, opts.query);
  const $config = ssrContext.runtimeConfig || {};
  const routerBase = $config._app && $config._app.basePath || '/';

  if (!fullPath.startsWith('http') && routerBase !== '/' && !fullPath.startsWith(routerBase)) {
    fullPath = Object(external_ufo_["joinURL"])(routerBase, fullPath);
  } // Avoid loop redirect


  if (decodeURI(fullPath) === decodeURI(ssrContext.url)) {
    ssrContext.redirected = false;
    return;
  }

  ssrContext.res.writeHead(opts.status, {
    Location: Object(external_ufo_["normalizeURL"])(fullPath)
  });
  ssrContext.res.end();
}; // This exported function will be called by `bundleRenderer`.
// This is where we perform data-prefetching to determine the
// state of our application before actually rendering it.
// Since data fetching is async, this function is expected to
// return a Promise that resolves to the app instance.


/* harmony default export */ var server = __webpack_exports__["default"] = (async ssrContext => {
  // Create ssrContext.next for simulate next() of beforeEach() when wanted to redirect
  ssrContext.redirected = false;
  ssrContext.next = createNext(ssrContext); // Used for beforeNuxtRender({ Components, nuxtState })

  ssrContext.beforeRenderFns = []; // Nuxt object (window.{{globals.context}}, defaults to window.__NUXT__)

  ssrContext.nuxt = {
    layout: 'default',
    data: [],
    fetch: {},
    error: null,
    serverRendered: true,
    routePath: ''
  };
  ssrContext.fetchCounters = {}; // Remove query from url is static target

  if (ssrContext.url) {
    ssrContext.url = ssrContext.url.split('?')[0];
  } // Public runtime config


  ssrContext.nuxt.config = ssrContext.runtimeConfig.public;

  if (ssrContext.nuxt.config._app) {
    __webpack_require__.p = Object(external_ufo_["joinURL"])(ssrContext.nuxt.config._app.cdnURL, ssrContext.nuxt.config._app.assetsPath);
  } // Create the app definition and the instance (created for each request)


  const {
    app,
    router
  } = await createApp(ssrContext, ssrContext.runtimeConfig.private);

  const _app = new external_vue_default.a(app); // Add ssr route path to nuxt context so we can account for page navigation between ssr and csr


  ssrContext.nuxt.routePath = app.context.route.path; // Add meta infos (used in renderer.js)

  ssrContext.meta = _app.$meta(); // Keep asyncData for each matched component in ssrContext (used in app/utils.js via this.$ssrContext)

  ssrContext.asyncData = {};

  const beforeRender = async () => {
    // Call beforeNuxtRender() methods
    await Promise.all(ssrContext.beforeRenderFns.map(fn => promisify(fn, {
      Components,
      nuxtState: ssrContext.nuxt
    })));
  };

  const renderErrorPage = async () => {
    // Don't server-render the page in static target
    if (ssrContext.target === 'static') {
      ssrContext.nuxt.serverRendered = false;
    } // Load layout for error page


    const layout = (layouts_error.options || layouts_error).layout;
    const errLayout = typeof layout === 'function' ? layout.call(layouts_error, app.context) : layout;
    ssrContext.nuxt.layout = errLayout || 'default';
    await _app.loadLayout(errLayout);

    _app.setLayout(errLayout);

    await beforeRender();
    return _app;
  };

  const render404Page = () => {
    app.context.error({
      statusCode: 404,
      path: ssrContext.url,
      message: 'This page could not be found'
    });
    return renderErrorPage();
  }; // Components are already resolved by setContext -> getRouteData (app/utils.js)


  const Components = getMatchedComponents(app.context.route);
  /*
  ** Call global middleware (nuxt.config.js)
  */

  let midd = [];
  midd = midd.map(name => {
    if (typeof name === 'function') {
      return name;
    }

    if (typeof nuxt_middleware[name] !== 'function') {
      app.context.error({
        statusCode: 500,
        message: 'Unknown middleware ' + name
      });
    }

    return nuxt_middleware[name];
  });
  await middlewareSeries(midd, app.context); // ...If there is a redirect or an error, stop the process

  if (ssrContext.redirected) {
    return noopApp();
  }

  if (ssrContext.nuxt.error) {
    return renderErrorPage();
  }
  /*
  ** Set layout
  */


  let layout = Components.length ? Components[0].options.layout : layouts_error.layout;

  if (typeof layout === 'function') {
    layout = layout(app.context);
  }

  await _app.loadLayout(layout);

  if (ssrContext.nuxt.error) {
    return renderErrorPage();
  }

  layout = _app.setLayout(layout);
  ssrContext.nuxt.layout = _app.layoutName;
  /*
  ** Call middleware (layout + pages)
  */

  midd = [];
  layout = sanitizeComponent(layout);

  if (layout.options.middleware) {
    midd = midd.concat(layout.options.middleware);
  }

  Components.forEach(Component => {
    if (Component.options.middleware) {
      midd = midd.concat(Component.options.middleware);
    }
  });
  midd = midd.map(name => {
    if (typeof name === 'function') {
      return name;
    }

    if (typeof nuxt_middleware[name] !== 'function') {
      app.context.error({
        statusCode: 500,
        message: 'Unknown middleware ' + name
      });
    }

    return nuxt_middleware[name];
  });
  await middlewareSeries(midd, app.context); // ...If there is a redirect or an error, stop the process

  if (ssrContext.redirected) {
    return noopApp();
  }

  if (ssrContext.nuxt.error) {
    return renderErrorPage();
  }
  /*
  ** Call .validate()
  */


  let isValid = true;

  try {
    for (const Component of Components) {
      if (typeof Component.options.validate !== 'function') {
        continue;
      }

      isValid = await Component.options.validate(app.context);

      if (!isValid) {
        break;
      }
    }
  } catch (validationError) {
    // ...If .validate() threw an error
    app.context.error({
      statusCode: validationError.statusCode || '500',
      message: validationError.message
    });
    return renderErrorPage();
  } // ...If .validate() returned false


  if (!isValid) {
    // Render a 404 error page
    return render404Page();
  } // If no Components found, returns 404


  if (!Components.length) {
    return render404Page();
  } // Call asyncData & fetch hooks on components matched by the route.


  const asyncDatas = await Promise.all(Components.map(Component => {
    const promises = []; // Call asyncData(context)

    if (Component.options.asyncData && typeof Component.options.asyncData === 'function') {
      const promise = promisify(Component.options.asyncData, app.context);
      promise.then(asyncDataResult => {
        ssrContext.asyncData[Component.cid] = asyncDataResult;
        applyAsyncData(Component);
        return asyncDataResult;
      });
      promises.push(promise);
    } else {
      promises.push(null);
    } // Call fetch(context)


    if (Component.options.fetch && Component.options.fetch.length) {
      promises.push(Component.options.fetch(app.context));
    } else {
      promises.push(null);
    }

    return Promise.all(promises);
  })); // datas are the first row of each

  ssrContext.nuxt.data = asyncDatas.map(r => r[0] || {}); // ...If there is a redirect or an error, stop the process

  if (ssrContext.redirected) {
    return noopApp();
  }

  if (ssrContext.nuxt.error) {
    return renderErrorPage();
  } // Call beforeNuxtRender methods & add store state


  await beforeRender();
  return _app;
});

/***/ })
/******/ ]);
//# sourceMappingURL=server.js.map