exports.ids = [6];
exports.modules = {

/***/ 29:
/***/ (function(module, exports) {

// Exports
module.exports = {

};


/***/ }),

/***/ 54:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_0_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_1_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_vue_loader_lib_index_js_vue_loader_options_portfolio_vue_vue_type_style_index_0_id_0e648cbd_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(29);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_0_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_1_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_vue_loader_lib_index_js_vue_loader_options_portfolio_vue_vue_type_style_index_0_id_0e648cbd_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_0_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_1_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_vue_loader_lib_index_js_vue_loader_options_portfolio_vue_vue_type_style_index_0_id_0e648cbd_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_0_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_1_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_vue_loader_lib_index_js_vue_loader_options_portfolio_vue_vue_type_style_index_0_id_0e648cbd_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_0_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_1_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_vue_loader_lib_index_js_vue_loader_options_portfolio_vue_vue_type_style_index_0_id_0e648cbd_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 78:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./pages/portfolio.vue?vue&type=template&id=0e648cbd&scoped=true&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"h-screen w-full absolute z-10"},[_vm._ssrNode("<header class=\"container  relative p-24 w-full flex flex-col justify-center grid grid-cols-1 justify-items-center h-112 max-w-full lg:max-w-max  mx-auto relative overflow-hidden\" data-v-0e648cbd>","</header>",[_c('light',{staticClass:"overflow-hidden filter-shadow-black"}),_vm._ssrNode(" <div class=\"title uppercase top-2\" data-v-0e648cbd><h1 class=\"text-8xl font-semibold text-center uppercase\" data-v-0e648cbd>Portfolio\n      </h1></div> <div class=\"title_dividers w-1/2 h-4 mx-auto my-10 relative inline-block\" data-v-0e648cbd><span class=\"w-full h-0.5 absolute left-2/4 transform -translate-x-1/2\" data-v-0e648cbd></span> <span class=\"w-full h-0.5 top-2 absolute left-2/4 transform -translate-x-1/2\" data-v-0e648cbd></span> <span class=\"w-full h-0.5 top-4 absolute left-2/4 transform -translate-x-1/2\" data-v-0e648cbd></span></div> "),_vm._ssrNode("<figure class=\"relative flex items-center justify-center filter-shadow-black z-10\" data-v-0e648cbd>","</figure>",[_vm._ssrNode("<img"+(_vm._ssrAttr("data-src",__webpack_require__(15)))+" alt=\"ribbon\" class=\"lazyload w-full h-20 my-auto z-1 filter-shadow-black\" data-v-0e648cbd> "),_vm._ssrNode("<figcaption class=\"absolute block mx-auto mt-5 text-white text-3xl text-center \" data-v-0e648cbd>","</figcaption>",[_c('NuxtLink',{attrs:{"to":"/"}},[_vm._v("Home")]),_vm._ssrNode("\n        &gt; Portfolio\n      ")],2)],2)],2),_vm._ssrNode(" <div class=\"page-spacing w-full h-20 absolute left-0 bg-repeat bg-center\" data-v-0e648cbd></div> "),_vm._ssrNode("<section class=\"portfolio h-auto pb-8 overflow-hidden\" data-v-0e648cbd>","</section>",[_vm._ssrNode("<div class=\"portfolio_case w-3/4 h-28  items-center flex  mx-auto mt-20\" data-v-0e648cbd><span class=\"w-full inline-block relative\" data-v-0e648cbd></span> <h2 class=\"font-bold text-3xl mt-4  text-center lg:w-full 2xl:w-9/12 2xl:mt-8\" data-v-0e648cbd>MEANINGFUL <br data-v-0e648cbd>CREATIVE WORK</h2> <span class=\"w-full inline-block relative\" data-v-0e648cbd></span></div> <h1 class=\"leading-none mt-16 mb-24 text-10xl font-semibold text-center xl:text-7xl xl:mt-2 xl:mb-5 2xl:text-14xl 2xl:mt-20 2xl:mb-24 \" data-v-0e648cbd>\n      CASE STUDIES</h1> "),_vm._ssrNode("<div data-aos-anchor=\"#panel\" data-aos-easing=\"ease-in-sine\" data-aos-anchor-placement=\"center-bottom\" data-aos=\"flip-down\" data-aos-delay=\"500\" class=\"w-full  flex flex-col justify-center items-center overflow-hidden\" data-v-0e648cbd>","</div>",[_c('transition',{attrs:{"name":_vm.currentTransition,"mode":"out-in"}},[_c(_vm.slides[_vm.currentSlide],{tag:"component",staticClass:"w-1/2 h-3/4  flex items-center justify-center bg-repeat-round  bg-cover text-3xl text-white font-sans"})],1),_vm._ssrNode(" <div id=\"panel\" class=\"w-full h-1/3 flex justify-center items-center font-sans text-white\" data-v-0e648cbd><button"+(_vm._ssrClass("draw-border m-4 px-12 py-6  inline bg-none border-none text-2xl font-bold font-sans uppercase cursor-pointer leading-normal",{disabled: _vm.currentSlide === 0}))+" data-v-0e648cbd>prev\n        </button> <p class=\"w-1/3 text-center text-5xl font-sans\" data-v-0e648cbd>"+_vm._ssrEscape(_vm._s(_vm.currentSlide + 1)+" of "+_vm._s(_vm.slides.length))+"</p> <button"+(_vm._ssrClass("btn draw-border m-4 px-12 py-6  inline bg-none border-none text-2xl font-bold font-sans uppercase cursor-pointer leading-normal",{disabled: _vm.currentSlide === _vm.slides.length - 1}))+" data-v-0e648cbd>next\n        </button></div>")],2)],2),_vm._ssrNode(" "),_vm._ssrNode("<section id=\"my_projects\" class=\"lg:-mb-8 overflow-x-hidden min-h-screen flex flex-col justify-between\" data-v-0e648cbd>","</section>",[_vm._ssrNode("<div class=\"title-container flex flex-col justify-center items-center mt-0\" data-v-0e648cbd><h1 class=\"title text-9xl font-semibold text-center uppercase mb-8\" data-v-0e648cbd>My Projects\n      </h1> <div data-v-0e648cbd><span"+(_vm._ssrClass("filter px-4 py-2 rounded-2xl text-4xl font-medium font-sans transition-all cursor-pointer",{ active: _vm.currentFilter === 'ALL' }))+" data-v-0e648cbd>ALL</span> <span"+(_vm._ssrClass("filter px-4 py-2 rounded-2xl text-4xl font-medium font-sans transition-all cursor-pointer",{ active: _vm.currentFilter === 'WEBPACK' }))+" data-v-0e648cbd>WEBPACK</span> <span"+(_vm._ssrClass("filter px-4 py-2 rounded-2xl text-4xl font-medium font-sans transition-all cursor-pointer",{ active: _vm.currentFilter === 'ES6' }))+" data-v-0e648cbd>ES6</span> <span"+(_vm._ssrClass("filter px-4 py-2 rounded-2xl text-4xl font-medium font-sans transition-all cursor-pointer",{ active: _vm.currentFilter === 'PURECSS' }))+" data-v-0e648cbd>PURE CSS</span> <span"+(_vm._ssrClass("filter px-4 py-2 rounded-2xl text-4xl font-medium font-sans transition-all cursor-pointer",{ active: _vm.currentFilter === 'DATABASE' }))+" data-v-0e648cbd>DATABASE</span> <span"+(_vm._ssrClass("filter px-4 py-2 rounded-2xl text-4xl font-medium font-sans transition-all cursor-pointer",{ active: _vm.currentFilter === 'REACT' }))+" data-v-0e648cbd>REACT</span> <span"+(_vm._ssrClass("filter px-4 py-2 rounded-2xl text-4xl font-medium font-sans transition-all cursor-pointer",{ active: _vm.currentFilter === 'VUE' }))+" data-v-0e648cbd>VUE</span></div></div> "),_vm._ssrNode("<div class=\"container_projects w-full h-full min-h-50 mt-8 pb-10 flex justify-center items-center flex-col\" data-v-0e648cbd>","</div>",[_c('transition-group',{staticClass:"projects w-11/12  mb-8 mt-1 flex flex-wrap justify-around",attrs:{"name":"projects"}},_vm._l((_vm.projects),function(project){return (_vm.currentFilter === project.category || _vm.currentFilter === 'ALL')?_c('div',{key:project.title,staticClass:"card w-116 h-52 mb-1 mt-5 flex-wrap justify-center overflow-hidden"},[_c('div',{staticClass:"project-image-wrapper relative"},[_c('h2',{staticClass:"project-title absolute bottom-0 right-28 text-4xl font-sans font-bold z-50"},[_vm._v(_vm._s(project.title))]),_vm._v(" "),_c('i',{staticClass:"card-arrow w-8 h-12 absolute bottom-1 right-4 bg-no-repeat cursor-pointer z-50"}),_vm._v(" "),_c('p',{staticClass:"absolute top-2 right-12 text-2xl opacity-70"},[_vm._v(_vm._s(project.secondTechnology))]),_vm._v(" "),_c('img',{staticClass:"lazyload pic w-10/12 h-56  z-50",attrs:{"src":project.image,"alt":project.alt}}),_vm._v(" "),_c('ul',{staticClass:"absolute list-none z-50"},[_c('li'),_vm._v(" "),_c('li'),_vm._v(" "),_c('li'),_vm._v(" "),_c('li'),_vm._v(" "),_c('li'),_vm._v(" "),_c('li'),_vm._v(" "),_c('li'),_vm._v(" "),_c('li'),_vm._v(" "),_c('li'),_vm._v(" "),_c('li'),_vm._v(" "),_c('li'),_vm._v(" "),_c('li'),_vm._v(" "),_c('li'),_vm._v(" "),_c('li'),_vm._v(" "),_c('li'),_vm._v(" "),_c('li'),_vm._v(" "),_c('li'),_vm._v(" "),_c('li'),_vm._v(" "),_c('li'),_vm._v(" "),_c('li'),_vm._v(" "),_c('li'),_vm._v(" "),_c('li'),_vm._v(" "),_c('li')]),_vm._v(" "),_c('div',{staticClass:"social w-52 h-8 absolute top-2 left-4 flex justify-around items-center"},[_c('i',{staticClass:"text-5xl"},[_vm._v(_vm._s(project.technology))]),_vm._v(" "),_c('i',{staticClass:"text-5xl"},[_vm._v("SCSS")]),_vm._v(" "),_c('i',{staticClass:"text-5xl"}),_vm._v(" "),_c('i',{staticClass:"text-5xl"})]),_vm._v(" "),_c('a',{attrs:{"href":("" + (project.link)),"target":"_blank","rel":"noopener"}},[_c('button',{staticClass:"w-8 h-8 absolute bottom-4 right-4 border-none outline-none cursor-pointer ",attrs:{"aria-label":"Project"}})])])]):_vm._e()}),0)],1),_vm._ssrNode(" "),_c('stickyFooter',{staticClass:"opacity-100",attrs:{"data-aos":"slide-left","data-aos-duration":"1000"}})],2)],2)}
var staticRenderFns = []


// CONCATENATED MODULE: ./pages/portfolio.vue?vue&type=template&id=0e648cbd&scoped=true&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./pages/portfolio.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ var portfoliovue_type_script_lang_js_ = ({
  components: {
    light: () => __webpack_require__.e(/* import() */ 0).then(__webpack_require__.bind(null, 80)),
    stickyFooter: () => __webpack_require__.e(/* import() */ 1).then(__webpack_require__.bind(null, 81)),
    slideA: () => __webpack_require__.e(/* import() */ 7).then(__webpack_require__.bind(null, 82)),
    slideB: () => __webpack_require__.e(/* import() */ 8).then(__webpack_require__.bind(null, 83)),
    slideC: () => __webpack_require__.e(/* import() */ 9).then(__webpack_require__.bind(null, 84))
  },
  layout: 'desktop',
  transition: {
    name: 'slots',
    mode: 'out-in'
  },

  data() {
    return {
      slides: ['slideA', 'slideB', 'slideC'],
      currentSlide: 0,
      currentTransition: '',
      currentFilter: 'ALL',
      projects: [{
        title: "Pizza",
        image: "https://c1chy.lima-city.de/graphic/Food.png",
        link: "https://c1chy.lima-city.de/Food/index.html",
        technology: "ES6",
        secondTechnology: "WEBPACK",
        category: 'WEBPACK',
        alt: 'Pizza Website'
      }, {
        title: "Cube",
        image: "https://c1chy.lima-city.de/graphic/Portfoliode2.png",
        link: "https://c1chy.lima-city.de/Portfolio2/index.html",
        technology: "ES6",
        secondTechnology: "WEBPACK",
        category: 'WEBPACK',
        alt: 'Cube Website'
      }, {
        title: "Bookstore",
        image: "https://c1chy.lima-city.de/graphic/bookstore.png",
        link: "https://bookstorec1chy.herokuapp.com/",
        technology: "FIREBASE",
        secondTechnology: "DATABASE",
        category: 'REACT',
        alt: 'React Bookstore Website'
      }, {
        title: "Paper Game",
        image: "https://c1chy.lima-city.de/graphic/paperGame.png",
        link: "https://c1chy.lima-city.de/PaperGame/index.html",
        technology: "ES6",
        secondTechnology: "PURE CSS",
        category: 'ES6',
        alt: 'Paper Game Website'
      }, {
        title: "Avenue",
        image: "https://c1chy.lima-city.de/graphic/avenuefasion.png",
        link: "https://c1chy.lima-city.de/psdtohtml1/index.html",
        technology: "PURE CSS",
        secondTechnology: "CSS GRID",
        category: 'PURECSS',
        alt: 'Pure css layout example'
      }, {
        title: "Orders",
        image: "https://c1chy.lima-city.de/graphic/OrderFirebase.png",
        link: "https://c1chy.lima-city.de/FirebaseOrder/index.html",
        technology: "FIREBASE",
        secondTechnology: "DATABASE",
        category: 'DATABASE',
        alt: 'Firebase example'
      }, {
        title: "Panel",
        image: "https://c1chy.lima-city.de/graphic/bootstrap_4.png",
        link: "https://c1chy.lima-city.de/Bootstrap_4/index.html",
        technology: "PURE CSS",
        secondTechnology: "BOOTSTRAP 4",
        category: 'PURECSS',
        alt: 'Bootstrap 4 Panel'
      }, {
        title: "Old Portfolio",
        image: "https://c1chy.lima-city.de/graphic/c1chy_old.png",
        link: "https://c1chy.de/",
        technology: "PURE CSS",
        secondTechnology: "PORTFOLIO",
        category: 'WEBPACK',
        alt: 'Old c1chy portfolio'
      }, {
        title: "API",
        image: "https://c1chy.lima-city.de/graphic/Blogc1chy.png",
        link: "https://c1chy.lima-city.de/Webcomponent/dist/index.html",
        technology: "GITHUB API",
        secondTechnology: "WEB COMPONENTS",
        category: 'ES6',
        alt: 'Api Example'
      }, {
        title: "New Portfolio",
        image: "https://c1chy.lima-city.de/graphic/nuxtportfolio.png",
        link: "https://c1chy.lima-city.de/Food/index.html",
        technology: "NUXT.vue",
        secondTechnology: "TAILWIND CSS",
        category: 'VUE',
        alt: 'New c1chy portfolio'
      }]
    };
  },

  methods: {
    setFilter: function (filter) {
      this.currentFilter = filter;
    },
    changeSlide: function (dir) {
      this.currentSlide = dir === 'next' ? this.currentSlide + 1 : this.currentSlide - 1;
      this.currentTransition = dir;
    }
  },

  beforeMount() {
    fullpage_api.destroy('all');
  }

});
// CONCATENATED MODULE: ./pages/portfolio.vue?vue&type=script&lang=js&
 /* harmony default export */ var pages_portfoliovue_type_script_lang_js_ = (portfoliovue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(2);

// CONCATENATED MODULE: ./pages/portfolio.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(54)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  pages_portfoliovue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "0e648cbd",
  "068f66b4"
  
)

/* harmony default export */ var portfolio = __webpack_exports__["default"] = (component.exports);

/***/ })

};;
//# sourceMappingURL=portfolio.js.map