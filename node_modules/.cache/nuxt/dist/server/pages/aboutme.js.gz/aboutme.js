exports.ids = [3];
exports.modules = {

/***/ 27:
/***/ (function(module, exports) {

// Exports
module.exports = {

};


/***/ }),

/***/ 36:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/4a40484.webp";

/***/ }),

/***/ 37:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/ad4f935.webp";

/***/ }),

/***/ 38:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/3f759fc.webp";

/***/ }),

/***/ 39:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/cfa754d.webp";

/***/ }),

/***/ 40:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/195770b.webp";

/***/ }),

/***/ 41:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/61eb984.webp";

/***/ }),

/***/ 42:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/1c4952d.webp";

/***/ }),

/***/ 43:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/f15835d.webp";

/***/ }),

/***/ 44:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/02a6b98.webp";

/***/ }),

/***/ 45:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/7ca059d.webp";

/***/ }),

/***/ 46:
/***/ (function(module, exports, __webpack_require__) {

module.exports = {
          srcSet: __webpack_require__.p + "img/309bb6b-300.webp"+" 300w"+","+__webpack_require__.p + "img/7b05b43-564.webp"+" 564w",
          images:[ {path: __webpack_require__.p + "img/309bb6b-300.webp",width: 300,height: 463},{path: __webpack_require__.p + "img/7b05b43-564.webp",width: 564,height: 871}],
          src: __webpack_require__.p + "img/309bb6b-300.webp",
          toString:function(){return __webpack_require__.p + "img/309bb6b-300.webp"},
          
          width: 300,
          height: 463
        }

/***/ }),

/***/ 47:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_0_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_1_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_vue_loader_lib_index_js_vue_loader_options_aboutme_vue_vue_type_style_index_0_id_b2709108_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(27);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_0_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_1_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_vue_loader_lib_index_js_vue_loader_options_aboutme_vue_vue_type_style_index_0_id_b2709108_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_0_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_1_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_vue_loader_lib_index_js_vue_loader_options_aboutme_vue_vue_type_style_index_0_id_b2709108_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_0_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_1_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_vue_loader_lib_index_js_vue_loader_options_aboutme_vue_vue_type_style_index_0_id_b2709108_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_0_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_1_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_vue_loader_lib_index_js_vue_loader_options_aboutme_vue_vue_type_style_index_0_id_b2709108_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 76:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./pages/aboutme.vue?vue&type=template&id=b2709108&scoped=true&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"h-screen w-full absolute z-10"},[_vm._ssrNode("<header class=\"container  relative p-24 w-full flex flex-col justify-center grid grid-cols-1 justify-items-center h-112 max-w-full lg:max-w-max  mx-auto  relative overflow-hidden\" data-v-b2709108>","</header>",[_c('light',{staticClass:"overflow-hidden filter-shadow-black"}),_vm._ssrNode(" <div class=\"title uppercase top-2\" data-v-b2709108><h1 class=\"text-8xl font-semibold text-center uppercase\" data-v-b2709108>About Me\n            </h1></div> <div class=\"title_dividers w-1/2 h-4 mx-auto my-10 relative inline-block\" data-v-b2709108><span class=\"w-full h-0.5 absolute left-2/4 transform -translate-x-1/2\" data-v-b2709108></span> <span class=\"w-full h-0.5 top-2 absolute left-2/4 transform -translate-x-1/2\" data-v-b2709108></span> <span class=\"w-full h-0.5 top-4 absolute left-2/4 transform -translate-x-1/2\" data-v-b2709108></span></div> "),_vm._ssrNode("<figure class=\"relative flex items-center justify-center filter-shadow-black z-10\" data-v-b2709108>","</figure>",[_vm._ssrNode("<img"+(_vm._ssrAttr("data-src",__webpack_require__(15)))+" alt=\"ribbon\" class=\"lazyload w-full h-20 my-auto z-1 filter-shadow-black\" data-v-b2709108> "),_vm._ssrNode("<figcaption class=\"absolute block mx-auto mt-5 text-white text-3xl text-center \" data-v-b2709108>","</figcaption>",[_c('NuxtLink',{attrs:{"to":"/"}},[_vm._v("Home")]),_vm._ssrNode("\n              &gt; About Me\n            ")],2)],2)],2),_vm._ssrNode(" <div class=\"page-spacing w-full h-20 absolute left-0 bg-repeat bg-center\" data-v-b2709108></div> <section class=\"about_me w-full h-108 relative\" data-v-b2709108><div class=\" w-3/4 h-28  items-center flex  mx-auto mt-20\" data-v-b2709108><span class=\"w-full inline-block relative 2xl:w-1/2\" data-v-b2709108></span> <h2 class=\" lg:w-1/2 2xl:w-3/12 font-bold text-3xl mt-4 text-center 2xl:mt-8\" data-v-b2709108>WHAT I DO</h2> <span class=\"w-full inline-block relative 2xl:w-1/2\" data-v-b2709108></span></div> <h1 class=\"text-11xl  text-center leading-tight uppercase filter-shadow-green\" data-v-b2709108>WINNING DESIGN</h1></section> <section class=\"about_gallery h-auto grid grid-rows-2 grid-cols-3  gap-x-0  gap-y-16 justify-items-center  2xl:pb-20\" data-v-b2709108><article class=\"bg-center bg-no-repeat\" data-v-b2709108><div data-aos=\"slide-left\" class=\"pic w-11/12\" data-v-b2709108><img"+(_vm._ssrAttr("data-src",__webpack_require__(36)))+" alt=\"website design\" class=\"lazyload\" data-v-b2709108> <h2 class=\"w-1/2 relative m-auto p-2 mt-6 flex justify-center text-2xl font-semibold uppercase\" data-v-b2709108>\n              Website Design\n            </h2></div></article> <article class=\"bg-center bg-no-repeat\" data-v-b2709108><div data-aos=\"rotate\" data-aos-delay=\"300\" class=\"pic w-11/12\" data-v-b2709108><img"+(_vm._ssrAttr("data-src",__webpack_require__(37)))+" alt=\"digital design\" class=\"lazyload\" data-v-b2709108> <h2 class=\"w-1/2 relative m-auto p-2 mt-6 flex justify-center text-2xl font-semibold uppercase\" data-v-b2709108>\n              Digital Design\n            </h2></div></article> <article class=\"bg-center bg-no-repeat\" data-v-b2709108><div data-aos=\"slide-right\" class=\"pic w-11/12\" data-v-b2709108><img"+(_vm._ssrAttr("data-src",__webpack_require__(38)))+" alt=\"branding\" class=\"lazyload\" data-v-b2709108> <h2 class=\"w-1/2 relative m-auto p-2 mt-6 flex justify-center text-2xl font-semibold uppercase\" data-v-b2709108>\n              Branding\n            </h2></div></article> <article class=\"bg-center bg-no-repeat\" data-v-b2709108><div data-aos=\"slide-left\" class=\"pic w-11/12\" data-v-b2709108><img"+(_vm._ssrAttr("data-src",__webpack_require__(39)))+" alt=\"graphic design\" class=\"lazyload\" data-v-b2709108> <h2 class=\"w-1/2 relative m-auto p-2 mt-6 flex justify-center text-2xl font-semibold uppercase\" data-v-b2709108>\n              Graphic Design\n            </h2></div></article> <article class=\"bg-center bg-no-repeat\" data-v-b2709108><div data-aos=\"rotate\" data-aos-delay=\"300\" class=\"pic w-11/12\" data-v-b2709108><img"+(_vm._ssrAttr("data-src",__webpack_require__(40)))+" alt=\"mobile apps\" class=\"lazyload\" data-v-b2709108> <h2 class=\"w-1/2 relative m-auto p-2 mt-6 flex justify-center text-2xl font-semibold uppercase\" data-v-b2709108>\n              Mobile Apps\n            </h2></div></article> <article class=\"bg-center bg-no-repeat\" data-v-b2709108><div data-aos=\"slide-right\" class=\"pic w-11/12\" data-v-b2709108><img"+(_vm._ssrAttr("data-src",__webpack_require__(41)))+" alt=\"design concept\" class=\"lazyload\" data-v-b2709108> <h2 class=\"w-1/2 relative m-auto p-2  mt-6 flex justify-center text-2xl font-semibold uppercase\" data-v-b2709108>\n              Design Concept\n            </h2></div></article></section> "),_vm._ssrNode("<section class=\"mission h-auto flex   lg:pt-12 lg:mt-16  lg:pb-32  2xl:mt-0  2xl:pb-12\" data-v-b2709108>","</section>",[_c('transition',{attrs:{"name":"fade"}},[(_vm.isShowing)?_c('div',{ref:"modal",staticClass:"lazyload modal flex w-full z-40 xl:mt-10 xl:ml-2"},[_c('img',{staticClass:"lazyload",attrs:{"data-src":__webpack_require__(42),"src":_vm.marlboro.src,"srcSet":_vm.marlboro.srcSet}}),_vm._v(" "),_c('article',{staticClass:"flex flex-col justify-center leading-snug"},[_c('button',{ref:"button",staticClass:"Icon relative self-end mt-6 right-4",attrs:{"id":"icon"},on:{"click":_vm.closeModal}},[_c('span'),_vm._v(" "),_c('span'),_vm._v(" "),_c('span')]),_vm._v(" "),_c('h1',{staticClass:"vectro px-3"},[_c('span',{staticClass:"vectro-body"},[_vm._v("TRY")])]),_vm._v(" "),_c('h1',{staticClass:"vectro px-3"},[_c('span',{staticClass:"vectro-body"},[_vm._v("IDEAS")]),_c('span',{staticClass:"vectro-red"},[_vm._v("I")])]),_vm._v(" "),_c('h1',{staticClass:"vectro px-3 "},[_c('span',{staticClass:"vectro-body"},[_vm._v("PLANS")]),_c('span',{staticClass:"vectro-red"},[_vm._v("I")]),_c('span',{staticClass:"vectro-green"},[_vm._v("I")])]),_vm._v(" "),_c('h1',{staticClass:"vectro px-3"},[_c('span',{staticClass:"vectro-body"},[_vm._v("PROGRESS")]),_c('span',{staticClass:"vectro-red"},[_vm._v("I")]),_c('span',{staticClass:"vectro-green"},[_vm._v("I")]),_c('span',{staticClass:"vectro-blue"},[_vm._v("I")])])])]):_vm._e()]),_vm._ssrNode(" <div class=\"mission_left  w-1/2  lg:pl-16  2xl:pl-24 2xl:pt-16  z-20\" data-v-b2709108><div class=\"flex\" data-v-b2709108><h3 class=\"w-1/3 font-bold text-3xl mt-4 ml-2 text-left\" data-v-b2709108>CORE PRINCIPLES</h3> <span class=\"w-10/12 inline-block relative self-center\" data-v-b2709108></span></div> <h1 class=\"text-10xl font-semibold leading-none uppercase\" data-v-b2709108>MISSION</h1> <p"+(_vm._ssrClass("w-10/12 text-2xl text-left mt-12 mb-8 z-10",[_vm.isShowing ? _vm.blurClass : '', _vm.bkClass]))+" data-v-b2709108>Das Internet ist groß und bunt. Hier gibt es keine Standard-Lösung, sondern es sind immer individuelle Ansätze gefragt. Ich finde für meine Kunden neue Ideen und Konzepte, die wir engagiert und mit dem nötigen Know-how umsetzen.Websites, die nicht auf Smartphones oder Tablets angezeigt werden können, sperren sich einem stetig wachsenden Markt. Mit Responsive Design mache ich Webseiten fit für den Einsatz immer und überall.</p> <button class=\"button_red fade lg:hidden 2xl:block\" data-v-b2709108>"+((_vm.isShowing)?("<span data-v-b2709108>HIDE</span>"):("<span data-v-b2709108>SHOW</span>"))+"\n        MY APPROACH\n\n        </button></div> <div class=\"mission_right w-1/2 grid grid-cols-2 grid-rows-2 gap-x-0\" data-v-b2709108><div class=\"h-72 w-72 m-auto cursor-pointer\" data-v-b2709108><svg aria-hidden=\"true\" focusable=\"false\" data-prefix=\"far\" data-icon=\"lightbulb\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 352 512\" class=\"svg-inline--fa fa-lightbulb fa-w-11\" data-v-b2709108><path fill=\"#e9e4dc\" d=\"M176 80c-52.94 0-96 43.06-96 96 0 8.84 7.16 16 16 16s16-7.16 16-16c0-35.3 28.72-64 64-64 8.84 0 16-7.16 16-16s-7.16-16-16-16zM96.06 459.17c0 3.15.93 6.22 2.68 8.84l24.51 36.84c2.97 4.46 7.97 7.14 13.32 7.14h78.85c5.36 0 10.36-2.68 13.32-7.14l24.51-36.84c1.74-2.62 2.67-5.7 2.68-8.84l.05-43.18H96.02l.04 43.18zM176 0C73.72 0 0 82.97 0 176c0 44.37 16.45 84.85 43.56 115.78 16.64 18.99 42.74 58.8 52.42 92.16v.06h48v-.12c-.01-4.77-.72-9.51-2.15-14.07-5.59-17.81-22.82-64.77-62.17-109.67-20.54-23.43-31.52-53.15-31.61-84.14-.2-73.64 59.67-128 127.95-128 70.58 0 128 57.42 128 128 0 30.97-11.24 60.85-31.65 84.14-39.11 44.61-56.42 91.47-62.1 109.46a47.507 47.507 0 0 0-2.22 14.3v.1h48v-.05c9.68-33.37 35.78-73.18 52.42-92.16C335.55 260.85 352 220.37 352 176 352 78.8 273.2 0 176 0z\" data-v-b2709108></path></svg> <h2 class=\" relative justify-center m-auto top-4 p-1 lg:w-2/3 lg:text-2xl xl2:text-4xl 2xl:w-full text-center font-semibold uppercase z-0 \" data-v-b2709108>\n            DRIVEN CREATIVE\n          </h2></div> <div class=\"h-72 w-72 m-auto cursor-pointer\" data-v-b2709108><svg aria-hidden=\"true\" focusable=\"false\" data-prefix=\"far\" data-icon=\"handshake\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 640 512\" class=\"h-3/5 svg-inline--fa fa-handshake fa-w-20\" data-v-b2709108><path fill=\"#e9e4dc\" d=\"M519.2 127.9l-47.6-47.6A56.252 56.252 0 0 0 432 64H205.2c-14.8 0-29.1 5.9-39.6 16.3L118 127.9H0v255.7h64c17.6 0 31.8-14.2 31.9-31.7h9.1l84.6 76.4c30.9 25.1 73.8 25.7 105.6 3.8 12.5 10.8 26 15.9 41.1 15.9 18.2 0 35.3-7.4 48.8-24 22.1 8.7 48.2 2.6 64-16.8l26.2-32.3c5.6-6.9 9.1-14.8 10.9-23h57.9c.1 17.5 14.4 31.7 31.9 31.7h64V127.9H519.2zM48 351.6c-8.8 0-16-7.2-16-16s7.2-16 16-16 16 7.2 16 16c0 8.9-7.2 16-16 16zm390-6.9l-26.1 32.2c-2.8 3.4-7.8 4-11.3 1.2l-23.9-19.4-30 36.5c-6 7.3-15 4.8-18 2.4l-36.8-31.5-15.6 19.2c-13.9 17.1-39.2 19.7-55.3 6.6l-97.3-88H96V175.8h41.9l61.7-61.6c2-.8 3.7-1.5 5.7-2.3H262l-38.7 35.5c-29.4 26.9-31.1 72.3-4.4 101.3 14.8 16.2 61.2 41.2 101.5 4.4l8.2-7.5 108.2 87.8c3.4 2.8 3.9 7.9 1.2 11.3zm106-40.8h-69.2c-2.3-2.8-4.9-5.4-7.7-7.7l-102.7-83.4 12.5-11.4c6.5-6 7-16.1 1-22.6L367 167.1c-6-6.5-16.1-6.9-22.6-1l-55.2 50.6c-9.5 8.7-25.7 9.4-34.6 0-9.3-9.9-8.5-25.1 1.2-33.9l65.6-60.1c7.4-6.8 17-10.5 27-10.5l83.7-.2c2.1 0 4.1.8 5.5 2.3l61.7 61.6H544v128zm48 47.7c-8.8 0-16-7.2-16-16s7.2-16 16-16 16 7.2 16 16c0 8.9-7.2 16-16 16z\" data-v-b2709108></path></svg> <h2 class=\"w-full relative justify-center m-auto top-4 p-1 lg:w-2/3 lg:text-2xl xl2:text-4xl 2xl:w-full text-center font-semibold uppercase z-0 \" data-v-b2709108>\n            HONEST WORK\n          </h2></div> <div class=\"h-72 w-72 m-auto cursor-pointer\" data-v-b2709108><svg aria-hidden=\"true\" focusable=\"false\" data-prefix=\"fas\" data-icon=\"laptop-house\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 24 695 537\" class=\"svg-inline--fa fa-laptop-house fa-w-20\" data-v-b2709108><path fill=\"#e9e4dc\" d=\"M272,288H208a16,16,0,0,1-16-16V208a16,16,0,0,1,16-16h64a16,16,0,0,1,16,16v37.12C299.11,232.24,315,224,332.8,224H469.74l6.65-7.53A16.51,16.51,0,0,0,480,207a16.31,16.31,0,0,0-4.75-10.61L416,144V48a16,16,0,0,0-16-16H368a16,16,0,0,0-16,16V87.3L263.5,8.92C258,4,247.45,0,240.05,0s-17.93,4-23.47,8.92L4.78,196.42A16.15,16.15,0,0,0,0,207a16.4,16.4,0,0,0,3.55,9.39L22.34,237.7A16.22,16.22,0,0,0,33,242.48,16.51,16.51,0,0,0,42.34,239L64,219.88V384a32,32,0,0,0,32,32H272ZM629.33,448H592V288c0-17.67-12.89-32-28.8-32H332.8c-15.91,0-28.8,14.33-28.8,32V448H266.67A10.67,10.67,0,0,0,256,458.67v10.66A42.82,42.82,0,0,0,298.6,512H597.4A42.82,42.82,0,0,0,640,469.33V458.67A10.67,10.67,0,0,0,629.33,448ZM544,448H352V304H544Z\" data-v-b2709108></path></svg> <h2 class=\"w-full relative justify-center m-auto top-4 p-1 lg:w-2/3 lg:text-2xl xl2:text-4xl 2xl:w-full text-center font-semibold uppercase z-0 \" data-v-b2709108>\n            MAKE AN IMPACT\n          </h2></div> <div class=\"h-72 w-72 m-auto cursor-pointer\" data-v-b2709108><svg aria-hidden=\"true\" focusable=\"false\" data-prefix=\"far\" data-icon=\"save\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 -15 420 585\" class=\"svg-inline--fa fa-save fa-w-14\" data-v-b2709108><path fill=\"#e9e4dc\" d=\"M433.941 129.941l-83.882-83.882A48 48 0 0 0 316.118 32H48C21.49 32 0 53.49 0 80v352c0 26.51 21.49 48 48 48h352c26.51 0 48-21.49 48-48V163.882a48 48 0 0 0-14.059-33.941zM272 80v80H144V80h128zm122 352H54a6 6 0 0 1-6-6V86a6 6 0 0 1 6-6h42v104c0 13.255 10.745 24 24 24h176c13.255 0 24-10.745 24-24V83.882l78.243 78.243a6 6 0 0 1 1.757 4.243V426a6 6 0 0 1-6 6zM224 232c-48.523 0-88 39.477-88 88s39.477 88 88 88 88-39.477 88-88-39.477-88-88-88zm0 128c-22.056 0-40-17.944-40-40s17.944-40 40-40 40 17.944 40 40-17.944 40-40 40z\" data-v-b2709108></path></svg> <h2 class=\"w-full relative justify-center m-auto top-4 p-1 lg:w-2/3 lg:text-2xl xl2:text-4xl 2xl:w-full text-center font-semibold uppercase z-0 \" data-v-b2709108>\n            HUMBLE COURAGE\n          </h2></div></div>")],2),_vm._ssrNode(" "),_vm._ssrNode("<section class=\"principles overflow-x-hidden\" data-v-b2709108>","</section>",[_vm._ssrNode("<div class=\"about_me w-3/4 h-28  items-center flex  mx-auto mt-8  2xl:mt-0\" data-v-b2709108><span class=\"w-full inline-block relative 2xl:w-2/3\" data-v-b2709108></span> <h3 class=\"w-1/2 font-bold text-3xl mt-4 text-center 2xl:mt-8\" data-v-b2709108>WHAT I'M WORKING ON</h3> <span class=\"w-full inline-block relative 2xl:w-2/3\" data-v-b2709108></span></div> <h1 class=\"text-11xl font-bold text-center leading-tight mb-20 filter-shadow-green\" data-v-b2709108>CORE PRINCIPLES</h1> <div class=\" w-full flex pb-16 items-end text-center mb-8  2xl:pb-16 2xl:mb-0 \" data-v-b2709108><article data-aos=\"fade-left\" data-aos-delay=\"1750\" data-aos-anchor=\"#site-footer\" class=\"h-full w-1/3\" data-v-b2709108><h2 class=\"w-1/3 relative m-auto p-1 flex justify-center lg:text-2xl 2xl:text-3xl font-semibold uppercase\" data-v-b2709108>\n              Verstehen\n            </h2> <img"+(_vm._ssrAttr("data-src",__webpack_require__(43)))+" alt=\"Verstehen Frontend\" class=\"lazyload m-auto\" data-v-b2709108> <p class=\"w-2/3 m-auto text-2xl\" data-v-b2709108>Mein erster Schritt in jedem Projekt: Ihre Bedürfnisse, Wünsche und Erwartungen nachvollziehen – und die Ihrer User.</p> <a href=\"#\" class=\"button_red inline-block fade uppercase\" data-v-b2709108>Lern Mehr\n\n            </a></article> <article data-aos-delay=\"1250\" data-aos=\"fade-up\" data-aos-anchor=\"#site-footer\" class=\"h-full w-1/3 \" data-v-b2709108><h2 class=\"w-1/3 relative m-auto p-1 flex justify-center lg:text-2xl 2xl:text-3xl font-semibold uppercase\" data-v-b2709108>\n              Entwickeln\n            </h2> <img"+(_vm._ssrAttr("data-src",__webpack_require__(44)))+" alt=\"Entwickeln Frontend\" class=\"lazyload m-auto\" data-v-b2709108> <p class=\"w-2/3 m-auto text-2xl\" data-v-b2709108>Auf dieser Grundlage ermittle ich mögliche Lösungswege und entwerfe erste konkrete Ansätze. </p> <a href=\"#\" class=\"button_red inline-block fade uppercase\" data-v-b2709108>Lern Mehr</a></article> <article data-aos=\"fade-right\" data-aos-delay=\"1750\" data-aos-anchor=\"#site-footer\" class=\"h-full w-1/3\" data-v-b2709108><h2 class=\"w-1/3 relative m-auto p-1 flex justify-center lg:text-2xl 2xl:text-3xl font-semibold uppercase\" data-v-b2709108>\n              Umsetzen\n            </h2> <img"+(_vm._ssrAttr("data-src",__webpack_require__(45)))+" alt=\"Umsetzen Frontend\" class=\"lazyload m-auto\" data-v-b2709108> <p class=\"w-2/3 m-auto mb-4 text-2xl\" data-v-b2709108>Ich stimme meine Ideen mit Ihnen ab. Ich übertrage den geplanten Maßnahmen und beginne mit der technischen Umsetzung.</p> <a href=\"#\" class=\"button_red inline-block fade uppercase\" data-v-b2709108>Lern Mehr</a></article></div> "),_c('stickyFooter',{staticClass:"opacity-100",attrs:{"data-aos":"slide-right","data-aos-duration":"1000"}})],2)],2)}
var staticRenderFns = []


// CONCATENATED MODULE: ./pages/aboutme.vue?vue&type=template&id=b2709108&scoped=true&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./pages/aboutme.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
const marlboro = __webpack_require__(46);

/* harmony default export */ var aboutmevue_type_script_lang_js_ = ({
  components: {
    light: () => __webpack_require__.e(/* import() */ 0).then(__webpack_require__.bind(null, 80)),
    stickyFooter: () => __webpack_require__.e(/* import() */ 1).then(__webpack_require__.bind(null, 81))
  },
  layout: 'desktop',

  data() {
    return {
      marlboro,
      animate: true,
      isShowing: false,
      bkClass: 'bk',
      blurClass: 'blur',
      show: false
    };
  },

  transition: {
    name: 'spotlight',
    mode: 'out-in'
  },
  methods: {
    toggleModal() {
      document.querySelector('.mission').scrollIntoView({
        behavior: 'smooth'
      });
      setTimeout(() => {
        this.isShowing = !this.isShowing;

        if (!this.isShowing) {
          this.$refs.modal.classList.add('out');
        }
      }, 500);
    },

    closeModal() {
      this.$refs.button.classList.add('close');
      setTimeout(() => {
        this.$refs.modal.classList.add('out');
      }, 500);
      setTimeout(() => {
        this.isShowing = false;
      }, 500);
    }

  },

  beforeMount() {
    fullpage_api.destroy('all');
  }

});
// CONCATENATED MODULE: ./pages/aboutme.vue?vue&type=script&lang=js&
 /* harmony default export */ var pages_aboutmevue_type_script_lang_js_ = (aboutmevue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(2);

// CONCATENATED MODULE: ./pages/aboutme.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(47)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  pages_aboutmevue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "b2709108",
  "8e9c1c5e"
  
)

/* harmony default export */ var aboutme = __webpack_exports__["default"] = (component.exports);

/***/ })

};;
//# sourceMappingURL=aboutme.js.map