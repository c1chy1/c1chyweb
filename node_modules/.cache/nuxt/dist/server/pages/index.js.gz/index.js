exports.ids = [5];
exports.modules = {

/***/ 30:
/***/ (function(module, exports) {

// Exports
module.exports = {

};


/***/ }),

/***/ 55:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/f12c44e.png";

/***/ }),

/***/ 56:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/dc06245.webp";

/***/ }),

/***/ 57:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/03dbf7a.png";

/***/ }),

/***/ 58:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/e2b847a.webp";

/***/ }),

/***/ 59:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/9165f14.webp";

/***/ }),

/***/ 60:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/9fec52e.webp";

/***/ }),

/***/ 61:
/***/ (function(module, exports, __webpack_require__) {

module.exports = {
          srcSet: __webpack_require__.p + "img/5f10a6b-150.webp"+" 150w"+","+__webpack_require__.p + "img/810eed3-400.webp"+" 400w",
          images:[ {path: __webpack_require__.p + "img/5f10a6b-150.webp",width: 150,height: 80},{path: __webpack_require__.p + "img/810eed3-400.webp",width: 400,height: 213}],
          src: __webpack_require__.p + "img/5f10a6b-150.webp",
          toString:function(){return __webpack_require__.p + "img/5f10a6b-150.webp"},
          
          width: 150,
          height: 80
        }

/***/ }),

/***/ 62:
/***/ (function(module, exports, __webpack_require__) {

module.exports = {
          srcSet: __webpack_require__.p + "img/124d42e-150.webp"+" 150w"+","+__webpack_require__.p + "img/e670645-378.webp"+" 378w",
          images:[ {path: __webpack_require__.p + "img/124d42e-150.webp",width: 150,height: 208},{path: __webpack_require__.p + "img/e670645-378.webp",width: 378,height: 524}],
          src: __webpack_require__.p + "img/124d42e-150.webp",
          toString:function(){return __webpack_require__.p + "img/124d42e-150.webp"},
          
          width: 150,
          height: 208
        }

/***/ }),

/***/ 63:
/***/ (function(module, exports, __webpack_require__) {

module.exports = {
          srcSet: __webpack_require__.p + "img/7e47f34-150.webp"+" 150w"+","+__webpack_require__.p + "img/f1c895d-600.webp"+" 600w"+","+__webpack_require__.p + "img/7a684ab-650.webp"+" 650w",
          images:[ {path: __webpack_require__.p + "img/7e47f34-150.webp",width: 150,height: 65},{path: __webpack_require__.p + "img/f1c895d-600.webp",width: 600,height: 261},{path: __webpack_require__.p + "img/7a684ab-650.webp",width: 650,height: 283}],
          src: __webpack_require__.p + "img/7e47f34-150.webp",
          toString:function(){return __webpack_require__.p + "img/7e47f34-150.webp"},
          
          width: 150,
          height: 65
        }

/***/ }),

/***/ 64:
/***/ (function(module, exports, __webpack_require__) {

module.exports = {
          srcSet: __webpack_require__.p + "img/fdc671d-150.webp"+" 150w"+","+__webpack_require__.p + "img/0a15d2c-395.webp"+" 395w",
          images:[ {path: __webpack_require__.p + "img/fdc671d-150.webp",width: 150,height: 214},{path: __webpack_require__.p + "img/0a15d2c-395.webp",width: 395,height: 564}],
          src: __webpack_require__.p + "img/fdc671d-150.webp",
          toString:function(){return __webpack_require__.p + "img/fdc671d-150.webp"},
          
          width: 150,
          height: 214
        }

/***/ }),

/***/ 65:
/***/ (function(module, exports, __webpack_require__) {

module.exports = {
          srcSet: __webpack_require__.p + "img/babb1e7-150.webp"+" 150w"+","+__webpack_require__.p + "img/c6f4c95-338.webp"+" 338w",
          images:[ {path: __webpack_require__.p + "img/babb1e7-150.webp",width: 150,height: 232},{path: __webpack_require__.p + "img/c6f4c95-338.webp",width: 338,height: 523}],
          src: __webpack_require__.p + "img/babb1e7-150.webp",
          toString:function(){return __webpack_require__.p + "img/babb1e7-150.webp"},
          
          width: 150,
          height: 232
        }

/***/ }),

/***/ 66:
/***/ (function(module, exports, __webpack_require__) {

module.exports = {
          srcSet: __webpack_require__.p + "img/062903e-150.webp"+" 150w"+","+__webpack_require__.p + "img/531ab9c-564.webp"+" 564w",
          images:[ {path: __webpack_require__.p + "img/062903e-150.webp",width: 150,height: 200},{path: __webpack_require__.p + "img/531ab9c-564.webp",width: 564,height: 752}],
          src: __webpack_require__.p + "img/062903e-150.webp",
          toString:function(){return __webpack_require__.p + "img/062903e-150.webp"},
          
          width: 150,
          height: 200
        }

/***/ }),

/***/ 67:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_0_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_1_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_vue_loader_lib_index_js_vue_loader_options_index_vue_vue_type_style_index_0_id_09e7a3ad_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(30);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_0_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_1_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_vue_loader_lib_index_js_vue_loader_options_index_vue_vue_type_style_index_0_id_09e7a3ad_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_0_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_1_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_vue_loader_lib_index_js_vue_loader_options_index_vue_vue_type_style_index_0_id_09e7a3ad_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_0_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_1_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_vue_loader_lib_index_js_vue_loader_options_index_vue_vue_type_style_index_0_id_09e7a3ad_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_0_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_1_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_vue_loader_lib_index_js_vue_loader_options_index_vue_vue_type_style_index_0_id_09e7a3ad_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 79:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./pages/index.vue?vue&type=template&id=09e7a3ad&scoped=true&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('full-page',{staticClass:"w-screen h-screen  absolute z-10 cursor-default container px-0 md:px-0  max-w-full lg:max-w-max  mx-auto",attrs:{"id":"fullpage","options":_vm.options}},[_c('section',{staticClass:"fp-section w-full overflow-hidden bg-no-repeat bg-cover bg-center opacity-100  xl:rounded-4xl  filter-shadow-black z-10 "},[_c('light'),_vm._v(" "),_c('div',{staticClass:"w-full h-screen relative fill-40 flex flex-col   justify-between    sm:justify-end ",staticStyle:{"background-image":"radial-gradient(transparent, rgba(0, 0, 0, 0.6))"}},[_c('div',{staticClass:"lazyload circle_bg circle1 absolute w-2 px-4 py-2 ml-12 bg-white hidden   2xl:block 2xl:w-20 2xl:p-5 z-50"}),_vm._v(" "),_c('div',{staticClass:"lazyload circle_bg  circle2 absolute w-4 px-3 py-2 ml-6 bg-white hidden  2xl:block 2xl:w-16 2xl:p-4  z-40"}),_vm._v(" "),_c('div',{staticClass:"lazyload circle_bg circle3  absolute w-8 px-2 py-1   bg-white hidden   2xl:block 2xl:p-2 z-30"}),_vm._v(" "),_c('img',{staticClass:"logo lazyload  self-center relative w-10/12 sm:w-1/3 md:w-40 portrait:w-1/2 lg:w-1/3 xl:w-1/4\n\n\n        xl:top-12 relative z-50",class:'animate__animated animate__tada animate__delay-8s animate__repeat-2',attrs:{"data-src":__webpack_require__(55),"srcset":_vm.logo.srcSet,"src":_vm.logo.src,"width":_vm.logo.width,"height":_vm.logo.height,"alt":"c1chy"}}),_vm._v(" "),_c('img',{staticClass:"hat lazyload relative self-center w-3/5 sm:w-32  md:1/2 portrait:w-1/2 lg:w-1/4  xl:top-12 xl:w-1/5 z-20",attrs:{"data-src":__webpack_require__(56),"srcSet":_vm.hat.srcSet,"src":_vm.hat.src,"width":_vm.hat.width,"height":_vm.hat.height,"sizes":"(min-width: 768px) 60vw, 95vw","alt":"rainbow balloon"}}),_vm._v(" "),_c('img',{staticClass:"body lazyload self-center w-full h-1/3 sm:w-2/5 sm:h-auto md:w-2/3 lg:w-5/12\n\n\n\n                xl:w-1/2 2xl:w-1/3 filter-shadow-black ",attrs:{"data-src":__webpack_require__(57),"srcSet":_vm.body.srcSet,"src":_vm.body.src,"width":_vm.body.width,"height":_vm.body.height,"sizes":"(min-width: 768px) 60vw, 95vw","alt":"vintage body"}}),_vm._v(" "),_c('figure',{staticClass:"ribbon flex bottom-20 absolute w-8/12 sm:justify-center  xl:w-2/5 2xl:w-1/3  self-center   filter-shadow-black z-10 "},[_c('img',{staticClass:"lazyload absolute  sm:w-1/2 md:w-2/3 lg:w-full 2xl:w-full filter-shadow-black z-10",attrs:{"data-src":__webpack_require__(15),"alt":"ribbon"}}),_vm._v(" "),_c('figcaption',{staticClass:"mx-auto mt-2   text-xs text-white text-center my-auto  md:text-xl lg:text-xl  xl:mt-4 xl:tracking-wider    2xl:mt-5 z-20"},[_vm._v("\n              Visually Striking Design ")])])]),_vm._v(" "),_c('div',{staticClass:"hidden sm:block bottom-0 right-2 absolute lg:pr-2 2xl:block 2xl:right-0 2xl:absolute 2xl:bottom-0 2xl:mb-3 2xl:mr-3 text-center tracking-widest md:text-left z-10"},[_c('div',{staticClass:"classic sm:mb-3 md:absolute  lg:text-center 2xl:block 2xl:relative 2xl:right-1/3 "},[_c('span',{staticClass:"intro intro--the block text-3xl"},[_vm._v("The")]),_vm._v(" "),_c('span',{staticClass:"intro intro--num block text inline-block absolute font-semibold sm:hidden lg:inline"},[_vm._v("first #1")]),_vm._v(" "),_c('span',{staticClass:"intro block  sm:text-xl 2xl:text-4xl"},[_vm._v("classic style")])]),_vm._v(" "),_c('div',{staticClass:"vintage__container block md:absolute lg:relative 2xl:relative "},[_c('p',{staticClass:"vintage vintage__top  m-0 text-6xl leading-none sm:hidden md:absolute md:text-5xl lg:absolute 2xl:absolute 2xl:block 2xl:text-center 2xl:w-full"},[_vm._v("VINTAGE")]),_vm._v(" "),_c('p',{staticClass:"vintage vintage__bot  m-0 text-6xl leading-none sm:hidden md:absolute md:text-5xl lg:absolute 2xl:relative 2xl:block 2xl:text-center"},[_vm._v("VINTAGE")])]),_vm._v(" "),_c('div',{staticClass:"sm:hidden md:hidden 2xl:block 2xl:right-0 2xl:mt-2 2xl:tracking-wide"},[_c('span',{staticClass:"outro pt-4 text-white text-xl "},[_vm._v("NO.01")]),_vm._v(" "),_c('span',{staticClass:"outro  text-white text-3xl font-sans"},[_vm._v("OLDSCHOOL RECREATED")]),_vm._v(" "),_c('span',{staticClass:"outro text-white text-xl"},[_vm._v("BEST")]),_vm._v(" "),_c('span',{staticClass:"outro block text-white text-xl 2xl:text-center"},[_vm._v("c1chy.web")])])])],1),_vm._v(" "),_c('section',{staticClass:"fp-section w-full  relative bg-repeat bg-scroll opacity-100 overflow-hidden z-10 xl:rounded-4xl  "},[_c('div',{staticClass:"welcome_studio w-full pt-4 flex flex-col justify-content-between items-center text-center box-border leading-tight"},[_c('div',{staticClass:"w-full h-28  items-center flex  mx-auto 2xl:mt-16"},[_c('span',{staticClass:"w-11/12 inline-block relative self-start"}),_vm._v(" "),_c('h1',{staticClass:"w-full font-bold text-2xl mt-2 sm:w-full sm:text-2xl md:w-full md:mt-0 md:text-5xl  xl:text-2xl  2xl:text-4xl   "},[_vm._v("WELCOME TO STUDIO")]),_vm._v(" "),_c('span',{staticClass:"w-11/12 inline-block relative self-start"})]),_vm._v(" "),_c('article',{staticClass:"bg-center bg-no-repeat leading-none "},[_c('h1',{staticClass:"hidden inline text-5xl font-bold uppercase 2xl:block 2xl:text-11xl 2xl:mt-4 "},[_vm._v("c1chy's studio")]),_vm._v(" "),_c('figure',{staticClass:"h-full w-8/12 relative m-auto flex items-center filter-shadow-black z-10 hidden sm:flex sm:w-1/2 sm:mt-4 md:w-1/2 lg:w-full xl:w-2/3 2xl:w-2/3 2xl:mt-0 2xl:mb-1 z-20"},[_c('img',{staticClass:"lazyload xl:text-center filter-shadow-black ",attrs:{"srcSet":__webpack_require__(15),"alt":"ribbon"}}),_vm._v(" "),_c('figcaption',{staticClass:"w-full my-auto mt-3 block absolute text-xl text-center text-white sm:text-xl sm:tracking-wide md:sm:tracking-widest xl:tracking-mega xl:mt-4 2xl:tracking-wider 2xl:text-4xl 2xl:mt-6 2xl:ml-2 "},[_vm._v("\n                ✪ ✪ ✪ ✪ ✪ ✪ ✪\n              ")])])])]),_vm._v(" "),_c('div',{staticClass:"scumbag w-full flex  flex-col  xl:flex-row  justify-center bg-repeat bg-auto bg-center z-2 xl:rounded-4xl"},[_c('div',{ref:"welcomeStudio",staticClass:"text-center mt-3 pt-1 xl:w-1/2 lg:w-2/3 2xl:w-1/2"},[_c('div',[_c('h2',{staticClass:"text-xl md:text-4xl lg:text-5xl  2xl:text-2xl 2xl:text-4xl 2xl:font-bold 2xl:text-center"},[_vm._v("\n                Klare Strategie , ausdrucksstarkes "),_c('br'),_vm._v(" Design & moderne Technologie. ")])]),_vm._v(" "),_c('div',{staticClass:"w-full  px-1 pt-5 leading-loose md:w-full xl:text-xl xl:mt-2  2xl:pt-3 2xl:mt-4 2xl:flex "},[_c('ul',{staticClass:" mb-16 text-xs text-center  md:text-2xl lg:text-2xl xl:text-xl xl:border-purple-700 2xl:mb-0 2xl:p-1 2xl:text-xl "},[_c('li',[_c('h3',[_vm._v("APP-Entwicklung")])]),_vm._v(" "),_c('li',[_c('h3',[_vm._v("Responsive Webdesign")])]),_vm._v(" "),_c('li',[_c('h3',[_vm._v("SEO + Sichtbarkeit")])])]),_vm._v(" "),_c('p',{staticClass:"hidden sm:hidden md:hidden md:block  md:text-2xl lg:hidden xl:text-xl  xl:hidden 2xl:w-1/2 2xl:p-1 2xl:m-auto 2xl:block 2xl:text-xl"},[_vm._v("\n                Webseiten der neuen Generation, die mit dem Ziel erstellt werden, Arbeit durch Innovation zu transformieren. ")])])]),_vm._v(" "),_c('img',{ref:"scumbag",staticClass:"wolf lazyload  w-1/2 rounded-4xl sm:hidden md:block xl:w-2/5 2xl:w-1/4 opacity-0  z-10 ",attrs:{"data-src":__webpack_require__(58),"src":_vm.scumbag.src,"srcSet":_vm.scumbag.srcSet,"width":_vm.scumbag.width,"height":_vm.scumbag.height,"sizes":"(min-width: 1024px) 1024px, 100vw","alt":"vintage wolf"}}),_vm._v(" "),_c('div',{staticClass:"background h-2/5 absolute right-0 top-3/4 opacity-70 "})])]),_vm._v(" "),_c('section',{staticClass:"fp-section  w-full relative overflow-hidden box-content xl:rounded-4xl z-0 "},[_c('div',{staticClass:"bg_stars h-full w-full flex flex-col justify-evenly sm:flex-row  md:flex-col xl:flex-row-reverse text-white z-0 "},[_c('div',{staticClass:"w-5/12 self-center lg:w-1/3  lg:h-full lg:flex lg:flex-col lg:justify-evenly"},[_c('h2',{staticClass:"text-center  text-xl xl:text-3xl 2xl:text-5xl "},[_vm._v("\n              Strategie, Technologie, "),_c('br'),_vm._v(" App & Content ")]),_vm._v(" "),_c('p',{staticClass:"hidden text-xs xl:block xl:text-xl 2xl:text-xl ",class:[_vm.isShowing ? _vm.blurClass : '', _vm.bkClass]},[_vm._v("\n              An der Schnittstelle von Technik entwickle ich digitale Anwendungen,\n              die mit durchdachter Benutzerführung und ausgefeilter Funktionalität überzeugen – egal,\n              auf welchem Gerät. Dazu erprobe ich neuartige Methoden, beschäftige mich intensiv mit aufregenden Technologien,\n              experimentiere mit neuen Herangehensweisen.")]),_vm._v(" "),_c('button',{staticClass:"button_red text-center px-4 py-2 relative hidden lg:hidden xl:hidden 2xl:block 2xl:w-1/2 2xl:text-3xl",on:{"click":_vm.toggleModal}},[(_vm.isShowing)?_c('span',[_vm._v("HIDE HOW !")]):_c('span',[_vm._v("SHOW ME HOW !")])]),_vm._v(" "),_c('transition',{attrs:{"name":"fade"}},[(_vm.isShowing)?_c('div',{ref:"modal",staticClass:"lazyload modal flex w-full"},[_c('img',{staticClass:"lazyload",attrs:{"data-src":__webpack_require__(59),"src":_vm.walkman.src,"srcSet":_vm.walkman.srcSet,"alt":"vintage"}}),_vm._v(" "),_c('article',{staticClass:"lazyload flex flex-row-reverse leading-snug"},[_c('button',{ref:"button",staticClass:"Icon relative 2xl:left-16 mt-2",attrs:{"id":"icon"},on:{"click":_vm.closeModal}},[_c('span'),_vm._v(" "),_c('span'),_vm._v(" "),_c('span')]),_vm._v(" "),_c('ul',{staticClass:"ml-4"},[_c('li',[_c('p',{staticClass:"fifties"},[_vm._v("1. Original")])]),_vm._v(" "),_c('li',[_c('p',{staticClass:"fifties"},[_vm._v("2. Stylish")])]),_vm._v(" "),_c('li',[_c('p',{staticClass:"fifties"},[_vm._v("3. Modernly")])])])])]):_vm._e()])],1),_vm._v(" "),_c('img',{ref:"vintageMusic",staticClass:"lazyload opacity-0 w-1/2 self-center rounded-3xl sm:w-1/4 md:w-1/2 lg:w-1/4 ",attrs:{"data-src":__webpack_require__(60),"src":_vm.vintageMusic.src,"srcSet":_vm.vintageMusic.srcSet,"width":_vm.vintageMusic.width,"height":_vm.vintageMusic.height,"sizes":"(min-width: 1024px) 1024px, 100vw","alt":"vintage"}})])]),_vm._v(" "),_c('section',{staticClass:"fp-section w-full relative box-content flex-col bg-cover overflow-hidden flex xl:rounded-4xl z-0 sm:flex-row md:flex-col lg:flex-col  xl:flex-row  "},[_c('article',{staticClass:"show w-full flex flex-col sm:self-center md:h-1/3 2xl:self-start"},[_c('div',{staticClass:"w-full h-28 items-center flex mx-auto xl:mt-16 xl:w-3/4 "},[_c('h2',{staticClass:"together w-3/5 font-bold text-3xl mt-4 px-2 text-xl  md:text-4xl  lg:w-full lg:text-5xl xl:w-2/5 2xl:text-4xl "},[_vm._v("\n              LET'S WORK TOGETHER\n            ")]),_vm._v(" "),_c('span',{staticClass:"w-1/2 inline-block relative "})]),_vm._v(" "),_c('div',{staticClass:"w-3/4 mx-auto items-center"},[_c('h1',{staticClass:"hire hidden font-bold text-10xl filter-shadow-green md:block md:text-6xl   md-landscape:hidden  md-portrait:text-5xl lg:block lg:text-10xl xl:hidden xl:text-4xl 2xl:block 2xl:text-9xl "},[_vm._v("\n    HIRE ME")]),_vm._v(" "),_c('figure',{staticClass:"lazyload  w-full relative top-8 m-auto flex items-center filter-shadow-black 2xl:h-auto 2xl:top-0 "},[_c('img',{staticClass:"lazyload md:w-full lg:w-3/4  xl:w-full filter-shadow-black 2xl:h-12 2xl:text-center z-1 ",attrs:{"data-src":__webpack_require__(15),"alt":"ribbon"}}),_vm._v(" "),_c('figcaption',{staticClass:"w-full absolute block text-2xl left-0 my-auto mt-2 bg-no-repeat text-center text-white md:ml-3 md:text-3xl md:tracking-widest  lg:text-3xl  2xl:tracking-widest 2xl:text-3xl   z-0 "},[_vm._v("\n      Let Me Know!\n    ")])]),_vm._v(" "),_c('p',{staticClass:"w-auto h-auto text-xs mt-4 sm:hidden md:text-2xl md:hidden  lg:text-3xl xl:block xl:text-2xl xl:mt-0 2xl:max-w-lg 2xl:block 2xl:text-2xl 2xl:mt-5 "},[_vm._v("\n    Eine hochwertige und ansprechende Website stellt die Grundlage für jede Online-Präsenz. ")])])]),_vm._v(" "),_c('div',{staticClass:"w-full sm:self-center z-0  2xl:self-end "},[_c('form',{ref:"form",staticClass:"lazyload opacity-0 w-full h-full flex flex-col justify-start items-center text-xl sm:justify-center md:justify-start lg:justify-center xl:justify-center xl:text-xl",attrs:{"id":"form"},on:{"submit":function($event){{_vm.getFormValues}}}},[_c('label',{staticClass:"w-full text-center",attrs:{"for":"name"}},[_c('input',{staticClass:"w-4/5 h-8 mt-3 pl-1 border-2  text-xl rounded-xl sm:h-8  md:h-16 md:text-4xl  md-landscape:h-12  md-landscape:text-xl lg:text-3xl  xl:h-12 xl:text-xl",attrs:{"type":"text","id":"name","placeholder":"name"}})]),_vm._v(" "),_c('label',{staticClass:"w-full text-center",attrs:{"for":"email"}},[_c('input',{staticClass:"w-4/5 h-8 mt-3 pl-1 text-xl  border-2 rounded-xl sm:h-8  md:h-16 md:text-4xl md-landscape:h-12  md-landscape:text-xl  lg:mb-5 lg:text-3xl xl:h-12 xl:text-xl",attrs:{"type":"email","id":"email","placeholder":"email"}})]),_vm._v(" "),_c('label',{staticClass:"w-full text-center",attrs:{"for":"message"}},[_c('textarea',{staticClass:"w-4/5 h-auto mt-3 pl-1  text-xl resize-none border-2 rounded-xl  md:text-4xl  md-landscape:text-xl  lg:h-64 lg:mb-5 lg:text-3xl xl:text-xl",attrs:{"id":"message","placeholder":"message"}})]),_vm._v(" "),_c('button',{staticClass:"button_red text-center px-4 py-2 mt-4 relative sm:mt-2 sm:ml-10 sm:self-start md:w-20 md:self-center md:text-2xl 2xl:w-40 2xl:self-stretch 2xl:ml-24",attrs:{"type":"submit","form":"form","value":"submit"}},[_vm._v("SEND")])])]),_vm._v(" "),_c('stickyFooter',{ref:"footer",staticClass:"bottom-0 absolute"})],1)])}
var staticRenderFns = []


// CONCATENATED MODULE: ./pages/index.vue?vue&type=template&id=09e7a3ad&scoped=true&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./pages/index.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
const logo = __webpack_require__(61);

const hat = __webpack_require__(62);

const body = __webpack_require__(63);

const vintageMusic = __webpack_require__(64);

const scumbag = __webpack_require__(65);

const walkman = __webpack_require__(66);

/* harmony default export */ var lib_vue_loader_options_pagesvue_type_script_lang_js_ = ({
  components: {
    light: () => __webpack_require__.e(/* import() */ 0).then(__webpack_require__.bind(null, 80)),
    stickyFooter: () => __webpack_require__.e(/* import() */ 1).then(__webpack_require__.bind(null, 81))
  },
  layout: 'desktop',
  transition: {
    name: 'slots',
    mode: 'out-in'
  },

  data() {
    return {
      logo,
      hat,
      body,
      scumbag,
      vintageMusic,
      walkman,
      bkClass: 'bk',
      blurClass: 'blur',
      loading: false,
      isShowing: false,
      options: {
        ref: true,
        dragAndMove: true,
        afterLoad: this.afterLoad,
        licenseKey: "MiT",
        navigation: true,
        anchors: ['page1', 'page2', 'page3', 'page4'],
        scrollingSpeed: 1500,
        sectionsColor: ['#e4ddd3', '#e4ddd3', '#1c1716', '#fec401'],
        controlArrows: true,
        verticalCentered: false,
        css3: true,
        slidesNavigation: false
      }
    };
  },

  methods: {
    toggleModal() {
      document.querySelector('.bg_stars').scrollIntoView({
        behavior: 'smooth'
      });
      this.isShowing = !this.isShowing;

      if (!this.isShowing) {
        this.$refs.modal.classList.add('out');
      }
    },

    closeModal() {
      this.$refs.button.classList.add('close');
      setTimeout(() => {
        this.$refs.modal.classList.add('out');
      }, 500);
      setTimeout(() => {
        this.isShowing = false;
      }, 500);
    },

    afterLoad: function animation(origin, destination, direction) {
      if (direction === "down" && destination.index === 1) {
        Velocity(this.$refs.scumbag, {
          opacity: 1,
          transform: ["translateX(0)", "translateX(75%)"]
        }, {
          easing: "ease-out",
          duration: 500,
          delay: 2500,
          queue: "test",
          complete: () => {
            Velocity(this.$refs.scumbag, {
              transform: ["rotate(12deg)", "rotate(0)"]
            }, {
              easing: [400, 4],
              duration: 1000,
              queue: "test",
              complete: this.afterLoad
            });
          },
          begin: () => {
            Velocity(this.$refs.welcomeStudio, {
              transform: ["translateX(-12%) rotate(8deg)", "translateX(0) rotate(0)"]
            }, {
              easing: "ease-in",
              queue: false,
              duration: 400,
              delay: 500,
              complete: this.afterLoad
            });
          }
        });
      } else if (direction === "up" && destination.index === 0) {
        Velocity(this.$refs.scumbag, {
          opacity: 0,
          transform: ["translateX(75%)", "translateX(0)"]
        }, {
          duration: 100,
          complete: () => {
            Velocity(this.$refs.scumbag, {
              transform: ["rotate(0)", "rotate(12deg)"]
            }, {
              duration: 100,
              complete: this.afterLoad
            });
          },
          begin: () => {
            Velocity(this.$refs.welcomeStudio, {
              transform: ["translateX(0) rotate(0)", "translateX(-12%) rotate(8deg)"]
            }, {
              complete: this.afterLoad
            });
          }
        });
      } else if (direction === "down" && destination.index === 2) {
        Velocity(this.$refs.vintageMusic, {
          opacity: 1
        }, {
          easing: "swing",
          duration: 550,
          begin: () => {
            this.$refs.vintageMusic.classList.add('animate__animated', 'animate__bounceInLeft', 'animate__delay-1s', 'animate__slow');
            setTimeout(() => {
              this.$refs.vintageMusic.classList.remove('animate__animated', 'animate__bounceInLeft', 'animate__delay-1s', 'animate__slow');
            }, 3000);
            Velocity(this.$refs.vintageMusic, {
              opacity: 1
            }, {
              easing: "swing",
              delay: 3500,
              complete: () => {
                this.$refs.vintageMusic.classList.add('animate__animated', 'animate__bounce', 'animate__repeat-2');
              }
            });
          }
        });
      } else if (direction === "up" && destination.index === 1) {
        Velocity(this.$refs.vintageMusic, {
          opacity: 0
        }, {
          begin: () => {
            this.$refs.vintageMusic.classList.remove('animate__animated', 'animate__bounce', 'animate__repeat-2');
          }
        });
      } else if (direction === "down" && destination.index === 3) {
        Velocity(this.$refs.form, {
          opacity: 1
        }, {
          begin: () => {
            this.$refs.form.classList.add('animate__animated', 'animate__bounceInRight', 'animate__delay-2s', 'animate__slow');
            this.$nuxt.$el.children[0].childNodes[0].children[1].children[3].children[2].classList.add('animate__animated', 'animate__slideInLeft', 'animate__delay-1s');
            this.$nuxt.$el.children[0].childNodes[0].children[1].children[3].children[2].style.opacity = "1";
            this.$nuxt.$el.children[0].children[0].children[1].children[3].children[2].children[2].children[0].classList.add('animate__animated', 'animate__zoomInDown', 'animate__delay-2s');
            this.$nuxt.$el.children[0].children[0].children[1].children[3].children[2].children[2].children[1].classList.add('animate__animated', 'animate__zoomInDown', 'animate__delay-3s');
            this.$nuxt.$el.children[0].children[0].children[1].children[3].children[2].children[2].children[2].classList.add('animate__animated', 'animate__zoomInDown', 'animate__delay-4s');
            this.$nuxt.$el.children[0].children[0].children[1].children[3].children[2].children[2].children[3].classList.add('animate__animated', 'animate__zoomInDown', 'animate__delay-5s');
          }
        });
      } else if (direction === "up" && destination.index === 2) {
        Velocity(this.$refs.form, {
          opacity: 0
        }, {
          begin: () => {
            this.$refs.form.classList.remove('animate__animated', 'animate__bounceInRight', 'animate__delay-2s', 'animate__slow');
            this.$nuxt.$el.children[0].childNodes[0].children[1].children[3].children[2].classList.remove('animate__animated', 'animate__slideInLeft', 'animate__delay-1s');
            this.$nuxt.$el.children[0].childNodes[0].children[1].children[3].children[2].style.opacity = "0";
          }
        });
      }
    },

    getFormValues(submitEvent) {
      this.name = submitEvent.target.elements.name.value;
    }

  },

  mounted() {
    this.$nextTick(() => {
      this.$nuxt.$loading.start();
    });
  }

});
// CONCATENATED MODULE: ./pages/index.vue?vue&type=script&lang=js&
 /* harmony default export */ var pagesvue_type_script_lang_js_ = (lib_vue_loader_options_pagesvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(2);

// CONCATENATED MODULE: ./pages/index.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(67)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  pagesvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "09e7a3ad",
  "1b818184"
  
)

/* harmony default export */ var pages = __webpack_exports__["default"] = (component.exports);

/***/ })

};;
//# sourceMappingURL=index.js.map