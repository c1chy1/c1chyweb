exports.ids = [3];
exports.modules = {

/***/ 100:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/e2b847a.webp";

/***/ }),

/***/ 101:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/9165f14.webp";

/***/ }),

/***/ 102:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/9fec52e.webp";

/***/ }),

/***/ 103:
/***/ (function(module, exports, __webpack_require__) {

module.exports = {
          srcSet: __webpack_require__.p + "img/bb00509-300.webp"+" 300w"+","+__webpack_require__.p + "img/810eed3-400.webp"+" 400w",
          images:[ {path: __webpack_require__.p + "img/bb00509-300.webp",width: 300,height: 160},{path: __webpack_require__.p + "img/810eed3-400.webp",width: 400,height: 213}],
          src: __webpack_require__.p + "img/bb00509-300.webp",
          toString:function(){return __webpack_require__.p + "img/bb00509-300.webp"},
          
          width: 300,
          height: 160
        }

/***/ }),

/***/ 104:
/***/ (function(module, exports, __webpack_require__) {

module.exports = {
          srcSet: __webpack_require__.p + "img/dba2f76-300.webp"+" 300w"+","+__webpack_require__.p + "img/e670645-378.webp"+" 378w",
          images:[ {path: __webpack_require__.p + "img/dba2f76-300.webp",width: 300,height: 416},{path: __webpack_require__.p + "img/e670645-378.webp",width: 378,height: 524}],
          src: __webpack_require__.p + "img/dba2f76-300.webp",
          toString:function(){return __webpack_require__.p + "img/dba2f76-300.webp"},
          
          width: 300,
          height: 416
        }

/***/ }),

/***/ 105:
/***/ (function(module, exports, __webpack_require__) {

module.exports = {
          srcSet: __webpack_require__.p + "img/4191a0b-300.webp"+" 300w"+","+__webpack_require__.p + "img/f1c895d-600.webp"+" 600w"+","+__webpack_require__.p + "img/7a684ab-650.webp"+" 650w",
          images:[ {path: __webpack_require__.p + "img/4191a0b-300.webp",width: 300,height: 131},{path: __webpack_require__.p + "img/f1c895d-600.webp",width: 600,height: 261},{path: __webpack_require__.p + "img/7a684ab-650.webp",width: 650,height: 283}],
          src: __webpack_require__.p + "img/4191a0b-300.webp",
          toString:function(){return __webpack_require__.p + "img/4191a0b-300.webp"},
          
          width: 300,
          height: 131
        }

/***/ }),

/***/ 106:
/***/ (function(module, exports, __webpack_require__) {

module.exports = {
          srcSet: __webpack_require__.p + "img/491ce65-300.webp"+" 300w"+","+__webpack_require__.p + "img/0a15d2c-395.webp"+" 395w",
          images:[ {path: __webpack_require__.p + "img/491ce65-300.webp",width: 300,height: 428},{path: __webpack_require__.p + "img/0a15d2c-395.webp",width: 395,height: 564}],
          src: __webpack_require__.p + "img/491ce65-300.webp",
          toString:function(){return __webpack_require__.p + "img/491ce65-300.webp"},
          
          width: 300,
          height: 428
        }

/***/ }),

/***/ 107:
/***/ (function(module, exports, __webpack_require__) {

module.exports = {
          srcSet: __webpack_require__.p + "img/60c6fa7-300.webp"+" 300w"+","+__webpack_require__.p + "img/c6f4c95-338.webp"+" 338w",
          images:[ {path: __webpack_require__.p + "img/60c6fa7-300.webp",width: 300,height: 464},{path: __webpack_require__.p + "img/c6f4c95-338.webp",width: 338,height: 523}],
          src: __webpack_require__.p + "img/60c6fa7-300.webp",
          toString:function(){return __webpack_require__.p + "img/60c6fa7-300.webp"},
          
          width: 300,
          height: 464
        }

/***/ }),

/***/ 108:
/***/ (function(module, exports, __webpack_require__) {

module.exports = {
          srcSet: __webpack_require__.p + "img/c3df91e-300.webp"+" 300w"+","+__webpack_require__.p + "img/531ab9c-564.webp"+" 564w",
          images:[ {path: __webpack_require__.p + "img/c3df91e-300.webp",width: 300,height: 400},{path: __webpack_require__.p + "img/531ab9c-564.webp",width: 564,height: 752}],
          src: __webpack_require__.p + "img/c3df91e-300.webp",
          toString:function(){return __webpack_require__.p + "img/c3df91e-300.webp"},
          
          width: 300,
          height: 400
        }

/***/ }),

/***/ 109:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_vue_loader_lib_index_js_vue_loader_options_index_vue_vue_type_style_index_0_id_890467b0_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_vue_loader_lib_index_js_vue_loader_options_index_vue_vue_type_style_index_0_id_890467b0_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_vue_loader_lib_index_js_vue_loader_options_index_vue_vue_type_style_index_0_id_890467b0_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_vue_loader_lib_index_js_vue_loader_options_index_vue_vue_type_style_index_0_id_890467b0_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_vue_loader_lib_index_js_vue_loader_options_index_vue_vue_type_style_index_0_id_890467b0_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 110:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(3);
var ___CSS_LOADER_GET_URL_IMPORT___ = __webpack_require__(9);
var ___CSS_LOADER_URL_IMPORT_0___ = __webpack_require__(111);
var ___CSS_LOADER_URL_IMPORT_1___ = __webpack_require__(112);
var ___CSS_LOADER_URL_IMPORT_2___ = __webpack_require__(49);
var ___CSS_LOADER_URL_IMPORT_3___ = __webpack_require__(21);
var ___CSS_LOADER_URL_IMPORT_4___ = __webpack_require__(50);
var ___CSS_LOADER_URL_IMPORT_5___ = __webpack_require__(53);
var ___CSS_LOADER_URL_IMPORT_6___ = __webpack_require__(54);
var ___CSS_LOADER_URL_IMPORT_7___ = __webpack_require__(113);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
var ___CSS_LOADER_URL_REPLACEMENT_0___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_0___);
var ___CSS_LOADER_URL_REPLACEMENT_1___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_1___);
var ___CSS_LOADER_URL_REPLACEMENT_2___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_2___);
var ___CSS_LOADER_URL_REPLACEMENT_3___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_3___);
var ___CSS_LOADER_URL_REPLACEMENT_4___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_4___);
var ___CSS_LOADER_URL_REPLACEMENT_5___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_5___);
var ___CSS_LOADER_URL_REPLACEMENT_6___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_6___);
var ___CSS_LOADER_URL_REPLACEMENT_7___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_7___);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".bk[data-v-890467b0]{transition:all .3s ease-out}.blur[data-v-890467b0]{filter:blur(1px);opacity:.4}#fullpage[data-v-890467b0]{background-color:#faebd7}.animate__delay-8s[data-v-890467b0]{-webkit-animation-delay:8s!important;animation-delay:8s!important}a[data-v-890467b0],div p[data-v-890467b0],li[data-v-890467b0]{font-family:Merriweather,sans-serif}.animate[data-v-890467b0],.logo[data-v-890467b0]{--animate-duration:1.5s}.button_red[data-v-890467b0]{background-color:transparent;color:#e53e26;border-color:#e53e26;border-style:solid;border-width:4px 0;font-weight:700;line-height:1;font-family:Barlow Condensed,sans-serif;transition:all .2s ease}.button_red[data-v-890467b0]:after,.button_red[data-v-890467b0]:before{background-color:#e53e26;content:\"\";position:absolute;top:50%;width:7px;height:7px;border-radius:50%;transform:translateY(-50%);transition:background-color .2s ease,transform .2s ease}.button_red[data-v-890467b0]:before{left:0}.button_red[data-v-890467b0]:after{right:0}.button_red[data-v-890467b0]:hover{color:#e6c8a0}.fade[data-v-890467b0]{opacity:0}.show[data-v-890467b0]{opacity:1}.fp-section.fp-table[data-v-890467b0],.fp-slide.fp-table[data-v-890467b0]{border-radius:25px!important}[data-anchor=page1][data-v-890467b0]{background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_0___ + ");visibility:inherit}[data-anchor=page1] .circle_bg[data-v-890467b0]{background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_1___ + ");border:5px solid #000;border-radius:50%;opacity:0}[data-anchor=page1] .intro span[data-v-890467b0]{color:#e6c8a0}[data-anchor=page1] figure figcaption[data-v-890467b0]{font-family:Satisfy,sans-serif}[data-anchor=page1] figure img[data-v-890467b0]{z-index:-1}[data-anchor=page1] .intro[data-v-890467b0]{color:#e6c8a0;font-family:\"Satisfy\",cursive;text-shadow:1px 1px #000;transform:rotate(-10deg)}[data-anchor=page1] .intro--the[data-v-890467b0]{transform:rotate(-10deg) translate(-20px,15px)}[data-anchor=page1] .intro--num[data-v-890467b0]{background:#f0c8a0;border:1px dotted #143c50;color:#143c50!important;font-family:sans-serif;padding:4px 6px 2px;text-shadow:none;transform:rotate(-12deg) translate(18px,-37px)}[data-anchor=page1] .vintage[data-v-890467b0]{font-family:\"Six Caps\",sans-serif}[data-anchor=page1] .vintage__top[data-v-890467b0]{background:linear-gradient(#f0dcc8,#e6c8a0);-webkit-background-clip:text;background-clip:text;z-index:1;-webkit-text-fill-color:transparent;text-fill-color:transparent}[data-anchor=page1] .vintage__bot[data-v-890467b0]{text-shadow:2px 1px #550a00,4px 2px #5a0f05,6px 4px #64140f,8px 5px #691914,10px 6px #6e1e19,12px 7px #731e1e,14px 8px #781e23,16px 9px #000,18px 10px #000,20px 11px #000,22px 12px #000,24px 13px #000,28px 14px rgba(0,0,0,.9),30px 15px rgba(0,0,0,.7),32px 16px rgba(0,0,0,.5),34px 17px rgba(0,0,0,.3),36px 18px rgba(0,0,0,.1),40px 20px rgba(0,0,0,.1)}[data-anchor=page1] .outro[data-v-890467b0]{font-family:\"Satisfy\",cursive}[data-anchor=page2][data-v-890467b0]{vertical-align:top!important;background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_2___ + ");background-position:0 0;visibility:inherit}[data-anchor=page2] figure figcaption[data-v-890467b0]{font-family:Satisfy,sans-serif}[data-anchor=page2] .scumbag div h2[data-v-890467b0]{background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_3___ + ");background-color:#4f7b70;color:#f7ebd5;padding:5px}[data-anchor=page2] .scumbag div p[data-v-890467b0]{border:2px solid #000;border-radius:15px}[data-anchor=page2] .scumbag .button_red[data-v-890467b0]:hover{color:#224a49}[data-anchor=page2] ul li[data-v-890467b0]{padding:5px 0;background-image:linear-gradient(90deg,#d5cdc1 33%,hsla(0,0%,100%,0) 0);background-position:top;background-size:8px 2px;background-repeat:repeat-x}[data-anchor=page2] ul li h3[data-v-890467b0]:before{content:\"🗲\";color:#a1362b;margin-right:20px;display:inline-block;transform:rotate(45deg)}[data-anchor=page2] .welcome_studio[data-v-890467b0]{color:#224a49}[data-anchor=page2] .welcome_studio .background[data-v-890467b0]{background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_3___ + ");z-index:-1;background-color:wheat;border-radius:40px}[data-anchor=page2] .welcome_studio div span[data-v-890467b0]:before{background-color:#224a49;content:\"\";position:absolute;left:0;width:100%;height:3px;top:0}[data-anchor=page2] .welcome_studio div span[data-v-890467b0]:after{color:#224a49;top:14px;height:8px;position:absolute;left:0;width:100%;content:\"\";display:block;background:url(" + ___CSS_LOADER_URL_REPLACEMENT_4___ + ") repeat-x 0 0}[data-anchor=page2] .welcome_studio div h2[data-v-890467b0],[data-anchor=page2] article h1[data-v-890467b0]{color:#224a49;filter:drop-shadow(5px 6px 0 #a9c9bb);font-family:Barlow Condensed,sans-serif}[data-anchor=page2] article h1[data-v-890467b0]{font-size:9vw}[data-anchor=page3][data-v-890467b0]{background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_5___ + ")}[data-anchor=page3][data-v-890467b0]:before{float:left;height:16px;background:url(" + ___CSS_LOADER_URL_REPLACEMENT_6___ + ") bottom repeat-x;border-image-repeat:round;border-style:solid}[data-anchor=page3][data-v-890467b0]:after,[data-anchor=page3][data-v-890467b0]:before{position:absolute;content:\"\";display:block;border-image-width:3px;border-image-source:url(" + ___CSS_LOADER_URL_REPLACEMENT_6___ + ")}[data-anchor=page3][data-v-890467b0]:after{height:15px;background:url(" + ___CSS_LOADER_URL_REPLACEMENT_6___ + ") top repeat-x;border-image-repeat:repeat;border-style:solid}[data-anchor=page3] .bg_stars h2[data-v-890467b0]{background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_3___ + ");background-color:#a1362b;color:#eae5de;white-space:revert;top:5px;left:6px}[data-anchor=page3] .bg_stars[data-v-890467b0]:before{background:url(" + ___CSS_LOADER_URL_REPLACEMENT_6___ + ") 0 repeat-y}[data-anchor=page3] .bg_stars[data-v-890467b0]:after,[data-anchor=page3] .bg_stars[data-v-890467b0]:before{position:absolute;content:\"\";display:block;border-image-width:3px;border-image-source:url(" + ___CSS_LOADER_URL_REPLACEMENT_6___ + ");border-image-repeat:repeat;border-style:solid}[data-anchor=page3] .bg_stars[data-v-890467b0]:after{background:url(" + ___CSS_LOADER_URL_REPLACEMENT_6___ + ") 100% repeat-y}[data-anchor=page3] p[data-v-890467b0]{font-family:monospace;color:rgba(233,228,221,.7)}[data-anchor=page3] div.modal[data-v-890467b0]{height:75px;width:75px;border-radius:75px;overflow:hidden;position:absolute;background-color:#ffa735;background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_2___ + ");-webkit-animation:bondJamesBond-data-v-890467b0 1.5s cubic-bezier(.165,.84,.44,1) forwards;animation:bondJamesBond-data-v-890467b0 1.5s cubic-bezier(.165,.84,.44,1) forwards}[data-anchor=page3] div.modal button[data-v-890467b0],[data-anchor=page3] div.modal h2[data-v-890467b0],[data-anchor=page3] div.modal img[data-v-890467b0],[data-anchor=page3] div.modal li[data-v-890467b0],[data-anchor=page3] div.modal p[data-v-890467b0]{opacity:0;position:relative;-webkit-animation:modalContentFadeIn-data-v-890467b0 .5s linear 1.4s forwards;animation:modalContentFadeIn-data-v-890467b0 .5s linear 1.4s forwards}[data-anchor=page3] div.modal .fifties[data-v-890467b0]{font-family:Lobster Two,italic;color:#fff;text-shadow:0 8px 0 #1c1c1c;font-size:4vw}[data-anchor=page3] div.modal.out[data-v-890467b0]{-webkit-animation:slowFade-data-v-890467b0 1.5s;animation:slowFade-data-v-890467b0 1.5s}[data-anchor=page3] div.modal.out>h2[data-v-890467b0],[data-anchor=page3] div.modal.out button[data-v-890467b0],[data-anchor=page3] div.modal.out img[data-v-890467b0],[data-anchor=page3] div.modal.out li[data-v-890467b0],[data-anchor=page3] div.modal.out p[data-v-890467b0]{-webkit-animation:modalContentFadeOut-data-v-890467b0 1.4s;animation:modalContentFadeOut-data-v-890467b0 1.4s}@-webkit-keyframes slowFade-data-v-890467b0{0%{border-radius:3px;height:352px;width:100%}80%{border-radius:25px;width:80%}90%{transform:translateX(0);border-radius:75px;height:75px;width:75px}to{width:0;transform:translateX(1000px)}}@keyframes slowFade-data-v-890467b0{0%{border-radius:3px;height:352px;width:100%}80%{border-radius:25px;width:80%}90%{transform:translateX(0);border-radius:75px;height:75px;width:75px}to{width:0;transform:translateX(1000px)}}@-webkit-keyframes modalContentFadeIn-data-v-890467b0{0%{opacity:0;top:-20px}to{opacity:1;top:0}}@keyframes modalContentFadeIn-data-v-890467b0{0%{opacity:0;top:-20px}to{opacity:1;top:0}}@-webkit-keyframes modalContentFadeOut-data-v-890467b0{0%{opacity:1;top:0}to{opacity:0;top:-20px}}@keyframes modalContentFadeOut-data-v-890467b0{0%{opacity:1;top:0}to{opacity:0;top:-20px}}@-webkit-keyframes bondJamesBond-data-v-890467b0{0%{transform:translateX(1000px)}80%{transform:translateX(0);border-radius:75px;height:75px;width:75px}90%{border-radius:3px;height:372px;width:80%}to{border-radius:3px;height:352px;width:125%}}@keyframes bondJamesBond-data-v-890467b0{0%{transform:translateX(1000px)}80%{transform:translateX(0);border-radius:75px;height:75px;width:75px}90%{border-radius:3px;height:372px;width:80%}to{border-radius:3px;height:352px;width:125%}}[data-anchor=page3] .Icon[data-v-890467b0]{width:50px;height:50px;position:relative;transform:rotate(-90deg);transition:.5s ease-in-out;cursor:pointer}[data-anchor=page3] .Icon span[data-v-890467b0]{display:block;position:absolute;left:0;top:23px;height:8px;width:100%;background:#fff;border-radius:4px;transform:rotate(0deg);transition:.2s ease-in-out}[data-anchor=page3] .Icon span[data-v-890467b0]:first-child,[data-anchor=page3] .Icon span[data-v-890467b0]:nth-child(3){width:50%;transform:rotate(45deg)}[data-anchor=page3] .Icon span[data-v-890467b0]:first-child{left:3px;top:15px}[data-anchor=page3] .Icon span[data-v-890467b0]:nth-child(2){transform:rotate(-45deg)}[data-anchor=page3] .Icon span[data-v-890467b0]:nth-child(3){left:22px;top:33px}[data-anchor=page3] .close span[data-v-890467b0]:first-child,[data-anchor=page3] .close span[data-v-890467b0]:nth-child(3){left:-1px}[data-anchor=page3] .close span[data-v-890467b0]:first-child{top:15px;transform:rotate(135deg)}[data-anchor=page3] .close span[data-v-890467b0]:nth-child(2){transform:rotate(0deg)}[data-anchor=page3] .close span[data-v-890467b0]:nth-child(3){top:31px;transform:rotate(45deg)}[data-anchor=page4][data-v-890467b0]{background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_7___ + ");background-position-x:80%}[data-anchor=page4] input[data-v-890467b0],[data-anchor=page4] textarea[data-v-890467b0]{background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_2___ + ");background-color:#faebd7}[data-anchor=page4] figure[data-v-890467b0]{-webkit-animation:none;animation:none;right:33%}[data-anchor=page4] figure figcaption[data-v-890467b0]{font-family:Satisfy,sans-serif}[data-anchor=page4] article span[data-v-890467b0]:before{background-color:#224a49;content:\"\";position:absolute;left:0;width:100%;height:3px;top:0}[data-anchor=page4] article span[data-v-890467b0]:after{color:#224a49;top:14px;height:8px;position:absolute;left:0;width:100%;content:\"\";display:block;background:url(" + ___CSS_LOADER_URL_REPLACEMENT_4___ + ") repeat-x 0 0}[data-anchor=page4] article h1[data-v-890467b0]{color:#e9e4dc}[data-anchor=page4] article h2[data-v-890467b0]{color:#224a49;font-family:Barlow Condensed,sans-serif;filter:drop-shadow(5px 6px 0 #a9c9bb)}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 111:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/d604ae9.webp";

/***/ }),

/***/ 112:
/***/ (function(module, exports, __webpack_require__) {

module.exports = {
          srcSet: __webpack_require__.p + "img/51de4a7-150.png"+" 150w",
          images:[ {path: __webpack_require__.p + "img/51de4a7-150.png",width: 150,height: 113}],
          src: __webpack_require__.p + "img/51de4a7-150.png",
          toString:function(){return __webpack_require__.p + "img/51de4a7-150.png"},
          
          width: 150,
          height: 113
        }

/***/ }),

/***/ 113:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/011da08.webp";

/***/ }),

/***/ 117:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./pages/index.vue?vue&type=template&id=890467b0&scoped=true&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('full-page',{staticClass:"w-screen h-screen  absolute z-10 cursor-default container px-0 md:px-0  max-w-full lg:max-w-max  mx-auto",attrs:{"id":"fullpage","options":_vm.options}},[_c('section',{staticClass:"fp-section w-full overflow-hidden bg-no-repeat bg-cover bg-center opacity-100  xl:rounded-4xl  filter-shadow-black z-10 "},[_c('light'),_vm._v(" "),_c('div',{staticClass:"w-full h-screen relative fill-40 flex flex-col   justify-between    sm:justify-end ",staticStyle:{"background-image":"radial-gradient(transparent, rgba(0, 0, 0, 0.5))"}},[_c('div',{staticClass:"lazyload circle_bg circle1 absolute w-2 px-4 py-2 ml-12 bg-white hidden   2xl:block 2xl:w-20 2xl:p-5 z-50"}),_vm._v(" "),_c('div',{staticClass:"lazyload circle_bg  circle2 absolute w-4 px-3 py-2 ml-6 bg-white hidden  2xl:block 2xl:w-16 2xl:p-4  z-40"}),_vm._v(" "),_c('div',{staticClass:"lazyload circle_bg circle3  absolute w-8 px-2 py-1   bg-white hidden   2xl:block 2xl:p-2 z-30"}),_vm._v(" "),_c('img',{staticClass:"logo lazyload  self-center relative w-10/12 sm:w-1/3 md:w-40 portrait:w-1/2 lg:w-1/3 xl:w-1/4\n\n\n        xl:top-12 relative z-50",class:'animate__animated animate__tada animate__delay-8s animate__repeat-2',attrs:{"data-src":__webpack_require__(97),"srcSet":_vm.logo.srcSet,"src":_vm.logo.src,"alt":"c1chy"}}),_vm._v(" "),_c('img',{staticClass:"hat lazyload relative self-center w-3/5 sm:w-32  md:1/2 portrait:w-1/2 lg:w-1/4  xl:top-12 xl:w-1/5 z-20",attrs:{"data-src":__webpack_require__(98),"srcSet":_vm.hat.srcSet,"src":_vm.hat.src,"alt":"rainbow balloon"}}),_vm._v(" "),_c('img',{staticClass:"body lazyload self-center w-full h-1/3 sm:w-2/5 sm:h-auto md:w-2/3 lg:w-5/12\n\n\n\n                xl:w-1/2 2xl:w-1/3 filter-shadow-black ",attrs:{"data-src":__webpack_require__(99),"srcSet":_vm.body.srcSet,"src":_vm.body.src,"alt":"vintage body"}}),_vm._v(" "),_c('figure',{staticClass:"ribbon flex bottom-20 absolute w-8/12 sm:justify-center  xl:w-2/5 2xl:w-1/3  self-center   filter-shadow-black z-10 "},[_c('img',{staticClass:"lazyload absolute  sm:w-1/2 md:w-2/3 lg:w-full 2xl:w-full filter-shadow-black z-10",attrs:{"data-src":__webpack_require__(20),"alt":"ribbon"}}),_vm._v(" "),_c('figcaption',{staticClass:"mx-auto mt-2   text-xs text-white text-center my-auto  md:text-xl lg:text-xl  xl:mt-4 xl:tracking-wider    2xl:mt-5 z-20"},[_vm._v("\n              Visually Striking Design ")])])]),_vm._v(" "),_c('div',{staticClass:"hidden sm:block bottom-0 right-2 absolute lg:pr-2 2xl:block 2xl:right-0 2xl:absolute 2xl:bottom-0 2xl:mb-3 2xl:mr-3 text-center tracking-widest md:text-left z-10"},[_c('div',{staticClass:"classic sm:mb-3 md:absolute  lg:text-center 2xl:block 2xl:relative 2xl:right-1/3 "},[_c('span',{staticClass:"intro intro--the block text-3xl"},[_vm._v("The")]),_vm._v(" "),_c('span',{staticClass:"intro intro--num block text inline-block absolute font-semibold sm:hidden lg:inline"},[_vm._v("first #1")]),_vm._v(" "),_c('span',{staticClass:"intro block  sm:text-xl 2xl:text-4xl"},[_vm._v("classic style")])]),_vm._v(" "),_c('div',{staticClass:"vintage__container block md:absolute lg:relative 2xl:relative "},[_c('p',{staticClass:"vintage vintage__top  m-0 text-6xl leading-none sm:hidden md:absolute md:text-5xl lg:absolute 2xl:absolute 2xl:block 2xl:text-center 2xl:w-full"},[_vm._v("VINTAGE")]),_vm._v(" "),_c('p',{staticClass:"vintage vintage__bot  m-0 text-6xl leading-none sm:hidden md:absolute md:text-5xl lg:absolute 2xl:relative 2xl:block 2xl:text-center"},[_vm._v("VINTAGE")])]),_vm._v(" "),_c('div',{staticClass:"sm:hidden md:hidden 2xl:block 2xl:right-0 2xl:mt-2 2xl:tracking-wide"},[_c('span',{staticClass:"outro pt-4 text-white text-xl "},[_vm._v("NO.01")]),_vm._v(" "),_c('span',{staticClass:"outro  text-white text-3xl font-sans"},[_vm._v("OLDSCHOOL RECREATED")]),_vm._v(" "),_c('span',{staticClass:"outro text-white text-xl"},[_vm._v("BEST")]),_vm._v(" "),_c('span',{staticClass:"outro block text-white text-xl 2xl:text-center"},[_vm._v("c1chy.web")])])])],1),_vm._v(" "),_c('section',{staticClass:"fp-section w-full  relative bg-repeat bg-scroll opacity-100 overflow-hidden z-10 xl:rounded-4xl  "},[_c('div',{staticClass:"welcome_studio w-full pt-4 flex flex-col justify-content-between items-center text-center box-border leading-tight"},[_c('div',{staticClass:"w-full h-28  items-center flex  mx-auto 2xl:mt-16"},[_c('span',{staticClass:"w-11/12 inline-block relative"}),_vm._v(" "),_c('h1',{staticClass:"w-full font-bold text-2xl mt-2 sm:w-full sm:text-2xl md:w-full md:mt-0 md:text-5xl  xl:text-2xl  2xl:text-4xl   "},[_vm._v("WELCOME TO STUDIO")]),_vm._v(" "),_c('span',{staticClass:"w-11/12 inline-block relative"})]),_vm._v(" "),_c('article',{staticClass:"bg-center bg-no-repeat leading-none "},[_c('h1',{staticClass:"hidden inline text-5xl font-bold uppercase 2xl:block 2xl:text-11xl 2xl:mt-4 "},[_vm._v("c1chy's studio")]),_vm._v(" "),_c('figure',{staticClass:"h-full w-8/12 relative m-auto flex items-center filter-shadow-black z-10 hidden sm:flex sm:w-1/2 sm:mt-4 md:w-1/2 lg:w-full xl:w-2/3 2xl:w-2/3 2xl:mt-0 2xl:mb-1 z-20"},[_c('img',{staticClass:"lazyload xl:text-center filter-shadow-black ",attrs:{"srcSet":__webpack_require__(20),"alt":"ribbon"}}),_vm._v(" "),_c('figcaption',{staticClass:"w-full my-auto mt-3 block absolute text-xl text-center text-white sm:text-xl sm:tracking-wide md:sm:tracking-widest xl:tracking-mega xl:mt-4 2xl:tracking-wider 2xl:text-4xl 2xl:mt-6 2xl:ml-2 "},[_vm._v("\n                ✪ ✪ ✪ ✪ ✪ ✪ ✪\n              ")])])])]),_vm._v(" "),_c('div',{staticClass:"scumbag w-full flex  flex-col  xl:flex-row  justify-center bg-repeat bg-auto bg-center z-2 xl:rounded-4xl"},[_c('div',{ref:"welcomeStudio",staticClass:"text-center mt-3 pt-1 xl:w-1/2 lg:w-2/3 2xl:w-1/2"},[_c('div',[_c('h2',{staticClass:"text-xl md:text-4xl lg:text-5xl  2xl:text-2xl 2xl:text-4xl 2xl:font-bold 2xl:text-center"},[_vm._v("\n                Klare Strategie , ausdrucksstarkes "),_c('br'),_vm._v(" Design & moderne Technologie. ")])]),_vm._v(" "),_c('div',{staticClass:"w-full  px-1 pt-5 leading-loose md:w-full xl:text-xl xl:mt-2  2xl:pt-3 2xl:mt-4 2xl:flex "},[_c('ul',{staticClass:" mb-16 text-xs text-center  md:text-2xl lg:text-2xl xl:text-xl xl:border-purple-700 2xl:mb-0 2xl:p-1 2xl:text-xl "},[_c('li',[_c('h3',[_vm._v("APP-Entwicklung")])]),_vm._v(" "),_c('li',[_c('h3',[_vm._v("Responsive Webdesign")])]),_vm._v(" "),_c('li',[_c('h3',[_vm._v("SEO + Sichtbarkeit")])])]),_vm._v(" "),_c('p',{staticClass:"hidden sm:hidden md:hidden md:block  md:text-2xl lg:hidden xl:text-xl  xl:hidden 2xl:w-1/2 2xl:p-1 2xl:m-auto 2xl:block 2xl:text-xl"},[_vm._v("\n                Webseiten der neuen Generation, die mit dem Ziel erstellt werden, Arbeit durch Innovation zu transformieren. ")])])]),_vm._v(" "),_c('img',{ref:"scumbag",staticClass:"wolf lazyload  w-1/2 rounded-4xl sm:hidden md:block xl:w-2/5 2xl:w-1/4 opacity-0  z-10 ",attrs:{"data-src":__webpack_require__(100),"src":_vm.scumbag.src,"srcSet":_vm.scumbag.srcSet,"alt":"vintage wolf"}}),_vm._v(" "),_c('div',{staticClass:"background h-2/5 absolute right-0 top-3/4 opacity-70 "})])]),_vm._v(" "),_c('section',{staticClass:"fp-section  w-full relative overflow-hidden box-content xl:rounded-4xl z-0 "},[_c('div',{staticClass:"bg_stars h-full w-full flex flex-col justify-evenly sm:flex-row  md:flex-col xl:flex-row-reverse text-white z-0 "},[_c('div',{staticClass:"w-5/12 self-center lg:w-1/3  lg:h-full lg:flex lg:flex-col lg:justify-evenly"},[_c('h2',{staticClass:"text-center  text-xl xl:text-3xl 2xl:text-5xl "},[_vm._v("\n              Strategie, Technologie, "),_c('br'),_vm._v(" App & Content ")]),_vm._v(" "),_c('p',{staticClass:"hidden text-xs xl:block xl:text-xl 2xl:text-xl ",class:[_vm.isShowing ? _vm.blurClass : '', _vm.bkClass]},[_vm._v("\n              An der Schnittstelle von Technik entwickle ich digitale Anwendungen,\n              die mit durchdachter Benutzerführung und ausgefeilter Funktionalität überzeugen – egal,\n              auf welchem Gerät. Dazu erprobe ich neuartige Methoden, beschäftige ich intensiv mit aufregenden Technologien,\n              experimentiere mit neuen Herangehensweisen.")]),_vm._v(" "),_c('button',{staticClass:"button_red text-center px-4 py-2 relative hidden lg:hidden xl:hidden 2xl:block 2xl:w-1/2 2xl:text-3xl",on:{"click":_vm.toggleModal}},[(_vm.isShowing)?_c('span',[_vm._v("HIDE HOW !")]):_c('span',[_vm._v("SHOW ME HOW !")])]),_vm._v(" "),_c('transition',{attrs:{"name":"fade"}},[(_vm.isShowing)?_c('div',{ref:"modal",staticClass:"lazyload modal flex w-full"},[_c('img',{staticClass:"lazyload",attrs:{"data-src":__webpack_require__(101),"src":_vm.walkman.src,"srcSet":_vm.walkman.srcSet}}),_vm._v(" "),_c('article',{staticClass:"lazyload flex flex-row-reverse leading-snug"},[_c('button',{ref:"button",staticClass:"Icon relative 2xl:left-16 mt-2",attrs:{"id":"icon"},on:{"click":_vm.closeModal}},[_c('span'),_vm._v(" "),_c('span'),_vm._v(" "),_c('span')]),_vm._v(" "),_c('ul',{staticClass:"ml-4"},[_c('li',[_c('p',{staticClass:"fifties"},[_vm._v("1. Original")])]),_vm._v(" "),_c('li',[_c('p',{staticClass:"fifties"},[_vm._v("2. Stylish")])]),_vm._v(" "),_c('li',[_c('p',{staticClass:"fifties"},[_vm._v("3. Modernly")])])])])]):_vm._e()])],1),_vm._v(" "),_c('img',{ref:"vintageMusic",staticClass:"lazyload opacity-0 w-1/2 self-center rounded-3xl sm:w-1/4 md:w-1/2 lg:w-1/4 ",attrs:{"data-src":__webpack_require__(102),"src":_vm.vintageMusic.src,"srcSet":_vm.vintageMusic.srcSet,"alt":"vintage"}})])]),_vm._v(" "),_c('section',{staticClass:"fp-section w-full relative box-content flex-col bg-cover overflow-hidden flex xl:rounded-4xl z-0 sm:flex-row md:flex-col lg:flex-col  xl:flex-row  "},[_c('article',{staticClass:"show w-full flex flex-col sm:self-center md:h-1/3 2xl:self-start"},[_c('div',{staticClass:"w-full h-28 items-center flex mx-auto xl:mt-16 xl:w-3/4 2xl:w-full"},[_c('h2',{staticClass:"together w-3/5 font-bold text-3xl mt-4 px-2 text-xl  md:text-4xl  lg:w-full lg:text-5xl xl:w-2/5 2xl:text-4xl "},[_vm._v("\n              LET'S WORK TOGETHER\n            ")]),_vm._v(" "),_c('span',{staticClass:"w-1/2 inline-block relative "})]),_vm._v(" "),_c('div',{staticClass:"w-3/4 mx-auto items-center"},[_c('h1',{staticClass:"hire hidden font-bold text-10xl filter-shadow-green md:block md:text-6xl   md-landscape:hidden  md-portrait:text-5xl lg:block lg:text-10xl xl:hidden xl:text-4xl 2xl:block 2xl:text-9xl "},[_vm._v("\n    HIRE ME")]),_vm._v(" "),_c('figure',{staticClass:"lazyload  w-full relative top-8 m-auto flex items-center filter-shadow-black 2xl:h-auto 2xl:top-0 "},[_c('img',{staticClass:"lazyload md:w-full lg:w-3/4  xl:w-full filter-shadow-black 2xl:h-12 2xl:text-center z-1 ",attrs:{"data-src":__webpack_require__(20),"alt":"ribbon"}}),_vm._v(" "),_c('figcaption',{staticClass:"w-full absolute block text-2xl left-0 my-auto mt-2 bg-no-repeat text-center text-white md:ml-3 md:text-3xl md:tracking-widest  lg:text-3xl  2xl:tracking-widest 2xl:text-3xl   z-0 "},[_vm._v("\n      Let Me Know!\n    ")])]),_vm._v(" "),_c('p',{staticClass:"w-auto h-auto text-xs mt-4 sm:hidden md:text-2xl md:hidden  lg:text-3xl xl:block xl:text-2xl xl:mt-0 2xl:max-w-lg 2xl:block 2xl:text-2xl 2xl:mt-5 "},[_vm._v("\n    Eine hochwertige und ansprechende Website stellt die Grundlage für jede Online-Präsenz. ")])])]),_vm._v(" "),_c('div',{staticClass:"w-full sm:self-center z-0  2xl:self-end "},[_c('form',{ref:"form",staticClass:"lazyload opacity-0 w-full h-full flex flex-col justify-start items-center text-xl sm:justify-center md:justify-start lg:justify-center xl:justify-center xl:text-2xl",attrs:{"id":"form"},on:{"submit":function($event){{_vm.getFormValues}}}},[_c('label',{staticClass:"w-full text-center",attrs:{"for":"name"}},[_c('input',{staticClass:"w-4/5 h-8 mt-3 pl-1 border-2  text-xl rounded-xl sm:h-8  md:h-16 md:text-4xl  md-landscape:h-12  md-landscape:text-xl lg:text-3xl  xl:h-12 xl:text-2xl",attrs:{"type":"text","id":"name","placeholder":"name"}})]),_vm._v(" "),_c('label',{staticClass:"w-full text-center",attrs:{"for":"email"}},[_c('input',{staticClass:"w-4/5 h-8 mt-3 pl-1 text-xl  border-2 rounded-xl sm:h-8  md:h-16 md:text-4xl md-landscape:h-12  md-landscape:text-xl  lg:mb-5 lg:text-3xl xl:h-12 xl:text-2xl",attrs:{"type":"email","id":"email","placeholder":"email"}})]),_vm._v(" "),_c('label',{staticClass:"w-full text-center",attrs:{"for":"message"}},[_c('textarea',{staticClass:"w-4/5 h-auto mt-3 pl-1  text-xl resize-none border-2 rounded-xl  md:text-4xl  md-landscape:text-xl  lg:h-64 lg:mb-5 lg:text-3xl xl:text-2xl ",attrs:{"id":"message","placeholder":"message"}})]),_vm._v(" "),_c('button',{staticClass:"button_red text-center px-4 py-2 mt-4 relative sm:mt-2 sm:ml-10 sm:self-start md:w-20 md:self-center md:text-2xl 2xl:w-40 2xl:self-stretch 2xl:ml-24",attrs:{"type":"submit","form":"form","value":"submit"}},[_vm._v("SEND")])])]),_vm._v(" "),_c('stickyFooter',{ref:"footer",staticClass:"bottom-0 absolute"})],1)])}
var staticRenderFns = []


// CONCATENATED MODULE: ./pages/index.vue?vue&type=template&id=890467b0&scoped=true&

// EXTERNAL MODULE: ./components/stickyFooter.vue + 4 modules
var stickyFooter = __webpack_require__(51);

// EXTERNAL MODULE: ./components/light.vue + 4 modules
var light = __webpack_require__(10);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./pages/index.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



const logo = __webpack_require__(103);

const hat = __webpack_require__(104);

const body = __webpack_require__(105);

const vintageMusic = __webpack_require__(106);

const scumbag = __webpack_require__(107);

const walkman = __webpack_require__(108);

/* harmony default export */ var lib_vue_loader_options_pagesvue_type_script_lang_js_ = ({
  components: {
    light: light["a" /* default */],
    stickyFooter: stickyFooter["a" /* default */]
  },
  layout: 'desktop',
  transition: {
    name: 'slots',
    mode: 'out-in'
  },

  data() {
    return {
      logo,
      hat,
      body,
      scumbag,
      vintageMusic,
      walkman,
      bkClass: 'bk',
      blurClass: 'blur',
      loading: false,
      isShowing: false,
      options: {
        ref: true,
        dragAndMove: true,
        afterLoad: this.afterLoad,
        licenseKey: "MiT",
        navigation: true,
        anchors: ['page1', 'page2', 'page3', 'page4'],
        scrollingSpeed: 1500,
        sectionsColor: ['#e4ddd3', '#e4ddd3', '#1c1716', '#fec401'],
        controlArrows: true,
        verticalCentered: false,
        css3: true,
        slidesNavigation: false
      }
    };
  },

  methods: {
    toggleModal() {
      document.querySelector('.bg_stars').scrollIntoView({
        behavior: 'smooth'
      });
      this.isShowing = !this.isShowing;

      if (!this.isShowing) {
        this.$refs.modal.classList.add('out');
      }
    },

    closeModal() {
      this.$refs.button.classList.add('close');
      setTimeout(() => {
        this.$refs.modal.classList.add('out');
      }, 500);
      setTimeout(() => {
        this.isShowing = false;
      }, 500);
    },

    afterLoad: function animation(origin, destination, direction) {
      if (direction === "down" && destination.index === 1) {
        Velocity(this.$refs.scumbag, {
          opacity: 1,
          transform: ["translateX(0)", "translateX(75%)"]
        }, {
          easing: "ease-out",
          duration: 500,
          delay: 2500,
          queue: "test",
          complete: () => {
            Velocity(this.$refs.scumbag, {
              transform: ["rotate(12deg)", "rotate(0)"]
            }, {
              easing: [400, 4],
              duration: 1000,
              queue: "test",
              complete: this.afterLoad
            });
          },
          begin: () => {
            Velocity(this.$refs.welcomeStudio, {
              transform: ["translateX(-12%) rotate(8deg)", "translateX(0) rotate(0)"]
            }, {
              easing: "ease-in",
              queue: false,
              duration: 400,
              delay: 500,
              complete: this.afterLoad
            });
          }
        });
      } else if (direction === "up" && destination.index === 0) {
        Velocity(this.$refs.scumbag, {
          opacity: 0,
          transform: ["translateX(75%)", "translateX(0)"]
        }, {
          duration: 100,
          complete: () => {
            Velocity(this.$refs.scumbag, {
              transform: ["rotate(0)", "rotate(12deg)"]
            }, {
              duration: 100,
              complete: this.afterLoad
            });
          },
          begin: () => {
            Velocity(this.$refs.welcomeStudio, {
              transform: ["translateX(0) rotate(0)", "translateX(-12%) rotate(8deg)"]
            }, {
              complete: this.afterLoad
            });
          }
        });
      } else if (direction === "down" && destination.index === 2) {
        Velocity(this.$refs.vintageMusic, {
          opacity: 1
        }, {
          easing: "swing",
          duration: 550,
          begin: () => {
            this.$refs.vintageMusic.classList.add('animate__animated', 'animate__bounceInLeft', 'animate__delay-1s', 'animate__slow');
            setTimeout(() => {
              this.$refs.vintageMusic.classList.remove('animate__animated', 'animate__bounceInLeft', 'animate__delay-1s', 'animate__slow');
            }, 3000);
            Velocity(this.$refs.vintageMusic, {
              opacity: 1
            }, {
              easing: "swing",
              delay: 3500,
              complete: () => {
                this.$refs.vintageMusic.classList.add('animate__animated', 'animate__bounce', 'animate__repeat-2');
              }
            });
          }
        });
      } else if (direction === "up" && destination.index === 1) {
        Velocity(this.$refs.vintageMusic, {
          opacity: 0
        }, {
          begin: () => {
            this.$refs.vintageMusic.classList.remove('animate__animated', 'animate__bounce', 'animate__repeat-2');
          }
        });
      } else if (direction === "down" && destination.index === 3) {
        Velocity(this.$refs.form, {
          opacity: 1
        }, {
          begin: () => {
            this.$refs.form.classList.add('animate__animated', 'animate__bounceInRight', 'animate__delay-2s', 'animate__slow');
            this.$nuxt.$el.children[0].childNodes[0].children[1].children[3].children[2].classList.add('animate__animated', 'animate__slideInLeft', 'animate__delay-1s');
            this.$nuxt.$el.children[0].childNodes[0].children[1].children[3].children[2].style.opacity = "1";
            this.$nuxt.$el.children[0].children[0].children[1].children[3].children[2].children[2].children[0].classList.add('animate__animated', 'animate__zoomInDown', 'animate__delay-2s');
            this.$nuxt.$el.children[0].children[0].children[1].children[3].children[2].children[2].children[1].classList.add('animate__animated', 'animate__zoomInDown', 'animate__delay-3s');
            this.$nuxt.$el.children[0].children[0].children[1].children[3].children[2].children[2].children[2].classList.add('animate__animated', 'animate__zoomInDown', 'animate__delay-4s');
            this.$nuxt.$el.children[0].children[0].children[1].children[3].children[2].children[2].children[3].classList.add('animate__animated', 'animate__zoomInDown', 'animate__delay-5s');
          }
        });
      } else if (direction === "up" && destination.index === 2) {
        Velocity(this.$refs.form, {
          opacity: 0
        }, {
          begin: () => {
            this.$refs.form.classList.remove('animate__animated', 'animate__bounceInRight', 'animate__delay-2s', 'animate__slow');
            this.$nuxt.$el.children[0].childNodes[0].children[1].children[3].children[2].classList.remove('animate__animated', 'animate__slideInLeft', 'animate__delay-1s');
            this.$nuxt.$el.children[0].childNodes[0].children[1].children[3].children[2].style.opacity = "0";
          }
        });
      }
    },

    getFormValues(submitEvent) {
      this.name = submitEvent.target.elements.name.value;
    }

  },

  mounted() {
    this.$nextTick(() => {
      this.$nuxt.$loading.start();
    });
  }

});
// CONCATENATED MODULE: ./pages/index.vue?vue&type=script&lang=js&
 /* harmony default export */ var pagesvue_type_script_lang_js_ = (lib_vue_loader_options_pagesvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(2);

// CONCATENATED MODULE: ./pages/index.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(109)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  pagesvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "890467b0",
  "1b818184"
  
)

/* harmony default export */ var pages = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 44:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(47);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(4).default
module.exports.__inject__ = function (context) {
  add("11e9d053", content, true, context)
};

/***/ }),

/***/ 45:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/056a6af.webp";

/***/ }),

/***/ 46:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_vue_loader_lib_index_js_vue_loader_options_stickyFooter_vue_vue_type_style_index_0_id_52a36096_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(44);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_vue_loader_lib_index_js_vue_loader_options_stickyFooter_vue_vue_type_style_index_0_id_52a36096_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_vue_loader_lib_index_js_vue_loader_options_stickyFooter_vue_vue_type_style_index_0_id_52a36096_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_vue_loader_lib_index_js_vue_loader_options_stickyFooter_vue_vue_type_style_index_0_id_52a36096_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_vue_loader_lib_index_js_vue_loader_options_stickyFooter_vue_vue_type_style_index_0_id_52a36096_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 47:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(3);
var ___CSS_LOADER_GET_URL_IMPORT___ = __webpack_require__(9);
var ___CSS_LOADER_URL_IMPORT_0___ = __webpack_require__(48);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
var ___CSS_LOADER_URL_REPLACEMENT_0___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_0___);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".back-to-top-wrapper[data-v-52a36096]{top:100vh;right:.25rem;bottom:-5em;width:3em;pointer-events:none}.back-to-top-link[data-v-52a36096]{position:sticky;display:inline-block;z-index:1;width:50px;height:50px;border-radius:50%;color:#faebd7;font-size:1.2rem;line-height:52px;text-align:center;background-color:#1e1e1e;pointer-events:all;top:calc(100vh - 5rem);transition:all .5s}.back-to-top-link[data-v-52a36096]:after{position:absolute;width:100%;height:100%;border-radius:50%;content:\"\";box-sizing:content-box;top:-7px;left:-7px;padding:7px;box-shadow:0 0 0 4px #a1362b;transition:all .5s;transform:scale(.8);opacity:0}.back-to-top-link[data-v-52a36096]:hover{background-color:#faebd7;color:#a1362b}.back-to-top-link[data-v-52a36096]:focus{outline:none}.back-to-top-link[data-v-52a36096]:hover:after{transform:scale(1);opacity:1}.box[data-v-52a36096]{transition:all .5s;border:2px solid #a1362b;-webkit-transition:.5s}.box[data-v-52a36096]:hover{border:2px solid rgba(0,160,80,0);color:#faebd7}.box[data-v-52a36096]:after,.box[data-v-52a36096]:before{width:100%;height:135%;z-index:3;content:\"\";position:absolute;top:-20px;left:0;box-sizing:border-box;-webkit-transform:scale(0);transition:all .5s}.box[data-v-52a36096]:hover:after,.box[data-v-52a36096]:hover:before{transform:scale(1)}.curmudgeon[data-v-52a36096]:before{border-bottom:3px solid #faebd7;border-left:0;-webkit-transform-origin:0 100%}.curmudgeon[data-v-52a36096]:after{border-top:0;border-right:0;-webkit-transform-origin:50% 50%}#site-footer[data-v-52a36096]{box-shadow:0 7px 35px 0 #000;font-family:\"Indie Flower\",cursive}#site-footer[data-v-52a36096]:after{min-height:20vw;background-size:cover;background-position:50%}#site-footer[data-v-52a36096]:before{text-shadow:#000 5px -6px 2px}footer[data-v-52a36096]{color:#faebd7;background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_0___ + ");background-size:auto auto;background-size:initial;background-attachment:scroll;background-color:#222;box-shadow:0 1px 1px 0 rgba(0,0,0,.12);text-align:left;font:700 22px sans-serif;z-index:10;-webkit-mask:radial-gradient(160% 68.15% at bottom,#fff 79.5%,transparent 80%) bottom right,radial-gradient(160% 68.15% at top,transparent 79.5%,#fff 80%) bottom center,radial-gradient(160% 68.15% at bottom,#fff 79.5%,transparent 80%) bottom left;mask:radial-gradient(160% 68.15% at bottom,#fff 79.5%,transparent 80%) bottom right,radial-gradient(160% 68.15% at top,transparent 79.5%,#fff 80%) bottom center,radial-gradient(160% 68.15% at bottom,#fff 79.5%,transparent 80%) bottom left;-webkit-mask:radial-gradient(var(--r1,160%) var(--r2,68.15%) at bottom,#fff 79.5%,transparent 80%) bottom right,radial-gradient(var(--r1,160%) var(--r2,68.15%) at top,transparent 79.5%,#fff 80%) bottom center,radial-gradient(var(--r1,160%) var(--r2,68.15%) at bottom,#fff 79.5%,transparent 80%) bottom left;mask:radial-gradient(var(--r1,160%) var(--r2,68.15%) at bottom,#fff 79.5%,transparent 80%) bottom right,radial-gradient(var(--r1,160%) var(--r2,68.15%) at top,transparent 79.5%,#fff 80%) bottom center,radial-gradient(var(--r1,160%) var(--r2,68.15%) at bottom,#fff 79.5%,transparent 80%) bottom left;-webkit-mask-size:33.4% 140%;-webkit-mask-repeat:no-repeat;-webkit-mask-size:33.4% 183%;mask-size:33.4% 183%;mask-repeat:no-repeat}footer svg[data-v-52a36096]{background-color:transparent}footer svg[data-v-52a36096]:hover{background-color:#000}footer ul[data-v-52a36096]{list-style:none;font-family:Merriweather,sans-serif}footer ul>li[data-v-52a36096]{width:7vmax}footer ul:first-of-type li[data-v-52a36096]>{align-self:center;text-transform:uppercase}footer ul:first-of-type li>a[data-v-52a36096]{font-size:1vw}footer ul:first-of-type li>a[data-v-52a36096]:after{font-size:1em;content:\"✬\"}footer .icon[data-v-52a36096]{display:inline-block;position:relative;z-index:1;width:50px;height:50px;border-radius:50%;font-size:40px;color:#faebd7;line-height:52px;text-align:center;background-color:#1e1e1e}footer .icon[data-v-52a36096]:after{position:absolute;width:100%;height:100%;border-radius:50%;content:\"\";box-sizing:content-box}footer .icon-effect .icon[data-v-52a36096]{transition:all .5s}footer .icon-effect .icon[data-v-52a36096]:after{top:-7px;left:-7px;padding:7px;box-shadow:0 0 0 4px #a1362b;transition:all .5s;transform:scale(.8);opacity:0}footer .icon-effect-1a .icon[data-v-52a36096]:hover{background-color:#a1362b;color:#faebd7}footer .icon-effect-1a .icon[data-v-52a36096]:hover:after{transform:scale(1);opacity:1}#moveTo[data-v-52a36096]{transition:all .5s;border:2px solid #a1362b;-webkit-transition:.5s}#moveTo[data-v-52a36096]:hover{border:2px solid rgba(0,160,80,0);opacity:1;color:#faebd7}#moveTo[data-v-52a36096]:before{border-bottom:3px solid #faebd7;border-left:0;-webkit-transform-origin:0 100%;height:150%;top:-30px}#moveTo[data-v-52a36096]:after{height:150%;border-top:0;border-right:0;-webkit-transform-origin:50% 50%;width:100%;font-size:2rem;content:\"⮬\";top:-30px}#moveTo[data-v-52a36096]:hover:after,#moveTo[data-v-52a36096]:hover:before{transform:scale(1);opacity:1}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 48:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/4a23869.webp";

/***/ }),

/***/ 49:
/***/ (function(module, exports, __webpack_require__) {

module.exports = {
          srcSet: __webpack_require__.p + "img/609d61f-300.webp"+" 300w"+","+__webpack_require__.p + "img/b6c2ca9-560.webp"+" 560w",
          images:[ {path: __webpack_require__.p + "img/609d61f-300.webp",width: 300,height: 225},{path: __webpack_require__.p + "img/b6c2ca9-560.webp",width: 560,height: 420}],
          src: __webpack_require__.p + "img/609d61f-300.webp",
          toString:function(){return __webpack_require__.p + "img/609d61f-300.webp"},
          
          width: 300,
          height: 225
        }

/***/ }),

/***/ 50:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA0IDQiIHN0eWxlPSJlbmFibGUtYmFja2dyb3VuZDpuZXcgMCAwIDQgNCIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSI+PHBhdGggZD0ibTIgLjYtLjUgMS0xLjEuMS44LjctLjIgMSAxLS41IDEgLjUtLjItMSAuOC0uNy0xLjEtLjEtLjUtMXoiIHN0eWxlPSJmaWxsOiMyMjRhNDk7Y2xpcC1ydWxlOnJlZCIvPjwvc3ZnPg=="

/***/ }),

/***/ 51:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./components/stickyFooter.vue?vue&type=template&id=52a36096&scoped=true&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('footer',{staticClass:"opacity-0 hidden w-full h-24 p-2 flex items-center  justify-start box-border bg-repeat bg-center text-6xl text-center sm:h-24 md:block md:h-24 md-landscape:hidden lg:w-full xl:hidden  2xl:flex 2xl:h-40 ",attrs:{"id":"site-footer"}},[_vm._ssrNode("<img"+(_vm._ssrAttr("data-src",__webpack_require__(45)))+" alt=\"c1chy logo\""+(_vm._ssrClass("lazyload h-16 w-full relative mt-4 ml-2 mx-auto sm:h-20 sm:w-1/2 sm:mt-2 sm:ml-5 md:h-16 md:w-full md:ml-3 md:mt-4 lg:w-full lg:h-32  lg:ml-6 xl:h-36 xl:w-7/12 xl:mt-5  2xl:ml-6 2xl:mt-3  2xl:h-28 2xl:w-1/12  ",{'animate__animated animate__pulse animate__infinite  animate__delay-2s ' : _vm.animate}))+" data-v-52a36096> "),_vm._ssrNode("<ul class=\"hidden w-1/2 h-12  pt-2 flex  justify-evenly self-center flex-wrap sm:hidden lg:hidden xl:flex xl:block xl:10/12 2xl:w-1/2\" data-v-52a36096>","</ul>",[_vm._ssrNode("<li data-v-52a36096>","</li>",[_c('NuxtLink',{staticClass:"box curmudgeon flex justify-center items-center  w-36 h-16 relative  text-xl text-center text-white align-middle cursor-pointer xl:max-w-full xl:text-xs 2xl:text-xl",attrs:{"to":"/","no-prefetch":""}},[_vm._v("\r\n        Home")])],1),_vm._ssrNode(" "),_vm._ssrNode("<li data-v-52a36096>","</li>",[_c('NuxtLink',{staticClass:"box curmudgeon flex justify-center items-center  w-36 h-16 relative  text-xl text-center text-white align-middle cursor-pointer xl:max-w-full xl:text-xs 2xl:text-xl",attrs:{"to":"/aboutme","no-prefetch":""}},[_vm._v("\r\n        About Me")])],1),_vm._ssrNode(" "),_vm._ssrNode("<li data-v-52a36096>","</li>",[_c('NuxtLink',{staticClass:"box curmudgeon flex justify-center items-center  w-36 h-16 relative  text-xl text-center text-white align-middle cursor-pointer xl:max-w-full xl:text-xs 2xl:text-xl",attrs:{"to":"/portfolio","no-prefetch":""}},[_vm._v("\r\n        Portfolio")])],1),_vm._ssrNode(" "),_vm._ssrNode("<li class=\"flex\" data-v-52a36096>","</li>",[_c('NuxtLink',{staticClass:"box curmudgeon flex justify-center items-center  w-36 h-16 relative  text-xl text-center text-white align-middle cursor-pointer xl:max-w-full xl:text-xs 2xl:text-xl",attrs:{"to":"/contact","no-prefetch":""}},[_vm._v("\r\n        Contact\r\n\r\n      ")])],1)],2),_vm._ssrNode(" <ul class=\"icon-effect icon-effect-1a w-2/5 h-12 flex justify-end  xl:mt-5 2xl:w-1/2 \" data-v-52a36096><li data-v-52a36096><a href=\"https://www.github.com/\" aria-label=\"github\" class=\"icon\" data-v-52a36096><svg aria-hidden=\"true\" focusable=\"false\" data-prefix=\"fab\" data-icon=\"github\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 496 512\" class=\"svg-inline--fa fa-github fa-w-16\" data-v-52a36096><path fill=\"currentColor\" d=\"M165.9 397.4c0 2-2.3 3.6-5.2 3.6-3.3.3-5.6-1.3-5.6-3.6 0-2 2.3-3.6 5.2-3.6 3-.3 5.6 1.3 5.6 3.6zm-31.1-4.5c-.7 2 1.3 4.3 4.3 4.9 2.6 1 5.6 0 6.2-2s-1.3-4.3-4.3-5.2c-2.6-.7-5.5.3-6.2 2.3zm44.2-1.7c-2.9.7-4.9 2.6-4.6 4.9.3 2 2.9 3.3 5.9 2.6 2.9-.7 4.9-2.6 4.6-4.6-.3-1.9-3-3.2-5.9-2.9zM244.8 8C106.1 8 0 113.3 0 252c0 110.9 69.8 205.8 169.5 239.2 12.8 2.3 17.3-5.6 17.3-12.1 0-6.2-.3-40.4-.3-61.4 0 0-70 15-84.7-29.8 0 0-11.4-29.1-27.8-36.6 0 0-22.9-15.7 1.6-15.4 0 0 24.9 2 38.6 25.8 21.9 38.6 58.6 27.5 72.9 20.9 2.3-16 8.8-27.1 16-33.7-55.9-6.2-112.3-14.3-112.3-110.5 0-27.5 7.6-41.3 23.6-58.9-2.6-6.5-11.1-33.3 2.6-67.9 20.9-6.5 69 27 69 27 20-5.6 41.5-8.5 62.8-8.5s42.8 2.9 62.8 8.5c0 0 48.1-33.6 69-27 13.7 34.7 5.2 61.4 2.6 67.9 16 17.7 25.8 31.5 25.8 58.9 0 96.5-58.9 104.2-114.8 110.5 9.2 7.9 17 22.9 17 46.4 0 33.7-.3 75.4-.3 83.6 0 6.5 4.6 14.4 17.3 12.1C428.2 457.8 496 362.9 496 252 496 113.3 383.5 8 244.8 8zM97.2 352.9c-1.3 1-1 3.3.7 5.2 1.6 1.6 3.9 2.3 5.2 1 1.3-1 1-3.3-.7-5.2-1.6-1.6-3.9-2.3-5.2-1zm-10.8-8.1c-.7 1.3.3 2.9 2.3 3.9 1.6 1 3.6.7 4.3-.7.7-1.3-.3-2.9-2.3-3.9-2-.6-3.6-.3-4.3.7zm32.4 35.6c-1.6 1.3-1 4.3 1.3 6.2 2.3 2.3 5.2 2.6 6.5 1 1.3-1.3.7-4.3-1.3-6.2-2.2-2.3-5.2-2.6-6.5-1zm-11.4-14.7c-1.6 1-1.6 3.6 0 5.9 1.6 2.3 4.3 3.3 5.6 2.3 1.6-1.3 1.6-3.9 0-6.2-1.4-2.3-4-3.3-5.6-2z\" data-v-52a36096></path></svg></a></li> <li data-v-52a36096><a href=\"https://www.twitter.com/\" aria-label=\"twitter\" class=\"icon\" data-v-52a36096><svg aria-hidden=\"true\" focusable=\"false\" data-prefix=\"fab\" data-icon=\"twitter\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 512 512\" class=\"svg-inline--fa fa-twitter fa-w-16\" data-v-52a36096><path fill=\"currentColor\" d=\"M459.37 151.716c.325 4.548.325 9.097.325 13.645 0 138.72-105.583 298.558-298.558 298.558-59.452 0-114.68-17.219-161.137-47.106 8.447.974 16.568 1.299 25.34 1.299 49.055 0 94.213-16.568 130.274-44.832-46.132-.975-84.792-31.188-98.112-72.772 6.498.974 12.995 1.624 19.818 1.624 9.421 0 18.843-1.3 27.614-3.573-48.081-9.747-84.143-51.98-84.143-102.985v-1.299c13.969 7.797 30.214 12.67 47.431 13.319-28.264-18.843-46.781-51.005-46.781-87.391 0-19.492 5.197-37.36 14.294-52.954 51.655 63.675 129.3 105.258 216.365 109.807-1.624-7.797-2.599-15.918-2.599-24.04 0-57.828 46.782-104.934 104.934-104.934 30.213 0 57.502 12.67 76.67 33.137 23.715-4.548 46.456-13.32 66.599-25.34-7.798 24.366-24.366 44.833-46.132 57.827 21.117-2.273 41.584-8.122 60.426-16.243-14.292 20.791-32.161 39.308-52.628 54.253z\" data-v-52a36096></path></svg></a></li> <li data-v-52a36096><a href=\"https://facebook.com/\" aria-label=\"facebook\" class=\"icon\" data-v-52a36096><svg aria-hidden=\"true\" focusable=\"false\" data-prefix=\"fab\" data-icon=\"facebook\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 512 512\" class=\"svg-inline--fa fa-facebook fa-w-16\" data-v-52a36096><path fill=\"currentColor\" d=\"M504 256C504 119 393 8 256 8S8 119 8 256c0 123.78 90.69 226.38 209.25 245V327.69h-63V256h63v-54.64c0-62.15 37-96.48 93.67-96.48 27.14 0 55.52 4.84 55.52 4.84v61h-31.28c-30.8 0-40.41 19.12-40.41 38.73V256h68.78l-11 71.69h-57.78V501C413.31 482.38 504 379.78 504 256z\" data-v-52a36096></path></svg></a></li> <li data-v-52a36096><a href=\"#top\" aria-label=\"Scroll to Top\" class=\"back-to-top-link cursor-pointer\" data-v-52a36096>TOP</a></li></ul>")],2)}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/stickyFooter.vue?vue&type=template&id=52a36096&scoped=true&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/stickyFooter.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ var stickyFootervue_type_script_lang_js_ = ({
  name: "stickyFooter",

  data() {
    return {
      animate: true
    };
  },

  methods: {
    toTop() {
      window.scroll(0, 0);
      fullpage_api.moveTo('page1', 2);
    }

  }
});
// CONCATENATED MODULE: ./components/stickyFooter.vue?vue&type=script&lang=js&
 /* harmony default export */ var components_stickyFootervue_type_script_lang_js_ = (stickyFootervue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(2);

// CONCATENATED MODULE: ./components/stickyFooter.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(46)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  components_stickyFootervue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "52a36096",
  "d36dc324"
  
)

/* harmony default export */ var stickyFooter = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ 53:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/7dded70.webp";

/***/ }),

/***/ 54:
/***/ (function(module, exports) {

module.exports = "data:image/webp;base64,UklGRqIAAABXRUJQVlA4WAoAAAAQAAAADAAADAAAQUxQSFAAAAABYFTbtpKLQyUdQhPGf8ZvgDsjQvwSWBF6uDaIiAnA7/Ejd3We9Ot0pbdsXtd1Zq0OCPV63YkAQC8oLu0L64qsS7as5Cr3NchecMXhzF09BVZQOCAsAAAAcAEAnQEqDQANAAIANCWcNsAAGwgA/vDUOIO4Qrv4jD6HQIohv4fe86vQAAA="

/***/ }),

/***/ 61:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(110);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(4).default
module.exports.__inject__ = function (context) {
  add("1b27c8a9", content, true, context)
};

/***/ }),

/***/ 97:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/187a241.webp";

/***/ }),

/***/ 98:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/dc06245.webp";

/***/ }),

/***/ 99:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/cdcc73d.webp";

/***/ })

};;
//# sourceMappingURL=index.js.map