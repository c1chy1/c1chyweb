exports.ids = [2];
exports.modules = {

/***/ 116:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./pages/contact.vue?vue&type=template&id=a5f45b36&scoped=true&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"h-screen w-full absolute z-10"},[_vm._ssrNode("<header class=\"exclusive-paper container  relative p-24 w-full flex flex-col justify-center grid grid-cols-1 justify-items-center h-112 max-w-full lg:max-w-max  mx-auto filter-shadow-black relative overflow-hidden\" data-v-a5f45b36>","</header>",[_c('light',{staticClass:"filter-shadow-black overflow-hidden absolute"}),_vm._ssrNode(" <div class=\"title uppercase top-2\" data-v-a5f45b36><h1 class=\"text-8xl font-semibold text-center uppercase\" data-v-a5f45b36>Contact\n      </h1></div> <div class=\"title_dividers w-1/2 h-4 mx-auto my-10 relative inline-block\" data-v-a5f45b36><span class=\"w-full h-0.5 absolute left-2/4 transform -translate-x-1/2\" data-v-a5f45b36></span> <span class=\"w-full h-0.5 top-2 absolute left-2/4 transform -translate-x-1/2\" data-v-a5f45b36></span> <span class=\"w-full h-0.5 top-4 absolute left-2/4 transform -translate-x-1/2\" data-v-a5f45b36></span></div> "),_vm._ssrNode("<figure class=\"relative flex items-center justify-center filter-shadow-black z-10\" data-v-a5f45b36>","</figure>",[_vm._ssrNode("<img"+(_vm._ssrAttr("data-src",__webpack_require__(20)))+" alt=\"ribbon\" class=\"lazyload w-full h-20 my-auto z-1 filter-shadow-black\" data-v-a5f45b36> "),_vm._ssrNode("<figcaption class=\"absolute block mx-auto mt-5 text-white text-3xl text-center \" data-v-a5f45b36>","</figcaption>",[_c('NuxtLink',{attrs:{"to":"/"}},[_vm._v("Home")]),_vm._ssrNode("\n        &gt; Contact\n      ")],2)],2)],2),_vm._ssrNode(" <div class=\"page-spacing w-full h-20 absolute left-0 bg-repeat bg-center\" data-v-a5f45b36></div> "),_vm._ssrNode("<section class=\"section h-full mt-20 relative box-content bg-repeat bg-auto bg-center overflow-hidden z-0\" data-v-a5f45b36>","</section>",[_vm._ssrNode("<div class=\"bg_stars w-full h-full flex\" data-v-a5f45b36>","</div>",[_vm._ssrNode("<section class=\"w-1/2\" data-v-a5f45b36>","</section>",[_vm._ssrNode("<div class=\"h-full mx-auto w-2/3 flex flex-col justify-evenly\" data-v-a5f45b36>","</div>",[_vm._ssrNode("<h2 class=\" pt-1 pr-5 pl-2 pb-1 relative top-2 left-4 inline text-6xl font-semibold leading-tight\" data-v-a5f45b36>\n            MY CULTURE IS TIMELESS AGE IS JUST A NUMBER</h2> <p"+(_vm._ssrClass("mt-10 text-xl",[_vm.isShowing ? _vm.blurClass : '', _vm.bkClass]))+" data-v-a5f45b36>Menschen zu bewegen, ihnen den Alltag zu erleichtern und sie für Marken zu begeistern, ist meine Mission. Dafür kümmere ich mich mit Hingabe auch um die kleinen Details, ohne das große Ganze aus dem Blick zu verlieren. Ich experimentiere, erfinde, erforsche. Deshalb gehört es für mich zum Alltag, Herangehensweisen immer wieder zu überdenken und mit neuen Technologien alternative Lösungen abseits der ausgetretenen Pfade zu entwickeln.</p> "),_c('transition',{attrs:{"name":"fade"}},[(_vm.isShowing)?_c('div',{ref:"modal",staticClass:"lazyload modal flex w-full z-40"},[_c('img',{staticClass:"lazyload",attrs:{"data-src":__webpack_require__(76),"src":_vm.sick.src,"srcSet":_vm.sick.srcSet}}),_vm._v(" "),_c('article',{staticClass:"flex flex-row-reverse leading-snug"},[_c('button',{ref:"button",staticClass:"Icon relative right-2",attrs:{"id":"icon"},on:{"click":_vm.closeModal}},[_c('span'),_vm._v(" "),_c('span'),_vm._v(" "),_c('span')]),_vm._v(" "),_c('section',{staticClass:"text flex flex-col justify-center text-center"},[_c('h3',[_vm._v("Hey everyone look at this")]),_vm._v(" "),_c('h1',[_c('span',[_vm._v("Awesome Vintage Style")])])])])]):_vm._e()]),_vm._ssrNode(" <button id=\"aos-space\" class=\"button_red w-4/12 uppercase  lg:hidden 2xl:block 2xl:p-3\" data-v-a5f45b36>Lern Mehr</button>")],2)]),_vm._ssrNode(" <section class=\"w-1/2 p-20\" data-v-a5f45b36><img data-aos=\"rotate-space\" data-aos-anchor=\"#aos-space\" data-aos-easing=\"ease-in-sine\" data-aos-anchor-placement=\"center-bottom\""+(_vm._ssrAttr("data-src",__webpack_require__(77)))+" alt=\"spaceman\" class=\"lazyload mx-auto rounded-3xl\" data-v-a5f45b36></section>")],2)]),_vm._ssrNode(" "),_vm._ssrNode("<section class=\"exclusive-paper w-full h-auto bg-black rounded-4xl relative\" data-v-a5f45b36>","</section>",[_vm._ssrNode("<div class=\"contact_me w-3/4 h-28  items-center flex  mx-auto pt-20 \" data-v-a5f45b36><span class=\"w-full inline-block relative\" data-v-a5f45b36></span> <h2 class=\"w-7/12 font-bold text-3xl mt-4 text-center\" data-v-a5f45b36>HAVE ANY QUESTIONS</h2> <span class=\"w-full inline-block relative\" data-v-a5f45b36></span></div> <div data-v-a5f45b36><h1 class=\"text-10xl mb-20 font-bold text-center leading-tight \" data-v-a5f45b36>GET IN TOUCH</h1></div> <aside class=\"w-2/3 flex justify-center m-auto pb-5\" data-v-a5f45b36><article class=\"w-1/3 p-10 mb-10\" data-v-a5f45b36><h2 class=\"w-9/12 mb-5 mx-auto p-1 relative flex justify-center lg:text-xl 2xl:text-3xl font-semibold uppercase\" data-v-a5f45b36>\n          CONTACT ME</h2> <img"+(_vm._ssrAttr("data-src",__webpack_require__(78)))+" alt=\"woman c1chy\" class=\"lazyload m-auto\" data-v-a5f45b36> <span class=\"w-full\" data-v-a5f45b36></span> <ul class=\"mt-6  lg:text-xl 2xl:text-3xl text-center \" data-v-a5f45b36><li data-v-a5f45b36>58511 Lüdenscheid,</li> <li data-v-a5f45b36>Märkischer Kreis, NRW</li> <li data-v-a5f45b36><a href=\"mailto:cichy08081987pp@gmail.com\" class=\"inline\" data-v-a5f45b36>cichy08081987pp@gmail.com</a></li></ul></article> <article data-aos=\"zoom-in\" data-aos-delay=\"1500\" data-aos-anchor-placement=\"center-bottom\" data-anchor=\"#footer\" class=\"h-full flex w-1/3 flex-col p-10 p mb-10 bg-repeat bg-auto border-12 border-solid\" data-v-a5f45b36><h2 class=\"w-9/12  mb-5 mx-auto p-1 relative flex justify-center  lg:text-xl 2xl:text-3xl font-semibold uppercase\" data-v-a5f45b36>\n          LET ME KNOW!</h2> <p class=\"lg:text-xl   2xl:text-2xl text-center\" data-v-a5f45b36>Wenn Sie ein konkretes Anliegen haben, eine Idee besprechen möchten oder mich erst kennenlernen wollen, kontaktieren Sie mich einfach.</p> <form class=\"flex flex-col\" data-v-a5f45b36><label data-v-a5f45b36><input placeholder=\"Name*\" class=\"w-full h-12 mt-2 pl-1 text-2xl\" data-v-a5f45b36></label> <label data-v-a5f45b36><input placeholder=\"Email*\" class=\"w-full h-12 mt-2 pl-1 text-2xl \" data-v-a5f45b36></label> <label data-v-a5f45b36><textarea placeholder=\"Your message\" class=\"w-full h-32 pl-1 mt-2 block text-2xl resize-none\" data-v-a5f45b36></textarea></label></form> <a href=\"#\" class=\"button_red w-1/3 self-center xl:w-1/2 xl:p-2 \" data-v-a5f45b36>SEND</a></article> <article class=\"w-1/3 p-10 mb-10\" data-v-a5f45b36><h2 class=\"w-9/12  mb-5 mx-auto p-1 relative flex justify-center lg:text-xl 2xl:text-3xl font-semibold uppercase\" data-v-a5f45b36>OPEN HOURS</h2> <img"+(_vm._ssrAttr("data-src",__webpack_require__(79)))+" alt=\"clocks\" class=\"lazyload m-auto\" data-v-a5f45b36> <span data-v-a5f45b36></span> <ul class=\"mt-6 lg:text-xl   2xl:text-3xl text-center\" data-v-a5f45b36><li data-v-a5f45b36>Monday - Sunday</li> <li data-v-a5f45b36>00:00 - 23:59</li> <li data-v-a5f45b36>Cheers (:</li></ul></article></aside> <div class=\"page-spacing\" data-v-a5f45b36></div> "),_c('stickyFooter',{staticClass:"opacity-100",attrs:{"id":"footer"}})],2)],2)}
var staticRenderFns = []


// CONCATENATED MODULE: ./pages/contact.vue?vue&type=template&id=a5f45b36&scoped=true&

// EXTERNAL MODULE: ./components/stickyFooter.vue + 4 modules
var stickyFooter = __webpack_require__(51);

// EXTERNAL MODULE: ./components/light.vue + 4 modules
var light = __webpack_require__(10);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./pages/contact.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



const sick = __webpack_require__(80);

/* harmony default export */ var contactvue_type_script_lang_js_ = ({
  components: {
    stickyFooter: stickyFooter["a" /* default */],
    light: light["a" /* default */]
  },
  layout: 'desktop',
  transition: {
    name: 'spotlight',
    mode: 'out-in'
  },

  data() {
    return {
      sick,
      bkClass: 'bk',
      blurClass: 'blur',
      isShowing: false
    };
  },

  methods: {
    toggleModal() {
      document.querySelector('.bg_stars').scrollIntoView({
        behavior: 'smooth'
      });
      this.isShowing = !this.isShowing;

      if (!this.isShowing) {
        this.$refs.modal.classList.add('out');
      }
    },

    closeModal() {
      this.$refs.button.classList.add('close');
      setTimeout(() => {
        this.$refs.modal.classList.add('out');
      }, 500);
      setTimeout(() => {
        this.isShowing = false;
      }, 500);
    }

  },

  beforeMount() {
    fullpage_api.destroy('all');
  }

});
// CONCATENATED MODULE: ./pages/contact.vue?vue&type=script&lang=js&
 /* harmony default export */ var pages_contactvue_type_script_lang_js_ = (contactvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(2);

// CONCATENATED MODULE: ./pages/contact.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(81)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  pages_contactvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "a5f45b36",
  "50bcfe8c"
  
)

/* harmony default export */ var contact = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 44:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(47);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(4).default
module.exports.__inject__ = function (context) {
  add("11e9d053", content, true, context)
};

/***/ }),

/***/ 45:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/056a6af.webp";

/***/ }),

/***/ 46:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_vue_loader_lib_index_js_vue_loader_options_stickyFooter_vue_vue_type_style_index_0_id_52a36096_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(44);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_vue_loader_lib_index_js_vue_loader_options_stickyFooter_vue_vue_type_style_index_0_id_52a36096_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_vue_loader_lib_index_js_vue_loader_options_stickyFooter_vue_vue_type_style_index_0_id_52a36096_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_vue_loader_lib_index_js_vue_loader_options_stickyFooter_vue_vue_type_style_index_0_id_52a36096_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_vue_loader_lib_index_js_vue_loader_options_stickyFooter_vue_vue_type_style_index_0_id_52a36096_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 47:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(3);
var ___CSS_LOADER_GET_URL_IMPORT___ = __webpack_require__(9);
var ___CSS_LOADER_URL_IMPORT_0___ = __webpack_require__(48);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
var ___CSS_LOADER_URL_REPLACEMENT_0___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_0___);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".back-to-top-wrapper[data-v-52a36096]{top:100vh;right:.25rem;bottom:-5em;width:3em;pointer-events:none}.back-to-top-link[data-v-52a36096]{position:sticky;display:inline-block;z-index:1;width:50px;height:50px;border-radius:50%;color:#faebd7;font-size:1.2rem;line-height:52px;text-align:center;background-color:#1e1e1e;pointer-events:all;top:calc(100vh - 5rem);transition:all .5s}.back-to-top-link[data-v-52a36096]:after{position:absolute;width:100%;height:100%;border-radius:50%;content:\"\";box-sizing:content-box;top:-7px;left:-7px;padding:7px;box-shadow:0 0 0 4px #a1362b;transition:all .5s;transform:scale(.8);opacity:0}.back-to-top-link[data-v-52a36096]:hover{background-color:#faebd7;color:#a1362b}.back-to-top-link[data-v-52a36096]:focus{outline:none}.back-to-top-link[data-v-52a36096]:hover:after{transform:scale(1);opacity:1}.box[data-v-52a36096]{transition:all .5s;border:2px solid #a1362b;-webkit-transition:.5s}.box[data-v-52a36096]:hover{border:2px solid rgba(0,160,80,0);color:#faebd7}.box[data-v-52a36096]:after,.box[data-v-52a36096]:before{width:100%;height:135%;z-index:3;content:\"\";position:absolute;top:-20px;left:0;box-sizing:border-box;-webkit-transform:scale(0);transition:all .5s}.box[data-v-52a36096]:hover:after,.box[data-v-52a36096]:hover:before{transform:scale(1)}.curmudgeon[data-v-52a36096]:before{border-bottom:3px solid #faebd7;border-left:0;-webkit-transform-origin:0 100%}.curmudgeon[data-v-52a36096]:after{border-top:0;border-right:0;-webkit-transform-origin:50% 50%}#site-footer[data-v-52a36096]{box-shadow:0 7px 35px 0 #000;font-family:\"Indie Flower\",cursive}#site-footer[data-v-52a36096]:after{min-height:20vw;background-size:cover;background-position:50%}#site-footer[data-v-52a36096]:before{text-shadow:#000 5px -6px 2px}footer[data-v-52a36096]{color:#faebd7;background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_0___ + ");background-size:auto auto;background-size:initial;background-attachment:scroll;background-color:#222;box-shadow:0 1px 1px 0 rgba(0,0,0,.12);text-align:left;font:700 22px sans-serif;z-index:10;-webkit-mask:radial-gradient(160% 68.15% at bottom,#fff 79.5%,transparent 80%) bottom right,radial-gradient(160% 68.15% at top,transparent 79.5%,#fff 80%) bottom center,radial-gradient(160% 68.15% at bottom,#fff 79.5%,transparent 80%) bottom left;mask:radial-gradient(160% 68.15% at bottom,#fff 79.5%,transparent 80%) bottom right,radial-gradient(160% 68.15% at top,transparent 79.5%,#fff 80%) bottom center,radial-gradient(160% 68.15% at bottom,#fff 79.5%,transparent 80%) bottom left;-webkit-mask:radial-gradient(var(--r1,160%) var(--r2,68.15%) at bottom,#fff 79.5%,transparent 80%) bottom right,radial-gradient(var(--r1,160%) var(--r2,68.15%) at top,transparent 79.5%,#fff 80%) bottom center,radial-gradient(var(--r1,160%) var(--r2,68.15%) at bottom,#fff 79.5%,transparent 80%) bottom left;mask:radial-gradient(var(--r1,160%) var(--r2,68.15%) at bottom,#fff 79.5%,transparent 80%) bottom right,radial-gradient(var(--r1,160%) var(--r2,68.15%) at top,transparent 79.5%,#fff 80%) bottom center,radial-gradient(var(--r1,160%) var(--r2,68.15%) at bottom,#fff 79.5%,transparent 80%) bottom left;-webkit-mask-size:33.4% 140%;-webkit-mask-repeat:no-repeat;-webkit-mask-size:33.4% 183%;mask-size:33.4% 183%;mask-repeat:no-repeat}footer svg[data-v-52a36096]{background-color:transparent}footer svg[data-v-52a36096]:hover{background-color:#000}footer ul[data-v-52a36096]{list-style:none;font-family:Merriweather,sans-serif}footer ul>li[data-v-52a36096]{width:7vmax}footer ul:first-of-type li[data-v-52a36096]>{align-self:center;text-transform:uppercase}footer ul:first-of-type li>a[data-v-52a36096]{font-size:1vw}footer ul:first-of-type li>a[data-v-52a36096]:after{font-size:1em;content:\"✬\"}footer .icon[data-v-52a36096]{display:inline-block;position:relative;z-index:1;width:50px;height:50px;border-radius:50%;font-size:40px;color:#faebd7;line-height:52px;text-align:center;background-color:#1e1e1e}footer .icon[data-v-52a36096]:after{position:absolute;width:100%;height:100%;border-radius:50%;content:\"\";box-sizing:content-box}footer .icon-effect .icon[data-v-52a36096]{transition:all .5s}footer .icon-effect .icon[data-v-52a36096]:after{top:-7px;left:-7px;padding:7px;box-shadow:0 0 0 4px #a1362b;transition:all .5s;transform:scale(.8);opacity:0}footer .icon-effect-1a .icon[data-v-52a36096]:hover{background-color:#a1362b;color:#faebd7}footer .icon-effect-1a .icon[data-v-52a36096]:hover:after{transform:scale(1);opacity:1}#moveTo[data-v-52a36096]{transition:all .5s;border:2px solid #a1362b;-webkit-transition:.5s}#moveTo[data-v-52a36096]:hover{border:2px solid rgba(0,160,80,0);opacity:1;color:#faebd7}#moveTo[data-v-52a36096]:before{border-bottom:3px solid #faebd7;border-left:0;-webkit-transform-origin:0 100%;height:150%;top:-30px}#moveTo[data-v-52a36096]:after{height:150%;border-top:0;border-right:0;-webkit-transform-origin:50% 50%;width:100%;font-size:2rem;content:\"⮬\";top:-30px}#moveTo[data-v-52a36096]:hover:after,#moveTo[data-v-52a36096]:hover:before{transform:scale(1);opacity:1}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 48:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/4a23869.webp";

/***/ }),

/***/ 49:
/***/ (function(module, exports, __webpack_require__) {

module.exports = {
          srcSet: __webpack_require__.p + "img/609d61f-300.webp"+" 300w"+","+__webpack_require__.p + "img/b6c2ca9-560.webp"+" 560w",
          images:[ {path: __webpack_require__.p + "img/609d61f-300.webp",width: 300,height: 225},{path: __webpack_require__.p + "img/b6c2ca9-560.webp",width: 560,height: 420}],
          src: __webpack_require__.p + "img/609d61f-300.webp",
          toString:function(){return __webpack_require__.p + "img/609d61f-300.webp"},
          
          width: 300,
          height: 225
        }

/***/ }),

/***/ 50:
/***/ (function(module, exports) {

module.exports = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA0IDQiIHN0eWxlPSJlbmFibGUtYmFja2dyb3VuZDpuZXcgMCAwIDQgNCIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSI+PHBhdGggZD0ibTIgLjYtLjUgMS0xLjEuMS44LjctLjIgMSAxLS41IDEgLjUtLjItMSAuOC0uNy0xLjEtLjEtLjUtMXoiIHN0eWxlPSJmaWxsOiMyMjRhNDk7Y2xpcC1ydWxlOnJlZCIvPjwvc3ZnPg=="

/***/ }),

/***/ 51:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./components/stickyFooter.vue?vue&type=template&id=52a36096&scoped=true&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('footer',{staticClass:"opacity-0 hidden w-full h-24 p-2 flex items-center  justify-start box-border bg-repeat bg-center text-6xl text-center sm:h-24 md:block md:h-24 md-landscape:hidden lg:w-full xl:hidden  2xl:flex 2xl:h-40 ",attrs:{"id":"site-footer"}},[_vm._ssrNode("<img"+(_vm._ssrAttr("data-src",__webpack_require__(45)))+" alt=\"c1chy logo\""+(_vm._ssrClass("lazyload h-16 w-full relative mt-4 ml-2 mx-auto sm:h-20 sm:w-1/2 sm:mt-2 sm:ml-5 md:h-16 md:w-full md:ml-3 md:mt-4 lg:w-full lg:h-32  lg:ml-6 xl:h-36 xl:w-7/12 xl:mt-5  2xl:ml-6 2xl:mt-3  2xl:h-28 2xl:w-1/12  ",{'animate__animated animate__pulse animate__infinite  animate__delay-2s ' : _vm.animate}))+" data-v-52a36096> "),_vm._ssrNode("<ul class=\"hidden w-1/2 h-12  pt-2 flex  justify-evenly self-center flex-wrap sm:hidden lg:hidden xl:flex xl:block xl:10/12 2xl:w-1/2\" data-v-52a36096>","</ul>",[_vm._ssrNode("<li data-v-52a36096>","</li>",[_c('NuxtLink',{staticClass:"box curmudgeon flex justify-center items-center  w-36 h-16 relative  text-xl text-center text-white align-middle cursor-pointer xl:max-w-full xl:text-xs 2xl:text-xl",attrs:{"to":"/","no-prefetch":""}},[_vm._v("\r\n        Home")])],1),_vm._ssrNode(" "),_vm._ssrNode("<li data-v-52a36096>","</li>",[_c('NuxtLink',{staticClass:"box curmudgeon flex justify-center items-center  w-36 h-16 relative  text-xl text-center text-white align-middle cursor-pointer xl:max-w-full xl:text-xs 2xl:text-xl",attrs:{"to":"/aboutme","no-prefetch":""}},[_vm._v("\r\n        About Me")])],1),_vm._ssrNode(" "),_vm._ssrNode("<li data-v-52a36096>","</li>",[_c('NuxtLink',{staticClass:"box curmudgeon flex justify-center items-center  w-36 h-16 relative  text-xl text-center text-white align-middle cursor-pointer xl:max-w-full xl:text-xs 2xl:text-xl",attrs:{"to":"/portfolio","no-prefetch":""}},[_vm._v("\r\n        Portfolio")])],1),_vm._ssrNode(" "),_vm._ssrNode("<li class=\"flex\" data-v-52a36096>","</li>",[_c('NuxtLink',{staticClass:"box curmudgeon flex justify-center items-center  w-36 h-16 relative  text-xl text-center text-white align-middle cursor-pointer xl:max-w-full xl:text-xs 2xl:text-xl",attrs:{"to":"/contact","no-prefetch":""}},[_vm._v("\r\n        Contact\r\n\r\n      ")])],1)],2),_vm._ssrNode(" <ul class=\"icon-effect icon-effect-1a w-2/5 h-12 flex justify-end  xl:mt-5 2xl:w-1/2 \" data-v-52a36096><li data-v-52a36096><a href=\"https://www.github.com/\" aria-label=\"github\" class=\"icon\" data-v-52a36096><svg aria-hidden=\"true\" focusable=\"false\" data-prefix=\"fab\" data-icon=\"github\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 496 512\" class=\"svg-inline--fa fa-github fa-w-16\" data-v-52a36096><path fill=\"currentColor\" d=\"M165.9 397.4c0 2-2.3 3.6-5.2 3.6-3.3.3-5.6-1.3-5.6-3.6 0-2 2.3-3.6 5.2-3.6 3-.3 5.6 1.3 5.6 3.6zm-31.1-4.5c-.7 2 1.3 4.3 4.3 4.9 2.6 1 5.6 0 6.2-2s-1.3-4.3-4.3-5.2c-2.6-.7-5.5.3-6.2 2.3zm44.2-1.7c-2.9.7-4.9 2.6-4.6 4.9.3 2 2.9 3.3 5.9 2.6 2.9-.7 4.9-2.6 4.6-4.6-.3-1.9-3-3.2-5.9-2.9zM244.8 8C106.1 8 0 113.3 0 252c0 110.9 69.8 205.8 169.5 239.2 12.8 2.3 17.3-5.6 17.3-12.1 0-6.2-.3-40.4-.3-61.4 0 0-70 15-84.7-29.8 0 0-11.4-29.1-27.8-36.6 0 0-22.9-15.7 1.6-15.4 0 0 24.9 2 38.6 25.8 21.9 38.6 58.6 27.5 72.9 20.9 2.3-16 8.8-27.1 16-33.7-55.9-6.2-112.3-14.3-112.3-110.5 0-27.5 7.6-41.3 23.6-58.9-2.6-6.5-11.1-33.3 2.6-67.9 20.9-6.5 69 27 69 27 20-5.6 41.5-8.5 62.8-8.5s42.8 2.9 62.8 8.5c0 0 48.1-33.6 69-27 13.7 34.7 5.2 61.4 2.6 67.9 16 17.7 25.8 31.5 25.8 58.9 0 96.5-58.9 104.2-114.8 110.5 9.2 7.9 17 22.9 17 46.4 0 33.7-.3 75.4-.3 83.6 0 6.5 4.6 14.4 17.3 12.1C428.2 457.8 496 362.9 496 252 496 113.3 383.5 8 244.8 8zM97.2 352.9c-1.3 1-1 3.3.7 5.2 1.6 1.6 3.9 2.3 5.2 1 1.3-1 1-3.3-.7-5.2-1.6-1.6-3.9-2.3-5.2-1zm-10.8-8.1c-.7 1.3.3 2.9 2.3 3.9 1.6 1 3.6.7 4.3-.7.7-1.3-.3-2.9-2.3-3.9-2-.6-3.6-.3-4.3.7zm32.4 35.6c-1.6 1.3-1 4.3 1.3 6.2 2.3 2.3 5.2 2.6 6.5 1 1.3-1.3.7-4.3-1.3-6.2-2.2-2.3-5.2-2.6-6.5-1zm-11.4-14.7c-1.6 1-1.6 3.6 0 5.9 1.6 2.3 4.3 3.3 5.6 2.3 1.6-1.3 1.6-3.9 0-6.2-1.4-2.3-4-3.3-5.6-2z\" data-v-52a36096></path></svg></a></li> <li data-v-52a36096><a href=\"https://www.twitter.com/\" aria-label=\"twitter\" class=\"icon\" data-v-52a36096><svg aria-hidden=\"true\" focusable=\"false\" data-prefix=\"fab\" data-icon=\"twitter\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 512 512\" class=\"svg-inline--fa fa-twitter fa-w-16\" data-v-52a36096><path fill=\"currentColor\" d=\"M459.37 151.716c.325 4.548.325 9.097.325 13.645 0 138.72-105.583 298.558-298.558 298.558-59.452 0-114.68-17.219-161.137-47.106 8.447.974 16.568 1.299 25.34 1.299 49.055 0 94.213-16.568 130.274-44.832-46.132-.975-84.792-31.188-98.112-72.772 6.498.974 12.995 1.624 19.818 1.624 9.421 0 18.843-1.3 27.614-3.573-48.081-9.747-84.143-51.98-84.143-102.985v-1.299c13.969 7.797 30.214 12.67 47.431 13.319-28.264-18.843-46.781-51.005-46.781-87.391 0-19.492 5.197-37.36 14.294-52.954 51.655 63.675 129.3 105.258 216.365 109.807-1.624-7.797-2.599-15.918-2.599-24.04 0-57.828 46.782-104.934 104.934-104.934 30.213 0 57.502 12.67 76.67 33.137 23.715-4.548 46.456-13.32 66.599-25.34-7.798 24.366-24.366 44.833-46.132 57.827 21.117-2.273 41.584-8.122 60.426-16.243-14.292 20.791-32.161 39.308-52.628 54.253z\" data-v-52a36096></path></svg></a></li> <li data-v-52a36096><a href=\"https://facebook.com/\" aria-label=\"facebook\" class=\"icon\" data-v-52a36096><svg aria-hidden=\"true\" focusable=\"false\" data-prefix=\"fab\" data-icon=\"facebook\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 512 512\" class=\"svg-inline--fa fa-facebook fa-w-16\" data-v-52a36096><path fill=\"currentColor\" d=\"M504 256C504 119 393 8 256 8S8 119 8 256c0 123.78 90.69 226.38 209.25 245V327.69h-63V256h63v-54.64c0-62.15 37-96.48 93.67-96.48 27.14 0 55.52 4.84 55.52 4.84v61h-31.28c-30.8 0-40.41 19.12-40.41 38.73V256h68.78l-11 71.69h-57.78V501C413.31 482.38 504 379.78 504 256z\" data-v-52a36096></path></svg></a></li> <li data-v-52a36096><a href=\"#top\" aria-label=\"Scroll to Top\" class=\"back-to-top-link cursor-pointer\" data-v-52a36096>TOP</a></li></ul>")],2)}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/stickyFooter.vue?vue&type=template&id=52a36096&scoped=true&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/stickyFooter.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ var stickyFootervue_type_script_lang_js_ = ({
  name: "stickyFooter",

  data() {
    return {
      animate: true
    };
  },

  methods: {
    toTop() {
      window.scroll(0, 0);
      fullpage_api.moveTo('page1', 2);
    }

  }
});
// CONCATENATED MODULE: ./components/stickyFooter.vue?vue&type=script&lang=js&
 /* harmony default export */ var components_stickyFootervue_type_script_lang_js_ = (stickyFootervue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(2);

// CONCATENATED MODULE: ./components/stickyFooter.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(46)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  components_stickyFootervue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "52a36096",
  "d36dc324"
  
)

/* harmony default export */ var stickyFooter = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ 52:
/***/ (function(module, exports) {

module.exports = "data:image/webp;base64,UklGRnoAAABXRUJQVlA4WAoAAAAQAAAAFAAAEwAAQUxQSC0AAAABFzATEREGo0iSIiXnmzdqkIIUpKAW9jAQ0f91aAQmlR10N4PGCiar2sHRr2cAVlA4ICYAAADQAgCdASoVABQAPpFEnUqlo6KhqAgAsBIJaQAAPaOgAP74zxrAAA=="

/***/ }),

/***/ 53:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/7dded70.webp";

/***/ }),

/***/ 54:
/***/ (function(module, exports) {

module.exports = "data:image/webp;base64,UklGRqIAAABXRUJQVlA4WAoAAAAQAAAADAAADAAAQUxQSFAAAAABYFTbtpKLQyUdQhPGf8ZvgDsjQvwSWBF6uDaIiAnA7/Ejd3We9Ot0pbdsXtd1Zq0OCPV63YkAQC8oLu0L64qsS7as5Cr3NchecMXhzF09BVZQOCAsAAAAcAEAnQEqDQANAAIANCWcNsAAGwgA/vDUOIO4Qrv4jD6HQIohv4fe86vQAAA="

/***/ }),

/***/ 56:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(82);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(4).default
module.exports.__inject__ = function (context) {
  add("56e73927", content, true, context)
};

/***/ }),

/***/ 76:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/3ff07c5.webp";

/***/ }),

/***/ 77:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/e258ed5.webp";

/***/ }),

/***/ 78:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/1771baf.webp";

/***/ }),

/***/ 79:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/25d5abe.webp";

/***/ }),

/***/ 80:
/***/ (function(module, exports, __webpack_require__) {

module.exports = {
          srcSet: __webpack_require__.p + "img/40d460f-300.webp"+" 300w"+","+__webpack_require__.p + "img/b4d190d-397.webp"+" 397w",
          images:[ {path: __webpack_require__.p + "img/40d460f-300.webp",width: 300,height: 529},{path: __webpack_require__.p + "img/b4d190d-397.webp",width: 397,height: 700}],
          src: __webpack_require__.p + "img/40d460f-300.webp",
          toString:function(){return __webpack_require__.p + "img/40d460f-300.webp"},
          
          width: 300,
          height: 529
        }

/***/ }),

/***/ 81:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_vue_loader_lib_index_js_vue_loader_options_contact_vue_vue_type_style_index_0_id_a5f45b36_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_vue_loader_lib_index_js_vue_loader_options_contact_vue_vue_type_style_index_0_id_a5f45b36_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_vue_loader_lib_index_js_vue_loader_options_contact_vue_vue_type_style_index_0_id_a5f45b36_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_vue_loader_lib_index_js_vue_loader_options_contact_vue_vue_type_style_index_0_id_a5f45b36_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_3_node_modules_vue_loader_lib_index_js_vue_loader_options_contact_vue_vue_type_style_index_0_id_a5f45b36_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 82:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(3);
var ___CSS_LOADER_GET_URL_IMPORT___ = __webpack_require__(9);
var ___CSS_LOADER_URL_IMPORT_0___ = __webpack_require__(49);
var ___CSS_LOADER_URL_IMPORT_1___ = __webpack_require__(21);
var ___CSS_LOADER_URL_IMPORT_2___ = __webpack_require__(52);
var ___CSS_LOADER_URL_IMPORT_3___ = __webpack_require__(50);
var ___CSS_LOADER_URL_IMPORT_4___ = __webpack_require__(83);
var ___CSS_LOADER_URL_IMPORT_5___ = __webpack_require__(84);
var ___CSS_LOADER_URL_IMPORT_6___ = __webpack_require__(53);
var ___CSS_LOADER_URL_IMPORT_7___ = __webpack_require__(54);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(false);
var ___CSS_LOADER_URL_REPLACEMENT_0___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_0___);
var ___CSS_LOADER_URL_REPLACEMENT_1___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_1___);
var ___CSS_LOADER_URL_REPLACEMENT_2___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_2___);
var ___CSS_LOADER_URL_REPLACEMENT_3___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_3___);
var ___CSS_LOADER_URL_REPLACEMENT_4___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_4___);
var ___CSS_LOADER_URL_REPLACEMENT_5___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_5___);
var ___CSS_LOADER_URL_REPLACEMENT_6___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_6___);
var ___CSS_LOADER_URL_REPLACEMENT_7___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_7___);
// Module
___CSS_LOADER_EXPORT___.push([module.i, "[data-aos=rotate-space][data-v-a5f45b36]{transform:rotate(-540deg);transition-property:transform}[data-aos=rotate-space].aos-animate[data-v-a5f45b36]{transform:rotate(0deg)}h1[data-v-a5f45b36]{color:#224a49;filter:drop-shadow(5px 6px 0 #a9c9bb);font-family:Barlow Condensed,sans-serif}.exclusive-paper[data-v-a5f45b36]{background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_0___ + ");background-color:#faebd7}.button_red[data-v-a5f45b36]{background-color:transparent;color:#e53e26;margin-top:30px;border-color:#e53e26;border-style:solid;border-width:4px 0;font-weight:700;font-size:30px;line-height:1;text-align:center;position:relative;font-family:Barlow Condensed,sans-serif;transition:all .2s ease}.button_red[data-v-a5f45b36]:after,.button_red[data-v-a5f45b36]:before{background-color:#e53e26;content:\"\";position:absolute;top:50%;width:7px;height:7px;border-radius:50%;transform:translateY(-50%);transition:background-color .2s ease,transform .2s ease}.button_red[data-v-a5f45b36]:before{left:0}.button_red[data-v-a5f45b36]:after{right:0}.button_red[data-v-a5f45b36]:hover{color:#e6c8a0}.bk[data-v-a5f45b36]{transition:all .3s ease-out}.blur[data-v-a5f45b36]{filter:blur(1px);opacity:.4}div.modal[data-v-a5f45b36]{height:75px;width:75px;border-radius:40px;overflow:hidden;position:absolute;background-color:#f4dda9;-webkit-animation:bondJamesBond-data-v-a5f45b36 1.5s cubic-bezier(.165,.84,.44,1) forwards;animation:bondJamesBond-data-v-a5f45b36 1.5s cubic-bezier(.165,.84,.44,1) forwards}div.modal button[data-v-a5f45b36],div.modal h1 span[data-v-a5f45b36],div.modal h2[data-v-a5f45b36],div.modal h3[data-v-a5f45b36],div.modal img[data-v-a5f45b36],div.modal li[data-v-a5f45b36],div.modal p[data-v-a5f45b36]{opacity:0;position:relative;-webkit-animation:modalContentFadeIn-data-v-a5f45b36 .5s linear 1.4s forwards;animation:modalContentFadeIn-data-v-a5f45b36 .5s linear 1.4s forwards}div.modal.out[data-v-a5f45b36]{-webkit-animation:slowFade-data-v-a5f45b36 1.5s;animation:slowFade-data-v-a5f45b36 1.5s}div.modal.out>h2[data-v-a5f45b36],div.modal.out button[data-v-a5f45b36],div.modal.out h1 span[data-v-a5f45b36],div.modal.out h3[data-v-a5f45b36],div.modal.out img[data-v-a5f45b36],div.modal.out li[data-v-a5f45b36],div.modal.out p[data-v-a5f45b36]{-webkit-animation:modalContentFadeOut-data-v-a5f45b36 1s;animation:modalContentFadeOut-data-v-a5f45b36 1s}@-webkit-keyframes slowFade-data-v-a5f45b36{0%{height:375px;width:45%;border-radius:0}80%{border-radius:40px;width:30%}90%{transform:translateX(0);height:75px;width:10%}to{height:75px;width:75px;transform:translateX(1000px)}}@keyframes slowFade-data-v-a5f45b36{0%{height:375px;width:45%;border-radius:0}80%{border-radius:40px;width:30%}90%{transform:translateX(0);height:75px;width:10%}to{height:75px;width:75px;transform:translateX(1000px)}}@-webkit-keyframes modalContentFadeIn-data-v-a5f45b36{0%{opacity:0;top:-20px}to{opacity:1;top:0}}@keyframes modalContentFadeIn-data-v-a5f45b36{0%{opacity:0;top:-20px}to{opacity:1;top:0}}@-webkit-keyframes modalContentFadeOut-data-v-a5f45b36{0%{opacity:1;top:0}to{opacity:0;top:-20px}}@keyframes modalContentFadeOut-data-v-a5f45b36{0%{opacity:1;top:0}to{opacity:0;top:-20px}}@-webkit-keyframes bondJamesBond-data-v-a5f45b36{0%{transform:translateX(1000px)}80%{transform:translateX(0);border-radius:40px;height:75px;width:75px}90%{border-radius:3px;height:322px;width:40%}to{border-radius:0;height:375px;width:45%}}@keyframes bondJamesBond-data-v-a5f45b36{0%{transform:translateX(1000px)}80%{transform:translateX(0);border-radius:40px;height:75px;width:75px}90%{border-radius:3px;height:322px;width:40%}to{border-radius:0;height:375px;width:45%}}div.modal section.text[data-v-a5f45b36]{position:relative;width:100%;min-width:300px}div.modal h1[data-v-a5f45b36],div.modal h3[data-v-a5f45b36]{font-family:\"Oswald\",sans-serif;color:#121212;transform:matrix(1,-.2,0,1,0,0);-ms-transform:matrix(1,-.2,0,1,0,0);-webkit-transform:matrix(1,-.2,0,1,0,0)}div.modal h1[data-v-a5f45b36]{text-transform:uppercase;font-weight:400;font-size:3.5vw;text-shadow:4px 5px #e6e6d8,6px 7px #c6a39a;filter:none}div.modal h1 span[data-v-a5f45b36]{display:inline-block;vertical-align:middle}div.modal h3[data-v-a5f45b36]{font-family:\"Merriweather\",sans-serif;text-transform:uppercase;font-weight:700;font-size:.8vw;letter-spacing:.2em;margin-bottom:10px;position:relative}div.modal h3[data-v-a5f45b36]:after,div.modal h3[data-v-a5f45b36]:before{content:\" \";position:absolute;width:100px;height:10px;border-top:2px solid #121212;border-bottom:2px solid #121212}div.modal h3[data-v-a5f45b36]:before{margin:5px 0 0 -110px}div.modal h3[data-v-a5f45b36]:after{margin:5px 0 0 10px}.Icon[data-v-a5f45b36]{width:50px;height:50px;position:relative;transition:.5s ease-in-out;cursor:pointer}.Icon[data-v-a5f45b36],.Icon span[data-v-a5f45b36]{transform:rotate(0deg)}.Icon span[data-v-a5f45b36]{display:block;position:absolute;left:0;top:23px;height:8px;width:100%;background:#fff;border-radius:4px;transition:.2s ease-in-out}.Icon span[data-v-a5f45b36]:first-child,.Icon span[data-v-a5f45b36]:nth-child(3){width:50%;transform:rotate(45deg)}.Icon span[data-v-a5f45b36]:first-child{left:3px;top:15px}.Icon span[data-v-a5f45b36]:nth-child(2){transform:rotate(-45deg)}.Icon span[data-v-a5f45b36]:nth-child(3){left:20px;top:32px}.close span[data-v-a5f45b36]:first-child,.close span[data-v-a5f45b36]:nth-child(3){left:-1px}.close span[data-v-a5f45b36]:first-child{top:15px;transform:rotate(135deg)}.close span[data-v-a5f45b36]:nth-child(2){transform:rotate(0deg)}.close span[data-v-a5f45b36]:nth-child(3){top:31px;transform:rotate(45deg)}header h1[data-v-a5f45b36]{color:#224a49;filter:drop-shadow(5px 6px 0 #a9c9bb);font-family:Barlow Condensed,sans-serif}header div[data-v-a5f45b36]:first-child{width:100vw;position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);margin:0;overflow:hidden}header img.light[data-v-a5f45b36]{height:100vmax;width:100%;-webkit-animation:rotate 120s linear infinite;animation:rotate 120s linear infinite;z-index:-1;-o-object-fit:cover;object-fit:cover;overflow:hidden}header .title[data-v-a5f45b36]{font-family:Barlow Condensed,sans-serif;color:#4f7b70;line-height:normal}header .title h1[data-v-a5f45b36]{-webkit-text-stroke-width:3px;filter:drop-shadow(4px 5px 0 #224a49);-webkit-text-stroke-color:#e4ddd3;background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_1___ + ");background-color:#4f7b70;-webkit-font-smoothing:antialiased;-webkit-background-clip:text;-webkit-text-fill-color:transparent}header .title_dividers span[data-v-a5f45b36]{background:linear-gradient(270deg,hsla(0,0%,100%,.01),#e9e4dd,#e9e4dd,hsla(0,0%,100%,.01))}header figure figcaption[data-v-a5f45b36]{font-family:Satisfy,sans-serif;letter-spacing:10px}header figure figcaption a[data-v-a5f45b36]{transition:all .2s ease}header figure figcaption a[data-v-a5f45b36]:hover{color:#224a49}.page-spacing[data-v-a5f45b36]{background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_2___ + ");background-color:#f7ebd5}.title[data-v-a5f45b36]{font-family:Barlow Condensed,sans-serif;color:#4f7b70;line-height:normal}.title h1[data-v-a5f45b36]{-webkit-text-stroke-width:3px;filter:drop-shadow(4px 5px 0 #224a49);-webkit-text-stroke-color:#e4ddd3;background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_1___ + ");background-color:#4f7b70;-webkit-font-smoothing:antialiased;-webkit-background-clip:text;-webkit-text-fill-color:transparent}.title .title_dividers span[data-v-a5f45b36]{background:linear-gradient(270deg,hsla(0,0%,100%,.01),#e9e4dd,#e9e4dd,hsla(0,0%,100%,.01))}figure figcaption[data-v-a5f45b36]{font-family:Satisfy,sans-serif;letter-spacing:10px}figure figcaption a[data-v-a5f45b36]{transition:all .2s ease}.contact_me[data-v-a5f45b36],figure figcaption a[data-v-a5f45b36]:hover{color:#224a49}.contact_me span[data-v-a5f45b36]:before{background-color:#224a49;content:\"\";position:absolute;left:0;width:100%;height:3px;top:0}.contact_me span[data-v-a5f45b36]:after{top:14px;height:8px;position:absolute;left:0;width:100%;content:\"\";display:block;background:url(" + ___CSS_LOADER_URL_REPLACEMENT_3___ + ") repeat-x 0 0}.contact_me h2[data-v-a5f45b36]{font-family:Barlow Condensed,sans-serif}aside article:first-child span[data-v-a5f45b36]:after,aside article:nth-child(3) span[data-v-a5f45b36]:after{width:75%;top:14px;height:8px;position:relative;content:\"\";display:block;background:url(" + ___CSS_LOADER_URL_REPLACEMENT_3___ + ") repeat-x 0 0;margin:0 auto}aside article:first-child ul li[data-v-a5f45b36]:not(:last-child),aside article:nth-child(3) ul li[data-v-a5f45b36]:not(:last-child){background-image:linear-gradient(90deg,#757575 33%,hsla(0,0%,100%,0) 0);background-position:bottom;background-size:8px 2px;background-repeat:repeat-x}aside article:first-child ul li a[data-v-a5f45b36],aside article:nth-child(3) ul li a[data-v-a5f45b36]{color:#224a49;transition:all .2s ease}aside article:first-child ul li a[data-v-a5f45b36]:hover,aside article:nth-child(3) ul li a[data-v-a5f45b36]:hover{outline:none;color:#e53e26}aside article[data-v-a5f45b36]:nth-child(2){-o-border-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_4___ + ") 12 round;border-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_4___ + ") 12 round;background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_5___ + ");background-position:0 0;padding-top:28px}aside article:nth-child(2) .button_red[data-v-a5f45b36]:hover{color:#4f7b70}aside article h2[data-v-a5f45b36]{background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_1___ + ");background-color:#4f7b70;color:#f7ebd5;box-shadow:-10px 0 0 #4f7b70;white-space:revert}aside input[data-v-a5f45b36],aside textarea[data-v-a5f45b36]{background-color:rgba(79,123,112,.07)}aside input[data-v-a5f45b36]::-moz-placeholder,aside textarea[data-v-a5f45b36]::-moz-placeholder{font-size:1.3rem;color:#333;padding-left:5px}aside input[data-v-a5f45b36]:-ms-input-placeholder,aside textarea[data-v-a5f45b36]:-ms-input-placeholder{font-size:1.3rem;color:#333;padding-left:5px}aside input[data-v-a5f45b36]::placeholder,aside textarea[data-v-a5f45b36]::placeholder{font-size:1.3rem;color:#333;padding-left:5px}.section[data-v-a5f45b36]{background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_6___ + ");background-color:#1c1716}.section[data-v-a5f45b36]:before{bottom:14px;float:left;width:97.8%;height:16px;background:url(" + ___CSS_LOADER_URL_REPLACEMENT_7___ + ") bottom repeat-x;border-image-repeat:round;border-style:solid}.section[data-v-a5f45b36]:after,.section[data-v-a5f45b36]:before{left:20px;position:absolute;content:\"\";display:block;border-image-width:3px;border-image-source:url(" + ___CSS_LOADER_URL_REPLACEMENT_7___ + ")}.section[data-v-a5f45b36]:after{top:6px;width:97.9%;height:15px;margin:0 auto;background:url(" + ___CSS_LOADER_URL_REPLACEMENT_7___ + ") top repeat-x;border-image-repeat:repeat;border-style:solid}.section .bg_stars[data-v-a5f45b36]{color:#fff}.section .bg_stars h2[data-v-a5f45b36]{background-image:url(" + ___CSS_LOADER_URL_REPLACEMENT_1___ + ");background-color:#a1362b;color:#eae5de;box-shadow:-20px 0 0 #a1362b;white-space:revert}.section .bg_stars[data-v-a5f45b36]:before{left:10px;background:url(" + ___CSS_LOADER_URL_REPLACEMENT_7___ + ") 0 repeat-y}.section .bg_stars[data-v-a5f45b36]:after,.section .bg_stars[data-v-a5f45b36]:before{top:18px;width:15px;position:absolute;height:94.7%;content:\"\";display:block;border-image-width:3px;border-image-source:url(" + ___CSS_LOADER_URL_REPLACEMENT_7___ + ");border-image-repeat:repeat;border-style:solid}.section .bg_stars[data-v-a5f45b36]:after{right:13px;background:url(" + ___CSS_LOADER_URL_REPLACEMENT_7___ + ") 100% repeat-y}.section p[data-v-a5f45b36]{font-family:monospace;color:rgba(233,228,221,.7)}", ""]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 83:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/ac9343d.webp";

/***/ }),

/***/ 84:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/11bf302.webp";

/***/ })

};;
//# sourceMappingURL=contact.js.map