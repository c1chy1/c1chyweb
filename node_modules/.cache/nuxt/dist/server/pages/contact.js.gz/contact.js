exports.ids = [4];
exports.modules = {

/***/ 28:
/***/ (function(module, exports) {

// Exports
module.exports = {

};


/***/ }),

/***/ 48:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/3ff07c5.webp";

/***/ }),

/***/ 49:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/e258ed5.webp";

/***/ }),

/***/ 50:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/1771baf.webp";

/***/ }),

/***/ 51:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/25d5abe.webp";

/***/ }),

/***/ 52:
/***/ (function(module, exports, __webpack_require__) {

module.exports = {
          srcSet: __webpack_require__.p + "img/40d460f-300.webp"+" 300w"+","+__webpack_require__.p + "img/b4d190d-397.webp"+" 397w",
          images:[ {path: __webpack_require__.p + "img/40d460f-300.webp",width: 300,height: 529},{path: __webpack_require__.p + "img/b4d190d-397.webp",width: 397,height: 700}],
          src: __webpack_require__.p + "img/40d460f-300.webp",
          toString:function(){return __webpack_require__.p + "img/40d460f-300.webp"},
          
          width: 300,
          height: 529
        }

/***/ }),

/***/ 53:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_0_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_1_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_vue_loader_lib_index_js_vue_loader_options_contact_vue_vue_type_style_index_0_id_25c93086_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(28);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_0_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_1_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_vue_loader_lib_index_js_vue_loader_options_contact_vue_vue_type_style_index_0_id_25c93086_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_0_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_1_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_vue_loader_lib_index_js_vue_loader_options_contact_vue_vue_type_style_index_0_id_25c93086_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_0_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_1_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_vue_loader_lib_index_js_vue_loader_options_contact_vue_vue_type_style_index_0_id_25c93086_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_0_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_1_node_modules_sass_loader_dist_cjs_js_ref_7_oneOf_1_2_node_modules_vue_loader_lib_index_js_vue_loader_options_contact_vue_vue_type_style_index_0_id_25c93086_scoped_true_lang_scss___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 77:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./pages/contact.vue?vue&type=template&id=25c93086&scoped=true&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"h-screen w-full absolute z-10"},[_vm._ssrNode("<header class=\"exclusive-paper container  relative p-24 w-full flex flex-col justify-center grid grid-cols-1 justify-items-center h-112 max-w-full lg:max-w-max  mx-auto relative overflow-hidden\" data-v-25c93086>","</header>",[_c('light',{staticClass:"overflow-hidden filter-shadow-black"}),_vm._ssrNode(" <div class=\"title uppercase top-2\" data-v-25c93086><h1 class=\"text-8xl font-semibold text-center uppercase\" data-v-25c93086>Contact\n      </h1></div> <div class=\"title_dividers w-1/2 h-4 mx-auto my-10 relative inline-block\" data-v-25c93086><span class=\"w-full h-0.5 absolute left-2/4 transform -translate-x-1/2\" data-v-25c93086></span> <span class=\"w-full h-0.5 top-2 absolute left-2/4 transform -translate-x-1/2\" data-v-25c93086></span> <span class=\"w-full h-0.5 top-4 absolute left-2/4 transform -translate-x-1/2\" data-v-25c93086></span></div> "),_vm._ssrNode("<figure class=\"relative flex items-center justify-center filter-shadow-black z-10\" data-v-25c93086>","</figure>",[_vm._ssrNode("<img"+(_vm._ssrAttr("data-src",__webpack_require__(15)))+" alt=\"ribbon\" class=\"lazyload w-full h-20 my-auto z-1 filter-shadow-black\" data-v-25c93086> "),_vm._ssrNode("<figcaption class=\"absolute block mx-auto mt-5 text-white text-3xl text-center \" data-v-25c93086>","</figcaption>",[_c('NuxtLink',{attrs:{"to":"/"}},[_vm._v("Home")]),_vm._ssrNode("\n        &gt; Contact\n      ")],2)],2)],2),_vm._ssrNode(" <div class=\"page-spacing w-full h-20 absolute left-0 bg-repeat bg-center\" data-v-25c93086></div> "),_vm._ssrNode("<section class=\"section h-full mt-20 relative box-content bg-repeat bg-auto bg-center overflow-hidden z-0\" data-v-25c93086>","</section>",[_vm._ssrNode("<div class=\"bg_stars w-full h-full flex\" data-v-25c93086>","</div>",[_vm._ssrNode("<section class=\"w-1/2\" data-v-25c93086>","</section>",[_vm._ssrNode("<div class=\"h-full mx-auto w-2/3 flex flex-col justify-evenly\" data-v-25c93086>","</div>",[_vm._ssrNode("<h2 class=\" pt-1 pr-5 pl-2 pb-1 relative top-2 left-4 inline text-6xl font-semibold leading-tight\" data-v-25c93086>\n            MY CULTURE IS TIMELESS AGE IS JUST A NUMBER</h2> <p"+(_vm._ssrClass("mt-10 text-xl",[_vm.isShowing ? _vm.blurClass : '', _vm.bkClass]))+" data-v-25c93086>Menschen zu bewegen, ihnen den Alltag zu erleichtern und sie für Marken zu begeistern, ist meine Mission. Dafür kümmere ich mich mit Hingabe auch um die kleinen Details, ohne das große Ganze aus dem Blick zu verlieren. Ich experimentiere, erfinde, erforsche. Deshalb gehört es für mich zum Alltag, Herangehensweisen immer wieder zu überdenken und mit neuen Technologien alternative Lösungen abseits der ausgetretenen Pfade zu entwickeln.</p> "),_c('transition',{attrs:{"name":"fade"}},[(_vm.isShowing)?_c('div',{ref:"modal",staticClass:"lazyload modal flex w-full z-40"},[_c('img',{staticClass:"lazyload",attrs:{"data-src":__webpack_require__(48),"src":_vm.sick.src,"srcSet":_vm.sick.srcSet}}),_vm._v(" "),_c('article',{staticClass:"flex flex-row-reverse leading-snug"},[_c('button',{ref:"button",staticClass:"Icon relative right-2",attrs:{"id":"icon"},on:{"click":_vm.closeModal}},[_c('span'),_vm._v(" "),_c('span'),_vm._v(" "),_c('span')]),_vm._v(" "),_c('section',{staticClass:"text flex flex-col justify-center text-center"},[_c('h3',[_vm._v("Hey everyone look at this")]),_vm._v(" "),_c('h1',[_c('span',[_vm._v("Awesome Vintage Style")])])])])]):_vm._e()]),_vm._ssrNode(" <button id=\"aos-space\" class=\"button_red w-4/12 uppercase  lg:hidden 2xl:block 2xl:p-3\" data-v-25c93086>Lern Mehr</button>")],2)]),_vm._ssrNode(" <section class=\"w-1/2 p-20\" data-v-25c93086><img data-aos=\"rotate-space\" data-aos-anchor=\"#aos-space\" data-aos-easing=\"ease-in-sine\" data-aos-anchor-placement=\"center-bottom\""+(_vm._ssrAttr("data-src",__webpack_require__(49)))+" alt=\"spaceman\" class=\"lazyload mx-auto rounded-3xl\" data-v-25c93086></section>")],2)]),_vm._ssrNode(" "),_vm._ssrNode("<section id=\"contact_me\" class=\"exclusive-paper w-full h-auto bg-black rounded-4xl relative\" data-v-25c93086>","</section>",[_vm._ssrNode("<div class=\"contact_me w-3/4 h-28  items-center flex  mx-auto pt-20 \" data-v-25c93086><span class=\"w-full inline-block relative\" data-v-25c93086></span> <h2 class=\"w-7/12 font-bold text-3xl mt-4 text-center\" data-v-25c93086>HAVE ANY QUESTIONS</h2> <span class=\"w-full inline-block relative\" data-v-25c93086></span></div> <div data-v-25c93086><h1 class=\"text-11xl mb-20  text-center leading-tight \" data-v-25c93086>GET IN TOUCH</h1></div> <aside class=\"w-3/4 flex justify-center m-auto pb-5\" data-v-25c93086><article class=\"w-1/3 p-10 mb-10\" data-v-25c93086><h2 class=\"w-9/12 mb-5 mx-auto p-1 relative flex justify-center lg:text-xl 2xl:text-3xl font-semibold uppercase\" data-v-25c93086>\n          CONTACT ME</h2> <img"+(_vm._ssrAttr("data-src",__webpack_require__(50)))+" alt=\"woman c1chy\" class=\"lazyload m-auto\" data-v-25c93086> <span class=\"w-full\" data-v-25c93086></span> <ul class=\"mt-6  lg:text-xl 2xl:text-3xl text-center \" data-v-25c93086><li data-v-25c93086>58511 Lüdenscheid,</li> <li data-v-25c93086>Märkischer Kreis, NRW</li> <li data-v-25c93086><a href=\"mailto:cichy08081987pp@gmail.com\" class=\"inline\" data-v-25c93086>cichy08081987pp@gmail.com</a></li></ul></article> <article data-aos=\"zoom-in\" data-aos-delay=\"1500\" data-aos-anchor-placement=\"center-bottom\" data-anchor=\"#footer\" class=\"h-full flex w-1/3 flex-col p-10 p mb-10 bg-repeat bg-auto border-12 border-solid\" data-v-25c93086><h2 class=\"w-9/12  mb-5 mx-auto p-1 relative flex justify-center  lg:text-xl 2xl:text-3xl font-semibold uppercase\" data-v-25c93086>\n          LET ME KNOW!</h2> <p class=\"lg:text-xl   2xl:text-2xl text-center\" data-v-25c93086>Wenn Sie ein konkretes Anliegen haben, eine Idee besprechen möchten oder mich erst kennenlernen wollen, kontaktieren Sie mich einfach.</p> <form class=\"flex flex-col\" data-v-25c93086><label data-v-25c93086><input placeholder=\"Name*\" class=\"w-full h-12 mt-2 pl-1 text-2xl\" data-v-25c93086></label> <label data-v-25c93086><input placeholder=\"Email*\" class=\"w-full h-12 mt-2 pl-1 text-2xl \" data-v-25c93086></label> <label data-v-25c93086><textarea placeholder=\"Your message\" class=\"w-full h-32 pl-1 mt-2 block text-2xl resize-none\" data-v-25c93086></textarea></label></form> <a href=\"#\" class=\"button_red w-1/3 self-center xl:w-1/2 xl:p-2 \" data-v-25c93086>SEND</a></article> <article class=\"w-1/3 p-10 mb-10\" data-v-25c93086><h2 class=\"w-9/12  mb-5 mx-auto p-1 relative flex justify-center lg:text-xl 2xl:text-3xl font-semibold uppercase\" data-v-25c93086>OPEN HOURS</h2> <img"+(_vm._ssrAttr("data-src",__webpack_require__(51)))+" alt=\"clocks\" class=\"lazyload m-auto\" data-v-25c93086> <span data-v-25c93086></span> <ul class=\"mt-6 lg:text-xl   2xl:text-3xl text-center\" data-v-25c93086><li data-v-25c93086>Monday - Sunday</li> <li data-v-25c93086>00:00 - 23:59</li> <li data-v-25c93086>Cheers (:</li></ul></article></aside> <div class=\"page-spacing\" data-v-25c93086></div> "),_c('stickyFooter',{staticClass:"opacity-100",attrs:{"id":"footer"}})],2)],2)}
var staticRenderFns = []


// CONCATENATED MODULE: ./pages/contact.vue?vue&type=template&id=25c93086&scoped=true&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./pages/contact.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
const sick = __webpack_require__(52);

/* harmony default export */ var contactvue_type_script_lang_js_ = ({
  components: {
    light: () => __webpack_require__.e(/* import() */ 0).then(__webpack_require__.bind(null, 80)),
    stickyFooter: () => __webpack_require__.e(/* import() */ 1).then(__webpack_require__.bind(null, 81))
  },
  layout: 'desktop',
  transition: {
    name: 'spotlight',
    mode: 'out-in'
  },

  data() {
    return {
      sick,
      bkClass: 'bk',
      blurClass: 'blur',
      isShowing: false
    };
  },

  methods: {
    toggleModal() {
      document.querySelector('.bg_stars').scrollIntoView({
        behavior: 'smooth'
      });
      this.isShowing = !this.isShowing;

      if (!this.isShowing) {
        this.$refs.modal.classList.add('out');
      }
    },

    closeModal() {
      this.$refs.button.classList.add('close');
      setTimeout(() => {
        this.$refs.modal.classList.add('out');
      }, 500);
      setTimeout(() => {
        this.isShowing = false;
      }, 500);
    }

  },

  beforeMount() {
    fullpage_api.destroy('all');
  }

});
// CONCATENATED MODULE: ./pages/contact.vue?vue&type=script&lang=js&
 /* harmony default export */ var pages_contactvue_type_script_lang_js_ = (contactvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(2);

// CONCATENATED MODULE: ./pages/contact.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(53)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  pages_contactvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "25c93086",
  "50bcfe8c"
  
)

/* harmony default export */ var contact = __webpack_exports__["default"] = (component.exports);

/***/ })

};;
//# sourceMappingURL=contact.js.map